//
//  File.swift
//  XWSwiftRefresh
//
//  Created by Xiong Wei on 15/10/7.
//  Copyright © 2015年 Xiong Wei. All rights reserved.
//

import UIKit

extension UIViewController {
    
    
//    public override class func initialize(){
//        if self != UITableView.self { return }
//        
//        struct once{
//            static var onceTaken:dispatch_once_t = 0
//        }
//        
//        dispatch_once(&once.onceTaken) { () -> Void in
//            
//            self.exchangeInstanceMethod1(Selector("deinit"), method2: Selector("xwDeinit"))
//        }
//        
//    }
//    
//    func xwDeinit(){
//        //正因为交换了方法，所以这里其实是执行的系统自己的 reloadData 方法
//        self.xwDeinit()
////        print("deinit 销毁了")
//    }
    
}



