//
//  AppDelegate.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"
#import "HomeViewController.h"
#import "MenuViewController.h"
#import "MMDrawerController.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) MainViewController *mainVc;
@property (strong, nonatomic) HomeViewController *homeVc;
@property (strong, nonatomic) MenuViewController *menuVc;
@property (strong, nonatomic) MMDrawerController *mmdVc;
@property (strong, nonatomic) UINavigationController *mainNc;

@end

