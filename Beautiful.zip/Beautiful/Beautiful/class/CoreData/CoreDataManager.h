//
//  CoreDataManager.h
//  CoreData
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

#define ManagerObjectModelFileName @"CoeDataModel"

@interface CoreDataManager : NSObject

@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *perStoreCoordinator;


+ (instancetype) sharedCoreDataManager;

- (void)saveContext;

@end
