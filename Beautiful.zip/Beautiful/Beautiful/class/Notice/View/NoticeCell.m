//
//  NoticeCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "NoticeCell.h"

@implementation NoticeCell


@end
