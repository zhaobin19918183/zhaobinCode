//
//  NoticeDetailCell.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NoticeDetailCell : UITableViewCell

@property(nonatomic,strong)BaseLabel  *titleLabel;
@property(nonatomic,strong)BaseImageView  * imgView;

@property(nonatomic,strong)BaseLabel  * contentOneLabel;
@property(nonatomic,strong)BaseLabel  * contentTwoLabel;

@end
