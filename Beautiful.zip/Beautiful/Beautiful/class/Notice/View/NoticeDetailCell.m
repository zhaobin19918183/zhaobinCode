//
//  NoticeDetailCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "NoticeDetailCell.h"

@implementation NoticeDetailCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.titleLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.titleLabel];
        
        self.imgView = [[BaseImageView alloc]init];
        [self.contentView addSubview:self.imgView];
        
        self.contentOneLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.contentOneLabel];
        
        self.contentTwoLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.contentTwoLabel];
    }
    return self;
}

-(void)layoutSubviews{

    [super layoutSubviews];
    self.titleLabel.frame = customCGRect(10, 10, 355, 45);
    [self.titleLabel setTextFont:16 textColor:BaseLabelBlue];
    
    self.contentOneLabel.frame = customCGRect(10, 65, 355, 80);
    [self.contentOneLabel setTextFont:12  textColor:BaseLabelBlack];
    
    self.imgView.frame = customCGRect(0, 150, 375, 200);
    self.imgView.backgroundColor = [UIColor blackColor];
    
    self.contentTwoLabel.frame = customCGRect(10, 355, 355, 80);
    [self.contentTwoLabel setTextFont:12  textColor:BaseLabelBlack];
    
    [self initData];
}

-(void)initData{

    [self.titleLabel setText:@"お知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知ら" textAlignment:BaseLabelLeft];
    
    [self.contentOneLabel setText:@"お知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせ" textAlignment:BaseLabelLeft];
    
    [self.contentTwoLabel setText:@"お知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせお知らせ" textAlignment:BaseLabelLeft];
}

@end
