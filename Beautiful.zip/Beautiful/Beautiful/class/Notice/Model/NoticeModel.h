//
//  NoticeModel.h
//  Beautiful
//
//  Created by newland on 2017/7/18.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseModel.h"

@interface NoticeModel : BaseModel

@end
