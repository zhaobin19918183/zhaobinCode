//
//  NoticeDetailViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "NoticeDetailViewController.h"
#import "NoticeDetailCell.h"

@interface NoticeDetailViewController (){
    BaseTableView *noticeTableView;
}


@end
/**
 * 機能名　　　　：お知らせリスト
 * 機能概要　　　：お知らせリスト詳しい
 * 作成者    　 ：郭麗影　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation NoticeDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self NavigationTitle:@"Notice"];
    [self CreatTableview];
}
 //creat tableview
-(void)CreatTableview{

    //creat tableview
    noticeTableView = [[BaseTableView alloc]init];
    noticeTableView.frame = CGRectMake(0, 0,Screen_W , Screen_H - YSpan(130)-64);
    noticeTableView.delegate = self;
    noticeTableView.dataSource = self;
    [self.view addSubview:noticeTableView];
    
    //プルロード
    [noticeTableView upRefresh];
    [noticeTableView upRefreshData:^{
        
    }];
    
    //プルダウン更新
    [noticeTableView downRefresh];
    [noticeTableView downRefreshData:^{
        NSLog(@"123456789/////");
        [self getRequest];
    }];
    
    //請求データ
    [self getRequest];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return Screen_H - YSpan(130)-64;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuse = @"reuse";
    NoticeDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil) {
        cell = [[NoticeDetailCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
}

#pragma mark - request
-(void)getRequest{
    [NetWorkManager POST:serviceUrl paraments:[self getRequestParament] showHUD:YES success:^(id responseObject) {
        [noticeTableView reloadData];
    } failure:^(NSError *error) {
        
    }];
}

-(NSDictionary *)getRequestParament{
    NSDictionary *dic = [[NSDictionary alloc]init];
    return dic;
}

//share button click event
-(void)shareButton{

    NSLog(@"123456");
}

//bottom view button click event
-(void)BottomViewButtonClick:(UIButton *)button{
    
    switch (button.tag) {
        case 0:
            NSLog(@"0");
            break;
        case 1:
            NSLog(@"1");
            break;
        case 2:
            NSLog(@"2");
            break;
        default:
            break;
    }
}

@end
