//
//  NoticeViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/14.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "NoticeViewController.h"
#import "NoticeCell.h"
#import "NoticeDetailViewController.h"
#import "MainViewController.h"

@interface NoticeViewController (){
    BaseTableView *noticeTableView;
}

@end
/**
 * 機能名　　　　：お知らせ
 * 機能概要　　　：お知らせリスト
 * 作成者    　 ：郭麗影　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation NoticeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = CountryLanguage(@"Notice");
    [self CreatTableview];
}
//creat tableview
-(void)CreatTableview{

    //creat tableview
    noticeTableView = [[BaseTableView alloc]init];
    noticeTableView.frame = CGRectMake(0, 0, self.view.frame.size.width, MainVc_H);
    noticeTableView.delegate = self;
    noticeTableView.dataSource = self;
    [self.view addSubview:noticeTableView];
    
    
    //プルロード
    [noticeTableView upRefresh];
    //プルダウン更新
    [noticeTableView downRefresh];
    //請求データ
    [self getRequest];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 12;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return YSpan(110);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuse = @"reuse";
    NoticeCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil) {
        cell = [[NoticeCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    NoticeDetailViewController * noticeDetail = [[NoticeDetailViewController alloc]init];
    [self.navigationController pushViewController:noticeDetail animated:YES];
}

#pragma mark - request
-(void)getRequest{
    [NetWorkManager POST:serviceUrl paraments:[self getRequestParament] showHUD:YES success:^(id responseObject) {
        [noticeTableView reloadData];
    } failure:^(NSError *error) {
        
    }];
}

-(NSDictionary *)getRequestParament{
    NSDictionary *dic = [[NSDictionary alloc]init];
    return dic;
}

@end
