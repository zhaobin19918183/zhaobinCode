//
//  MyPocketViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyProcketModel.h"
@interface MyPocketViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic)  BaseTableView *tableView;

@end
