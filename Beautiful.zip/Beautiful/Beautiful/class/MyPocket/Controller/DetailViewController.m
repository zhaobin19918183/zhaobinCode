//
//  DetailViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title =@"お知らせ";
    self.bottomView.frame = customCGRect(0, 530, 375, 80);
    self.titleLabel.hidden = YES;
    [self layoutView];
}
-(void)layoutView
{
    BaseButton *backButton = [[BaseButton alloc]init];
    backButton.layer.cornerRadius = 10.0;
    [backButton setText:@"MyPocket お知らせ" textColor:BaseButtonWhite];
    backButton.frame = customCGRect(80, 470, 215, 50);
    backButton.backgroundColor = [UIColor colorWithRed:1/255.0 green:86/255.0 blue:102/255.0 alpha:1];
    [backButton addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:backButton];

}
-(void)back
{
    [self.navigationController popViewControllerAnimated:YES];
  
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
