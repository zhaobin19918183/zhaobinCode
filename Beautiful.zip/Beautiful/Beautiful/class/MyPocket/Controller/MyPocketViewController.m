//
//  MyPocketViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "MyPocketViewController.h"
#import "BasePocketTableViewCell.h"
#import "MyPockerDetailViewController.h"
@interface MyPocketViewController ()
{

    NSMutableArray *imageArray;
    NSMutableArray *backImageArray;
    NSString *imageString ;
    NSMutableArray *dataArray;
}
@end
/**
 * 機能名　　　　：MyPocket
 * 機能概要　　　：美ら得アプリのログイン画面です。
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation MyPocketViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self layoutView];

   
}
/**
 * 機能名　　　　：MyPocket
 * 機能概要　　　：グラビアページ。
 * 作成者    　 ：趙ビン　2017/07/18
 ***********************************************************************
 ***********************************************************************
 */
-(void)layoutView
{
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView =[[BaseTableView alloc]initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H - 66*KHEIGHT)];
    self.tableView.delegate = self;
    self.tableView.dataSource=self;
    self.tableView.separatorStyle = NO;
    self.tableView.backgroundColor = [UIColor colorWithRed:231.0/255.0 green:231.0/255.0 blue:231.0/255.0 alpha:1];
    [self.tableView upRefresh];
    [self.tableView downRefresh];
    [self.view addSubview:self.tableView];
   //
    imageArray = [[NSMutableArray alloc]initWithObjects:@"pocket_red",@"pocket_blue",@"pocket_gray",@"pocket_orange", nil];
    
    [self dataPlist];
    
}
-(void)dataPlist
{
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"dataPlist" ofType:@"plist"];
    NSMutableDictionary *data = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    dataArray = [[NSMutableArray alloc]init];
    dataArray = [data valueForKey:@"MyPocket"];
   
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIndetifier = @"cell";
    BasePocketTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIndetifier];
    
    if (cell == nil) {
        cell = [[BasePocketTableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIndetifier];
    }
    //pocket_blue pocket_red pocket_gray pocket_orange
    if (indexPath.row<imageArray.count)
    {
        imageString = [NSString stringWithFormat:@"%@",[imageArray objectAtIndex:indexPath.row]];
    }
    else
    {
        imageString = [NSString stringWithFormat:@"%@",[imageArray objectAtIndex:indexPath.row%imageArray.count]];
    }
    
    cell.backImageVIew.image =[UIImage imageNamed:imageString];
    [cell myPocketCell:[MyProcketModel myPocketDic:[dataArray objectAtIndex:indexPath.row]]];

    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return dataArray.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

    return 150*KHEIGHT;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    MyPockerDetailViewController *detail =[[MyPockerDetailViewController alloc]init];
    [self.navigationController pushViewController:detail animated:YES];

}

@end
