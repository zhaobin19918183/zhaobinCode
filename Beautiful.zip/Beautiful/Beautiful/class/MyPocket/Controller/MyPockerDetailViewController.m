//
//  MyPockerDetailViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "MyPockerDetailViewController.h"
#import "DetailViewController.h"
@interface MyPockerDetailViewController ()
{
    BaseLabel *titleLabel;
    BaseLabel *lineLabel;
    BaseLabel *contentLabel;
    BaseImageView *imageView;
    NSMutableDictionary *dataDic;

}

@end

@implementation MyPockerDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self navigationBar];
    [self layoutView];
    // Do any additional setup after loading the view.
}
-(void)layoutView
{
    
    titleLabel= [[BaseLabel alloc]init];
    [titleLabel setTextFont:16 textColor:BaseLabelBlue];
    titleLabel.frame =customCGRect(10, 10, 355, 45);
   // titleLabel.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:titleLabel];
    
    lineLabel = [[BaseLabel alloc]init];
    lineLabel.frame = customCGRect(0, 60, 375, 1);
    lineLabel.backgroundColor = [UIColor colorWithRed:236/255.0 green:236/255.0 blue:236/255.0 alpha:1];
    [self.view addSubview:lineLabel];
    
    contentLabel= [[BaseLabel alloc]init];
    contentLabel.frame = customCGRect(10, 67, 355, 80);
    [contentLabel setTextFont:12  textColor:BaseLabelBlack];
    //contentLabel.backgroundColor = [UIColor orangeColor];
    [self.view addSubview:contentLabel];
    
    imageView= [[BaseImageView alloc]init];
    imageView.frame = customCGRect(0, 150, 375, 200);
    //imageView.backgroundColor = [UIColor blackColor];
    [self.view addSubview:imageView];
  
    BaseButton *detailButton = [[BaseButton alloc]init];
    detailButton.layer.cornerRadius = 10.0;
    [detailButton setText:@"MyPocket お知らせ" textColor:BaseButtonWhite];
    detailButton.frame = customCGRect(80, 470, 215, 50);
    detailButton.backgroundColor = [UIColor colorWithRed:204/255.0 green:67/255.0 blue:0 alpha:1];
    [detailButton addTarget:self action:@selector(detail) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:detailButton];
    
    self.bottomView.frame = customCGRect(0, 530, 375, 80);
    self.titleLabel.hidden = YES;
    
    [self initData];

}
-(void)detail
{
    DetailViewController *detailView = [[DetailViewController alloc]init];
    [self.navigationController pushViewController:detailView animated:YES];

}
-(void)initData
{

    [self dataPlist];
}

-(void)dataPlist
{
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"dataPlist" ofType:@"plist"];
    NSMutableDictionary *data = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    dataDic = [[NSMutableDictionary alloc]init];
    dataDic = [data valueForKey:@"MyPocketDetail"];
    [self myPocketModel:[MyProcketModel myPocketDic:dataDic]];
}
-(void)myPocketModel:(MyProcketModel *)model
{

    [titleLabel setText:model.titleStr textAlignment:BaseLabelLeft];
    
    [contentLabel setText:model.contentStr textAlignment:BaseLabelLeft];

     imageView.image =[UIImage imageNamed:@"demo"];
}
    
    


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)navigationBar
{
    
    self.title = CountryLanguage(@"MyPocket");
    
    
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
