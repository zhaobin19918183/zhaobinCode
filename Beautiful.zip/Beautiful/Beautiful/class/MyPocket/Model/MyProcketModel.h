//
//  MyProcketModel.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseModel.h"

@interface MyProcketModel : BaseModel
@property(nonatomic,strong)NSString  * titleStr;
@property(nonatomic,strong)NSString  * contentStr;
@property(nonatomic,strong)NSString  * ImageStr;
+(MyProcketModel *)myPocketDic :(NSMutableDictionary *)dic;
@end
