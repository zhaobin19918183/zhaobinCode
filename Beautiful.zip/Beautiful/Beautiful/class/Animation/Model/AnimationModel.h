//
//  AnimationModel.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseModel.h"

@interface AnimationModel : BaseModel
@property(nonatomic,strong)NSString  * ImageName;
@property(nonatomic,strong)NSString  * dateString;
@property(nonatomic,strong)NSString  * titleString;
@property(nonatomic,strong)NSString  * nameString;
+(AnimationModel *)animationDic :(NSMutableDictionary *)dic;
@end
