//
//  AnimationDetailModel.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "AnimationDetailModel.h"

@implementation AnimationDetailModel
+(AnimationDetailModel *)animationDic :(NSMutableDictionary *)dic
{
    AnimationDetailModel *model = [[AnimationDetailModel alloc]initWithDic:dic];
    model.titleStr =[dic valueForKey:@"titleStr"];
    model.contentOne =[dic valueForKey:@"contentOne"];
    model.contentTwo =[dic valueForKey:@"contentTwo"];
    model.imageNameStr =[dic valueForKey:@"imageNameStr"];
    
    return model;

}
@end
