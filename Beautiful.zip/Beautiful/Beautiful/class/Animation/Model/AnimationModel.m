//
//  AnimationModel.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "AnimationModel.h"

@implementation AnimationModel
+(AnimationModel *)animationDic :(NSMutableDictionary *)dic
{
    AnimationModel *model = [[AnimationModel alloc]initWithDic:dic];
    model.nameString = [dic valueForKey:@"nameString"];
    model.ImageName   = [dic valueForKey:@"imageName"];
    model.dateString = [dic valueForKey:@"dateString"];
    model.titleString = [dic valueForKey:@"titleString"];
    return model;
}
@end
