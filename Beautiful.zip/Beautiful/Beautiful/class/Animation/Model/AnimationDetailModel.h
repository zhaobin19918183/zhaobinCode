//
//  AnimationDetailModel.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseModel.h"

@interface AnimationDetailModel : BaseModel
@property(nonatomic,strong)NSString  * titleStr;
@property(nonatomic,strong)NSString  * contentOne;
@property(nonatomic,strong)NSString  * contentTwo;
@property(nonatomic,strong)NSString  * imageNameStr;
+(AnimationDetailModel *)animationDic :(NSMutableDictionary *)dic;
@end
