//
//  AnimationDetailViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseViewController.h"
#import "SRVideoPlayer.h"
@interface AnimationDetailViewController : BaseDetailViewController
@property(nonatomic,strong)BaseLabel  *titleLab;
@property(nonatomic,strong)BaseImageView  * imgView;

@property(nonatomic,strong)BaseLabel  * contentOneLabel;
@property(nonatomic,strong)BaseLabel  * contentTwoLabel;

@property(nonatomic,strong)BaseButton  * playButton;
@property (nonatomic, strong) SRVideoPlayer *videoPlayer;
@end
