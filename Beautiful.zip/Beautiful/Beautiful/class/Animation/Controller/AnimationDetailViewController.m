//
//  AnimationDetailViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "AnimationDetailViewController.h"
#import "AnimationDetailModel.h"
@interface AnimationDetailViewController ()

{
    AnimationDetailModel *model;
    NSMutableDictionary *dataDic;
}

@end
/**
 * 機能名　　　　：アニメ
 * 機能概要　　　：美ら得アプリのログイン画面です。
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation AnimationDetailViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self layoutView];
    // Do any additional setup after loading the view.
}
-(void)layoutView
{
    self.title = CountryLanguage(@"アニメ");
    self.titleLab = [[BaseLabel alloc]init];
    [self.view addSubview:self.titleLab];
    
    self.imgView = [[BaseImageView alloc]init];
    [self.view addSubview:self.imgView];
    
    self.playButton = [[BaseButton alloc]init];
    [self.imgView addSubview:self.playButton];
    
    self.contentOneLabel = [[BaseLabel alloc]init];
    [self.view addSubview:self.contentOneLabel];
    
    self.contentTwoLabel = [[BaseLabel alloc]init];
    [self.view addSubview:self.contentTwoLabel];
    [self layoutSubviews];
}


-(void)layoutSubviews
{
    self.titleLab.frame = customCGRect(10, 10, 355, 45);
    [self.titleLab setTextFont:16 textColor:BaseLabelBlue];
    
    self.contentOneLabel.frame = customCGRect(10, 65, 355, 80);
    [self.contentOneLabel setTextFont:12  textColor:BaseLabelBlack];
    
    self.imgView.frame = customCGRect(0, 150, 375, 200);
    self.imgView.userInteractionEnabled=YES;
    
    self.imgView.backgroundColor = [UIColor blackColor];
    
    self.playButton.frame = customCGRect(165, 80, 40, 40);
    [self.playButton setImage:[UIImage imageNamed:@"ico_play"] forState:UIControlStateNormal];
    [self.playButton addTarget:self action:@selector(showVideoPlayer) forControlEvents:UIControlEventTouchDown];
    
    self.contentTwoLabel.frame = customCGRect(10, 355, 355, 80);
    [self.contentTwoLabel setTextFont:12  textColor:BaseLabelBlack];
    
    [self dataPlist];
}
-(void)dataPlist
{
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"dataPlist" ofType:@"plist"];
    NSMutableDictionary *data = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    dataDic = [[NSMutableDictionary alloc]init];
    dataDic = [data valueForKey:@"AnimationDetail"];
    [self animationModel:[AnimationDetailModel animationDic:dataDic]];
    
    
    
}

-(void)animationModel:(AnimationDetailModel *)detailModel
{
    [self.titleLab setText:detailModel.titleStr textAlignment:BaseLabelLeft];
    
    [self.contentOneLabel setText:detailModel.contentOne textAlignment:BaseLabelLeft];
    
    [self.contentTwoLabel setText:detailModel.contentTwo textAlignment:BaseLabelLeft];
   self.imgView.image = [UIImage imageNamed:@"demo"];
}

-(void)backViewcontroller
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)showVideoPlayer
{
    
    self.imgView.hidden =YES;
    // [self prefersStatusBarHidden];
    UIView *playerView = [[UIView alloc] init];
    playerView.frame =customCGRect(0, 150, 375, 200);
    [self.view addSubview:playerView];
    _videoPlayer = [SRVideoPlayer playerWithVideoURL:[self urlstring] playerView:playerView playerSuperView:playerView.superview];
    _videoPlayer.videoName = @"Here Is The Video Name";
    _videoPlayer.playerEndAction = SRVideoPlayerEndActionLoop;
    [_videoPlayer play];
}
//- (BOOL)prefersStatusBarHidden
//{
//    return YES;
//}
-(NSURL *)urlstring
{
    NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"好好(你的名字)" withExtension:@"mp4"];
//    
//    NSString *videoURLString = @"http://yxfile.idealsee.com/9f6f64aca98f90b91d260555d3b41b97_mp4.mp4";
//    NSURL *fileURL = [NSURL URLWithString:videoURLString];
    
    
    return fileURL;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
