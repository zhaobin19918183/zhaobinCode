//
//  AnimationViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/14.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "AnimationViewController.h"
#import "AnimationTableViewCell.h"
#import "AnimationModel.h"
#import "AnimationDetailViewController.h"
@interface AnimationViewController (){
    BaseTableView *animationTableView;
    NSMutableArray *dataArray;
}

@end
/**
 * 機能名　　　　：アニメ
 * 機能概要　　　：美ら得アプリのログイン画面です。
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation AnimationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = CountryLanguage(@"Animation");
    [self dataPlist];
    [self layoutView];
    
  
}
-(void)layoutView
{
    //creat tableview
    animationTableView = [[BaseTableView alloc]init];
    animationTableView.frame = CGRectMake(0, 0, self.view.frame.size.width, MainVc_H);
    animationTableView.delegate = self;
    animationTableView.dataSource = self;
   
    [animationTableView downRefresh];
    if (dataArray.count>5)
    {
        [animationTableView upRefresh];
    }
    [self.view addSubview:animationTableView];

}

-(void)dataPlist
{
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"dataPlist" ofType:@"plist"];
    NSMutableDictionary *data = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    dataArray = [[NSMutableArray alloc]init];
    dataArray = [data valueForKey:@"Animation"];
   
  
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 110*KHEIGHT;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuse = @"reuse";
    AnimationTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil) {
        cell = [[AnimationTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    [cell animationModel:[AnimationModel animationDic:[dataArray objectAtIndex:indexPath.row]]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    AnimationDetailViewController *detail = [[AnimationDetailViewController alloc]init];
    [self.navigationController pushViewController:detail animated:YES];
    
    
}

@end
