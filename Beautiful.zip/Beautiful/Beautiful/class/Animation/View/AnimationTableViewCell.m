//
//  AnimationTableViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "AnimationTableViewCell.h"

@implementation AnimationTableViewCell
/**
 * 機能名　　　　：アニメ
 * 機能概要　　　：美ら得アプリのログイン画面です。
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.photoImagView = [[BaseImageView alloc]init];
        
        [self.contentView addSubview:self.photoImagView];
        
        self.titleLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.titleLabel];
        
        self.dateLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.dateLabel];
        
        self.authorLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.authorLabel];
    }
    return self;
}

-(void)layoutSubviews{
    
    [super layoutSubviews];
    
    self.photoImagView.frame = customCGRect(10, 5, 120, 100);
    self.photoImagView.backgroundColor = [UIColor blackColor];
    
    self.titleLabel.frame = CGRectMake(CGRectGetMaxX(self.photoImagView.frame)+XSpan(5), YSpan(5), Screen_W - CGRectGetMaxX(self.photoImagView.frame)-XSpan(15), YSpan(60));
    [self.titleLabel setTextFont:XSpan(16) textColor:BaseLabelBlack];
    
    self.dateLabel.frame = CGRectMake(CGRectGetMaxX(self.photoImagView.frame)+XSpan(5), CGRectGetMaxY(self.titleLabel.frame)+YSpan(15), XSpan(125), YSpan(20));
    [self.dateLabel setTextFont:XSpan(10) textColor:BaseLabelGray];
    
    self.authorLabel.frame = CGRectMake(CGRectGetMaxX(self.dateLabel.frame)+XSpan(5), CGRectGetMaxY(self.titleLabel.frame)+YSpan(15), XSpan(100), YSpan(20));
    [self.authorLabel setTextFont:XSpan(10) textColor:BaseLabelWhite];
    self.authorLabel.textAlignment = NSTextAlignmentCenter;
    self.authorLabel.layer.cornerRadius = XSpan(5);
    self.authorLabel.layer.masksToBounds = YES;
    self.authorLabel.backgroundColor = RGBA(0, 86, 102, 1);
    
  //  [self initData];
}
-(void)animationModel:(AnimationModel *)model
{

    [self.titleLabel setText:model.titleString textAlignment:BaseLabelLeft];
    
    [self.dateLabel setText:model.dateString textAlignment:BaseLabelLeft];
    
    [self.authorLabel setText:model.nameString textAlignment:BaseLabelCenter];
    
    self.photoImagView.image =[UIImage imageNamed:model.ImageName];
 

}
-(void)initData{
    
    [self.titleLabel setText:@"通知通知通知通知通知通知通知通知通知通知通知通知" textAlignment:BaseLabelLeft];
    
    [self.dateLabel setText:@"更新日  2017年07月07日" textAlignment:BaseLabelLeft];
    
    [self.authorLabel setText:@"作者作者作者" textAlignment:BaseLabelCenter];
}


@end
