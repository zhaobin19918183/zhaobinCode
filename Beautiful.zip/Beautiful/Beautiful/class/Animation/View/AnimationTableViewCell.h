//
//  AnimationTableViewCell.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AnimationModel.h"
@interface AnimationTableViewCell : UITableViewCell
@property(nonatomic,strong)BaseImageView  * photoImagView;
@property(nonatomic,strong)BaseLabel  * titleLabel;
@property(nonatomic,strong)BaseLabel  * dateLabel;
@property(nonatomic,strong)BaseLabel  * authorLabel;
-(void)animationModel:(AnimationModel *)model;
@end
