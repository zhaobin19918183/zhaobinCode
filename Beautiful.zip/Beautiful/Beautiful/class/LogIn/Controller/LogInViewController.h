//
//  LogInViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/14.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseViewController.h"

@interface LogInViewController : BaseViewController

@end
