//
//  NetWorkManager.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "NetWorkManager.h"

static AFHTTPSessionManager *manager;
static MBProgressHUD *HUD;
/**
 * 機能名　　　　：工具類
 * 機能概要　　　：補助開発
 * 作成者    　 ：郭詠明　2017/07/13
 ***********************************************************************
 ***********************************************************************
 */
@implementation NetWorkManager
//初期設定データ
+(AFHTTPSessionManager *)shareManager{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!manager) {
            manager = [AFHTTPSessionManager manager];
            HUD = [[MBProgressHUD alloc]init];
        }
    });
    return manager;
}

//インターネットを取り消してお願いする
+(void)CancelNetWorkManager{
    [manager.operationQueue cancelAllOperations];
}

//post ネットワーク要求
+(void)POST:(NSString *)URLString paraments:(NSDictionary *)paraments showHUD:(BOOL)HUD success:(void(^)(id responseObject))success failure:(void(^)(NSError *error))failure{
    
    //タイムアウトタイム
    manager.requestSerializer.timeoutInterval = timeOut;
    
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    [manager.requestSerializer setQueryStringSerializationWithBlock:^NSString *(NSURLRequest *request, id parameters, NSError *__autoreleasing *error) {
        return parameters;
    }];
    
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json",@"text/javascript",@"text/html",@"text/plain",nil];
    
    //json
    NSData *dataFriends = [NSJSONSerialization dataWithJSONObject:paraments options:kNilOptions error:nil];
    NSString *jsonString = [[NSString alloc] initWithData:dataFriends
                                                 encoding:NSUTF8StringEncoding];
    NSString *paraString = [NSString stringWithFormat:@"json_str=%@",jsonString];
    
    //http
    [manager  POST:URLString parameters:paraString progress:^(NSProgress * _Nonnull uploadProgress) {
        
        if (HUD) {
            [NetWorkManager showHUD];
        }
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject){
         if (success){
             success(responseObject);
             [NetWorkManager hideHUD];
         }
     } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error){
         if (failure){
             failure(error);
             [NetWorkManager hideHUD];
             [NetWorkManager CancelNetWorkManager];
         }
     }];
}

+(void)showHUD{
    HUD = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
    HUD.label.text = CountryLanguage(@"加载中...");
    HUD.label.textColor = [UIColor blackColor];
    HUD.mode = MBProgressHUDAnimationFade;
}

+(void)hideHUD{
    [HUD hideAnimated:YES];
}

@end
