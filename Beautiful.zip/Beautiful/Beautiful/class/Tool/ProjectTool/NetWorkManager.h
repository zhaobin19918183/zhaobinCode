//
//  NetWorkManager.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <Foundation/Foundation.h>

/**タイムアウトタイム*/
static NSTimeInterval timeOut = 30.f;

@interface NetWorkManager : NSObject

/**
 初期設定データ

 @return AFHTTPSessionManager
 */
+(AFHTTPSessionManager *)shareManager;

/**
 インターネットを取り消してお願いする
 */
+(void)CancelNetWorkManager;

/**
 ネットワーク要求

 @param URLString url
 @param paraments アップロードパラメータ
 @param HUD 表示活動指示器
 @param success 成功後のフィボナッチリトレースメント
 @param failure 失敗後のフィボナッチリトレースメント
 */
+(void)POST:(NSString *)URLString paraments:(NSDictionary *)paraments showHUD:(BOOL)HUD success:(void(^)(id responseObject))success failure:(void(^)(NSError *error))failure;

/**
 表示活動指示器
 */
+(void)showHUD;

/**
 隠しイベント指示器
 */
+(void)hideHUD;

@end
