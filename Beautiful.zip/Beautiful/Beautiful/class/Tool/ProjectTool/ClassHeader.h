//
//  ClassHeader.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#ifndef ClassHeader_h
#define ClassHeader_h

//screen
#define Screen_W [UIScreen mainScreen].bounds.size.width
#define Screen_H [UIScreen mainScreen].bounds.size.height
#define KWIDTH ([UIScreen mainScreen].bounds.size.width/375)
#define KHEIGHT ([UIScreen mainScreen].bounds.size.height/667)
#define MainVc_H Screen_H - 64 - 40
#define XSpan(X) X*KWIDTH
#define YSpan(Y) Y*KHEIGHT
#define customCGRect(X,Y,W,H) CGRectMake(X*KWIDTH, Y*KHEIGHT, W*KWIDTH, H*KHEIGHT)
//多言語
#define CountryLanguage(Language) NSLocalizedString(Language, @"")
//RGB
#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
#define serviceUrl @"www.baidu.com"
#endif /* ClassHeader_h */
