//
//  PhotoModel.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseModel.h"

@interface PhotoModel : BaseModel
@property(nonatomic,strong)NSString  * ImageName;
@property(nonatomic,strong)NSString  * contentString;
+(PhotoModel *)PhotoDic :(NSMutableDictionary *)dic;
@end
