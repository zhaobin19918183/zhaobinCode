//
//  PhotoModel.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "PhotoModel.h"

@implementation PhotoModel

+(PhotoModel *)PhotoDic :(NSMutableDictionary *)dic
{
    PhotoModel *photo = [[PhotoModel alloc]initWithDic:dic];
    photo.ImageName =[dic valueForKey:@"imageName"];
    return photo;

}
@end
