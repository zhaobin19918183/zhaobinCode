//
//  PhotoViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/14.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "PhotoViewController.h"
#import "PhotoCollectionViewCell.h"
#import "PhotoModel.h"
static NSString *reuse = @"reuse";

@interface PhotoViewController (){
    BaseCollectionView *photoCollectionView;
    NSMutableArray *dataImageArray;
    
}

@end
/**
 * 機能名　　　　：写真
 * 機能概要　　　：グラビアページ。
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation PhotoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = CountryLanguage(@"Photo");
     [self dataPlist];
     [self collection];
   
 
}

-(void)collection
{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    [layout setScrollDirection:UICollectionViewScrollDirectionVertical];
    
    //creat
    photoCollectionView = [[BaseCollectionView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, MainVc_H) collectionViewLayout:layout];
    photoCollectionView.backgroundColor = [UIColor clearColor];
    photoCollectionView.delegate = self;
    photoCollectionView.dataSource = self;
    [photoCollectionView upRefresh];
    [photoCollectionView downRefresh];
    [self.view addSubview:photoCollectionView];
    
    //register
    [photoCollectionView registerClass:[PhotoCollectionViewCell class] forCellWithReuseIdentifier:reuse];
}
-(void)dataPlist
{
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"dataPlist" ofType:@"plist"];
    NSMutableDictionary *data = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    dataImageArray = [[NSMutableArray alloc]init];
    dataImageArray = [data valueForKey:@"PhotoArray"];

}
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return dataImageArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    PhotoCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuse forIndexPath:indexPath];
    
    if (cell ==nil) {
        cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuse forIndexPath:indexPath];
    }
    
    cell.backgroundColor = [UIColor yellowColor];
    [cell setImageName:[PhotoModel PhotoDic:[dataImageArray objectAtIndex:indexPath.row]]];
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(110*KWIDTH, 110*KWIDTH);
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    PhotoDetialViewController *detail =[[PhotoDetialViewController alloc]init];
    
    [self.navigationController pushViewController:detail animated:YES];
    
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(YSpan(10), XSpan(10), YSpan(10), XSpan(10));
}

@end
