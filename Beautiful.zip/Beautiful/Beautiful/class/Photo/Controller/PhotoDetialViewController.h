//
//  PhotoDetialViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseViewController.h"

@interface PhotoDetialViewController : BaseDetailViewController<UITextViewDelegate>
@property( nonatomic,strong) UIBarButtonItem *leftBarButtonItem;
@end
