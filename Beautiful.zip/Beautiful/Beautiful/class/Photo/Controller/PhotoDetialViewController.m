//
//  PhotoDetialViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "PhotoDetialViewController.h"
#import "PhotoModel.h"
@interface PhotoDetialViewController ()
{

    BaseTextView *contentTextView;
    BaseImageView *backImageView;
    PhotoModel *model;
    NSMutableDictionary *dataDic;
}

@end
/**
 * 機能名　　　　：写真の詳細は
 * 機能概要　　　：美ら得アプリのログイン画面です。
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation PhotoDetialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.bottomView.hidden = YES;
    [self layoutView];
    [self navigationBar];
    [self dataPlist];

}
/**
 * 機能名　　　　：写真の詳細は
 * 機能概要　　　：ページをレイアウト。
 * 作成者    　 ：趙ビン　2017/07/18
 ***********************************************************************
 ***********************************************************************
 */
-(void)layoutView
{
    self.view.backgroundColor =[UIColor colorWithRed:85/255.0 green:85/255.0 blue:85/255.0 alpha:1];
    
    UITapGestureRecognizer*tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(backViewcontroller)];
    [self.view addGestureRecognizer:tapGesture];
    
    backImageView = [[BaseImageView alloc]init];
    backImageView.frame = customCGRect(10, 100, 355, 200);
    backImageView.backgroundColor = [UIColor whiteColor];
    
    [self.view addSubview:backImageView];
    
    contentTextView = [[BaseTextView alloc]init];
    contentTextView.frame = customCGRect(10, backImageView.bounds.size.height + 110,  [UIScreen mainScreen].bounds.size.width-20, [UIScreen mainScreen].bounds.size.height);
    contentTextView.backgroundColor = [UIColor clearColor];
 
    contentTextView.textColor = [UIColor whiteColor];
    contentTextView.scrollEnabled = NO;
    contentTextView.userInteractionEnabled = NO;
    [self.view addSubview:contentTextView];
    
    
}
/**
 * 機能名　　　　：写真の詳細は
 * 機能概要　　　：データのページ。
 * 作成者    　 ：趙ビン　2017/07/18
 ***********************************************************************
 ***********************************************************************
 */
-(void)dataPlist
{
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"dataPlist" ofType:@"plist"];
    NSMutableDictionary *data = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    dataDic = [[NSMutableDictionary alloc]init];
    dataDic = [data valueForKey:@"PhotoDetail"];
    backImageView.image =[UIImage imageNamed:[dataDic valueForKey:@"imageName"]];
    contentTextView.text = [dataDic valueForKey:@"content"];

}

-(void)navigationBar
{
    
    self.title = CountryLanguage(@"写真名");

}

-(void)backViewcontroller
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
