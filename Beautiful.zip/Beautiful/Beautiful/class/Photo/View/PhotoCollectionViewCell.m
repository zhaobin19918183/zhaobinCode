//
//  PhotoCollectionViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "PhotoCollectionViewCell.h"
#import "PhotoModel.h"
@implementation PhotoCollectionViewCell


-(instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    
    if (self)
    {
        self.backImageView = [[BaseImageView alloc]init];
        self.backImageView.frame = CGRectMake(0, 0, self.contentView.bounds.size.width, self.contentView.bounds.size.height);
        self.backImageView.backgroundColor = [UIColor redColor];
        [self addSubview:self.backImageView];
    }

    return  self;
}

- (void)setImageName:(PhotoModel *)imageName
{
    self.backImageView.image =[UIImage imageNamed:imageName.ImageName];
    
}
@end
