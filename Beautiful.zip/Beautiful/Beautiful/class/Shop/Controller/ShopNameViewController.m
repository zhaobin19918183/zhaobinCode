//
//  ShopNameViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "ShopNameViewController.h"

@interface ShopNameViewController (){
    BaseTableView *shopNameTableView;//リスト
}

@end
/**
 * 機能名　　　　：店名
 * 機能概要　　　：ショップ名リスト
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation ShopNameViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = CountryLanguage(@"Name of tourist area");
    [self leftItemButton];
    
    //creat tableview
    shopNameTableView = [[BaseTableView alloc]init];
    shopNameTableView.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-64);
    shopNameTableView.delegate = self;
    shopNameTableView.dataSource = self;
    shopNameTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:shopNameTableView];
    
    //プルロード
    [shopNameTableView upRefresh];
    //プルダウン更新
    [shopNameTableView downRefresh];
    //請求データ
    [self getRequest];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 12;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return tableView.frame.size.height/6;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuse = @"reuse";
    ShopNameTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil) {
        cell = [[ShopNameTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse frame:CGRectMake(0, 0, tableView.frame.size.width, [self tableView:tableView heightForRowAtIndexPath:indexPath])];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    ShopDetailViewController *detailVc = [[ShopDetailViewController alloc]init];
    [self.navigationController pushViewController:detailVc animated:YES];
}

#pragma mark - request
-(void)getRequest{
    [NetWorkManager POST:serviceUrl paraments:[self getRequestParament] showHUD:YES success:^(id responseObject) {
        [shopNameTableView reloadData];
    } failure:^(NSError *error) {
        
    }];
}

-(NSDictionary *)getRequestParament{
    NSDictionary *dic = [[NSDictionary alloc]init];
    return dic;
}

@end
