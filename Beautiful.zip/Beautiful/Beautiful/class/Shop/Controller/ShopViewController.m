//
//  ShopViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/14.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "ShopViewController.h"

static NSString *reuse = @"reuse";

@interface ShopViewController (){
    BaseCollectionView *shopCollectionView;//リスト
}

@end
/**
 * 機能名　　　　：商店
 * 機能概要　　　：ショップリスト
 * 作成者    　 ：郭詠明　2017/07/13
 ***********************************************************************
 ***********************************************************************
 */
@implementation ShopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = CountryLanguage(@"Shop");
    
    //layout
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    [layout setScrollDirection:UICollectionViewScrollDirectionVertical];
    
    //creat
    shopCollectionView = [[BaseCollectionView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, MainVc_H) collectionViewLayout:layout];
    shopCollectionView.backgroundColor = [UIColor clearColor];
    shopCollectionView.delegate = self;
    shopCollectionView.dataSource = self;
    [self.view addSubview:shopCollectionView];
    
    //register
    [shopCollectionView registerClass:[ShopCollectionViewCell class] forCellWithReuseIdentifier:reuse];
    
    //プルロード
    [shopCollectionView upRefresh];
    //プルダウン更新
    [shopCollectionView downRefresh];
    //請求データ
    [self getRequest];
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 16;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    ShopCollectionViewCell *cell = [[ShopCollectionViewCell alloc]initWithFrame:CGRectMake(0, 0,(collectionView.frame.size.width-XSpan(30))/2, (collectionView.frame.size.height-YSpan(50))/4)];
    cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuse forIndexPath:indexPath];
    
    cell.backgroundColor = [UIColor yellowColor];
    
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake((collectionView.frame.size.width-XSpan(30))/2, (collectionView.frame.size.height-YSpan(50))/4);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(YSpan(10), XSpan(10), YSpan(10), XSpan(10));
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    ShopNameViewController *shopNameVc = [[ShopNameViewController alloc]init];
    [self.navigationController pushViewController:shopNameVc animated:YES];
}

#pragma mark - request
-(void)getRequest{
    [NetWorkManager POST:serviceUrl paraments:[self getRequestParament] showHUD:YES success:^(id responseObject) {
        [shopCollectionView reloadData];
    } failure:^(NSError *error) {
        
    }];
}

-(NSDictionary *)getRequestParament{
    NSDictionary *dic = [[NSDictionary alloc]init];
    return dic;
}

@end
