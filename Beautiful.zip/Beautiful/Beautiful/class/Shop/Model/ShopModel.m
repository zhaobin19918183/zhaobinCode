//
//  ShopModel.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "ShopModel.h"
/**
 * 機能名　　　　：商店
 * 機能概要　　　：店舗データ
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation ShopModel

@end
