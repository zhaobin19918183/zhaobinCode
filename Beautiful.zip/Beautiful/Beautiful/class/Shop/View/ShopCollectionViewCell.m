//
//  ShopCollectionViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "ShopCollectionViewCell.h"
/**
 * 機能名　　　　：商店
 * 機能概要　　　：商店 cell
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation ShopCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        self.contentView.frame = self.frame;
        [self createSubviews];
    }
    return self;
}

-(void)createSubviews{
    BaseImageView *imageView = [[BaseImageView alloc]init];
    imageView.frame = CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.height-shopLabelHeight);
    imageView.backgroundColor = [UIColor redColor];
    [self.contentView addSubview:imageView];
    
    BaseLabel *shopLabel = [[BaseLabel alloc]init];
    shopLabel.frame = CGRectMake(0, CGRectGetMaxY(imageView.frame), imageView.frame.size.width, self.contentView.frame.size.height-CGRectGetMaxY(imageView.frame));
    [shopLabel setText:@"shopLabel" textAlignment:BaseLabelCenter];
    [self.contentView addSubview:shopLabel];
}

@end
