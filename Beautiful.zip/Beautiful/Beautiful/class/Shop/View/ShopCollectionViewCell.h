//
//  ShopCollectionViewCell.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#define shopLabelHeight YSpan(30) 
@interface ShopCollectionViewCell : UICollectionViewCell
-(instancetype)initWithFrame:(CGRect)frame;
@end
