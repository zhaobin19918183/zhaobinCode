//
//  ShopNameTableViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "ShopNameTableViewCell.h"
/**
 * 機能名　　　　：店名
 * 機能概要　　　：店名cell
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation ShopNameTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier frame:(CGRect)frame{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        self.contentView.frame = self.frame;
        [self creatSubview];
    }
    return self;
}

-(void)creatSubview{
    BaseImageView *imageView = [[BaseImageView alloc]init];
    imageView.frame = CGRectMake(XSpan(10), YSpan(5), (self.contentView.frame.size.width-XSpan(20))/3, self.contentView.frame.size.height-YSpan(10));
    imageView.backgroundColor = [UIColor greenColor];
    [self.contentView addSubview:imageView];
    
    BaseLabel *titleLabel = [[BaseLabel alloc]init];
    titleLabel.frame = CGRectMake(CGRectGetMaxX(imageView.frame)+XSpan(5), imageView.frame.origin.y, self.contentView.frame.size.width-CGRectGetMaxX(imageView.frame)-XSpan(15), imageView.frame.size.height/4);
    titleLabel.backgroundColor = [UIColor yellowColor];
    [self.contentView addSubview:titleLabel];
    
    BaseLabel *contextLabel = [[BaseLabel alloc]init];
    contextLabel.frame = CGRectMake(titleLabel.frame.origin.x, CGRectGetMaxY(titleLabel.frame), titleLabel.frame.size.width, titleLabel.frame.size.height*2);
    contextLabel.backgroundColor = [UIColor redColor];
    [self.contentView addSubview:contextLabel];
    
    BaseLabel *authorLabel = [[BaseLabel alloc]init];
    authorLabel.frame = CGRectMake(self.contentView.frame.size.width-XSpan(10)-XSpan(102), CGRectGetMaxY(contextLabel.frame), XSpan(102), titleLabel.frame.size.height);
    authorLabel.backgroundColor = RGBA(0, 86, 102, 1);
    [self.contentView addSubview:authorLabel];
}

@end
