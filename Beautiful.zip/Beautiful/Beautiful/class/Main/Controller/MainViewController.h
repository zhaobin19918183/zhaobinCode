//
//  MainViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NinaPagerView.h"
#import "MenuCollectionViewCell.h"
@interface MainViewController : BaseViewController<NinaPagerViewDelegate>
@property(nonatomic,strong) NinaPagerView *ninaPagerView;
@property  int pageindex;
@end
