//
//  HomeViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/19.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseViewController.h"
#import "MenuCollectionViewCell.h"

@interface HomeViewController : BaseViewController<UICollectionViewDelegate,UICollectionViewDataSource,UITableViewDelegate,UITableViewDataSource>

@end
