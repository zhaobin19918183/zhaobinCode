//
//  MenuViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/18.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "MenuViewController.h"
static NSString *reuse = @"reuse";
static CGFloat itemHeight = 0;
static CGFloat itemWidth = 0;
@interface MenuViewController (){
    BaseCollectionView *menuCollectionView;
    NSMutableArray <UIImage *>*imageArray;
    NSMutableArray *titleArray;
    NSArray *modelArray;
}

@end
/**
 * 機能名　　　　：メニュー
 * 機能概要　　　：高速選択指定機能
 * 作成者    　 ：郭詠明　2017/07/14
 ***********************************************************************
 ***********************************************************************
 */
@implementation MenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = RGBA(0, 86, 102, 1);
    [self initData];
    
    [self.navigationItem setHidesBackButton:YES animated:NO];
    self.leftButton.hidden = YES;
    [self rightItemButton];
    [self.rightButton setImage:[UIImage imageNamed:@"close"] forState:UIControlStateNormal];
    [self.rightButton addTarget:self action:@selector(myPocketButton) forControlEvents:UIControlEventTouchUpInside];
    
    //layout
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    [layout setScrollDirection:UICollectionViewScrollDirectionVertical];
    
    //creat
    menuCollectionView = [[BaseCollectionView alloc] initWithFrame:CGRectMake(0, 0, XSpan(150), self.view.frame.size.height) collectionViewLayout:layout];
    menuCollectionView.backgroundColor = [UIColor clearColor];
    menuCollectionView.delegate = self;
    menuCollectionView.dataSource = self;
    [self.view addSubview:menuCollectionView];
    
    //register
    [menuCollectionView registerClass:[MenuCollectionViewCell class] forCellWithReuseIdentifier:reuse];
    [menuCollectionView registerClass:[UICollectionViewCell class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"headerId"];
}

-(void)initData{
    imageArray = [[NSMutableArray alloc]init];
    [imageArray addObject:[UIImage imageNamed:@"menu_home"]];
    [imageArray addObject:[UIImage imageNamed:@"menu_notice"]];
    [imageArray addObject:[UIImage imageNamed:@"menu_tourist"]];
    [imageArray addObject:[UIImage imageNamed:@"menu_shop"]];
    [imageArray addObject:[UIImage imageNamed:@"menu_animation"]];
    [imageArray addObject:[UIImage imageNamed:@"menu_photo"]];
    [imageArray addObject:[UIImage imageNamed:@"menu_pocket"]];
    
    titleArray = [[NSMutableArray alloc]init];
    [titleArray addObject:CountryLanguage(@"menu_home")];
    [titleArray addObject:CountryLanguage(@"menu_notify")];
    [titleArray addObject:CountryLanguage(@"menu_tourist_spots")];
    [titleArray addObject:CountryLanguage(@"menu_shop")];
    [titleArray addObject:CountryLanguage(@"menu_video")];
    [titleArray addObject:CountryLanguage(@"menu_photo")];
    [titleArray addObject:CountryLanguage(@"menu_myPocket")];
    
    modelArray = @[
                   @"Home",
                   @"Notice",
                   @"Tourist destination",
                   @"Shop",
                   @"Animation",
                   @"Photo",
                   @"myPocket"
                   ];
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 7;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    MenuCollectionViewCell *cell = [[MenuCollectionViewCell alloc]initWithFrame:CGRectMake(0, 0,itemWidth, itemHeight)];
    
    cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuse forIndexPath:indexPath];
    [[cell getImageView] setImage:[imageArray objectAtIndex:indexPath.row]];
    [[cell getmenuLabel] setText:[titleArray objectAtIndex:indexPath.row] textAlignment:BaseLabelLeft];
    
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    itemHeight = collectionView.frame.size.height/13;
    itemWidth = collectionView.frame.size.width;
    return CGSizeMake(itemWidth, itemHeight);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(YSpan(0), XSpan(0), YSpan(0), XSpan(0));
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    [[NSNotificationCenter defaultCenter]postNotificationName:[modelArray objectAtIndex:indexPath.row] object:nil];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
    return CGSizeMake(collectionView.frame.size.width, YSpan(20));
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    if([kind isEqualToString:UICollectionElementKindSectionHeader]){
        UICollectionReusableView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:@"headerId" forIndexPath:indexPath];
        if(headerView == nil){
            headerView = [[UICollectionReusableView alloc] init];
        }
        headerView.backgroundColor = [UIColor clearColor];
        
        return headerView;
    }
    return nil;
}

- (void)myPocketButton{
    [self.navigationController popViewControllerAnimated:YES];
}


@end
