//
//  MainViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "MainViewController.h"
#import "NinaPagerView.h"
#import "PhotoViewController.h"
#import "MyPocketViewController.h"
#import "NoticeViewController.h"
#import "TouristViewController.h"
#import "ShopViewController.h"
#import "AnimationViewController.h"
#import "MenuViewController.h"
#import "AppDelegate.h"
@interface MainViewController ()

@end
/**
 * 機能名　　　　：ホームページ面
 * 機能概要　　　：選択メニュー
 * 作成者    　 ：郭詠明　2017/07/13
 ***********************************************************************
 ***********************************************************************
 */
@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = CountryLanguage(@"app_name");
    
    [self leftItemButton];
    [self.leftButton setImage:[UIImage imageNamed:@"menu"] forState:UIControlStateNormal];
    [self.leftButton addTarget:self action:@selector(mainLeftButton:) forControlEvents:UIControlEventTouchUpInside];
    
    [self rightItemButton];
    [self.rightButton addTarget:self action:@selector(mainRightButton:) forControlEvents:UIControlEventTouchUpInside];
    
    /**<Titles showing on the topTab   **/
    NSArray *titleArray =   @[
                              CountryLanguage(@"Photo"),
                              CountryLanguage(@"MyPocket"),
                              CountryLanguage(@"Notice"),
                              CountryLanguage(@"Tourist destination"),
                              CountryLanguage(@"Shop"),
                              CountryLanguage(@"Animation"),
                              ];
    /**
     ViewControllers to the titles on the topTab.Just add your VCs' Class Name to the array. Wanning:the number of ViewControllers should equal to the titles.Meanwhile,default max VC number is 10.
     **/
    
    NSArray *vcsArray = @[
                          [[PhotoViewController alloc]init],
                          [[MyPocketViewController alloc]init],
                          [[NoticeViewController alloc]init],
                          [[TouristViewController alloc]init],
                          [[ShopViewController alloc]init],
                          [[AnimationViewController alloc]init],
                          ];

    /**
     A tip you should know is that when init the VCs frames,the default frame i set is FUll_CONTENT_HEIGHT,it means fullscreen height - NavigationHeight - TabbarHeight.If the frame is not what you want,just go to UIParameter.h to change it!XD**/
    
    self.ninaPagerView = [[NinaPagerView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H) WithTitles:titleArray WithVCs:vcsArray];
    self.ninaPagerView.delegate = self;
    self.ninaPagerView.nina_navigationBarHidden = NO;
    self.ninaPagerView.nina_autoBottomLineEnable = YES;
    self.ninaPagerView.ninaDefaultPage = self.pageindex;
    self.ninaPagerView.backgroundColor = [UIColor blueColor];
    [self.view addSubview:self.ninaPagerView];
}

- (void)mainLeftButton:(BaseButton *)button{
    AppDelegate *app =  (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [app.mmdVc toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

- (void)mainRightButton:(BaseButton *)button{
    
}

- (BOOL)deallocVCsIfUnnecessary{
    return YES;
}

@end
