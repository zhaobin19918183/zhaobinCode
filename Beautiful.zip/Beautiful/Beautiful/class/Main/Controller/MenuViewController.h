//
//  MenuViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/18.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseViewController.h"
#import "MenuCollectionViewCell.h"
@interface MenuViewController : BaseViewController<UICollectionViewDelegate,UICollectionViewDataSource>

@end
