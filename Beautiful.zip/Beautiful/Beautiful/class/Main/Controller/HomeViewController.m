//
//  HomeViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/19.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "HomeViewController.h"
#import "NoticeDetailViewController.h"
#import "HomeCollectionCell.h"
#import "AppDelegate.h"

static NSString *reuse = @"reuse";

@interface HomeViewController ()
{
    BaseView * bottomView;
    BaseCollectionView *menuCollectionView;
    NSMutableArray <UIImage *>*imageArray;
    NSMutableArray *titleArray;
    NSArray *modelArray;
    BaseView * topView;
    BaseTableView * noticeTable;
}


@end
/**
 * 機能名　　　　：トップページ
 * 機能概要　　　：トップページ表示
 * 作成者    　 ：郭麗影　2017/07/19
 ***********************************************************************
 ***********************************************************************
 */
@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.navigationItem setHidesBackButton:YES animated:NO];
    self.leftButton.hidden = YES;
    self.title = CountryLanguage(@"app_name");
    
    [self leftItemButton];
    [self.leftButton setImage:[UIImage imageNamed:@"menu"] forState:UIControlStateNormal];
    [self.leftButton addTarget:self action:@selector(mainLeftButton:) forControlEvents:UIControlEventTouchUpInside];
    
    [self rightItemButton];
    [self.rightButton addTarget:self action:@selector(mainRightButton:) forControlEvents:UIControlEventTouchUpInside];
    
    [self initData];
    [self CreatBackImage];
    [self CreatTopView];
    [self CreatTableview];
    [self CreatBottomView];
    
}

- (void)mainLeftButton:(BaseButton *)button{
    AppDelegate *app =  (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [app.mmdVc toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

- (void)mainRightButton:(BaseButton *)button{
    [[NSNotificationCenter defaultCenter]postNotificationName:@"myPocket" object:nil];
}

-(void)CreatBackImage{

    UIImageView * backimg = [[UIImageView alloc]init];
    backimg.frame = CGRectMake(0, 0, Screen_W, Screen_H);
    [self.view addSubview:backimg];
    backimg.image = [UIImage imageNamed:@"bg"];
}

-(void)CreatTopView{

    topView = [[BaseView alloc]init];
    topView.frame = customCGRect(0, 0, Screen_W, 30);
    topView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:topView];
    
    BaseLabel * titlelabel = [[BaseLabel alloc]init];
    titlelabel.frame = customCGRect(10, 0, 355, 29);
    [titlelabel setText:@"文字 文字 文字" textAlignment:BaseLabelCenter];
    [titlelabel setTextFont:14 textColor:BaseLabelBlack];
    titlelabel.textColor = RGBA(0, 86, 102, 1);
    [topView addSubview:titlelabel];
    
    BaseView * lineView = [[BaseView alloc]init];
    lineView.frame = customCGRect(10, 29, 355, 1);
    lineView.backgroundColor = RGBA(0, 86, 102, 1);
    [topView addSubview:lineView];
}

//creat tableview
-(void)CreatTableview{
    
    //creat tableview
    noticeTable = [[BaseTableView alloc]init];
    noticeTable.frame = CGRectMake(0, 0, self.view.frame.size.width, Screen_H - 64- YSpan(244));
    noticeTable.delegate = self;
    noticeTable.dataSource = self;
    [self.view addSubview:noticeTable];
    noticeTable.backgroundColor = [UIColor clearColor];
    
    noticeTable.tableHeaderView = topView;
    
    //プルロード
    [noticeTable upRefresh];
    //プルダウン更新
    [noticeTable downRefresh];
    //請求データ
    [self getRequest];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 12;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return YSpan(110);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuse = @"reuse";
    BaseNoticeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil) {
        cell = [[BaseNoticeTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NoticeDetailViewController * noticeDetail = [[NoticeDetailViewController alloc]init];
    [self.navigationController pushViewController:noticeDetail animated:YES];
}

#pragma mark - request
-(void)getRequest{
    [NetWorkManager POST:serviceUrl paraments:[self getRequestParament] showHUD:YES success:^(id responseObject) {
        [noticeTable reloadData];
    } failure:^(NSError *error) {
        
    }];
}

-(NSDictionary *)getRequestParament{
    NSDictionary *dic = [[NSDictionary alloc]init];
    return dic;
}


-(void)CreatBottomView{

    bottomView = [[BaseView alloc]init];
    bottomView.frame = CGRectMake(0, Screen_H - 64- YSpan(244), Screen_W, YSpan(244));
    bottomView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:bottomView];
    
    BaseLabel * label = [[BaseLabel alloc]init];
    label.frame = customCGRect(10, 0, 355, 29);
    [label setText:@"文字 文字 文字" textAlignment:BaseLabelCenter];
    [label setTextFont:14 textColor:BaseLabelBlue];
    label.textColor = RGBA(0, 86, 102, 1);
    [bottomView addSubview:label];
    
    BaseView * lineView = [[BaseView alloc]init];
    lineView.frame = customCGRect(10, 29, 355, 1);
    lineView.backgroundColor = RGBA(0, 86, 102, 1);
    [bottomView addSubview:lineView];
    
    [self CreatCollectionView];
}

-(void)CreatCollectionView{

    //layout
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    [layout setScrollDirection:UICollectionViewScrollDirectionVertical];
    
    //creat
    menuCollectionView = [[BaseCollectionView alloc] initWithFrame:CGRectMake(0, YSpan(30), Screen_W, YSpan(214)) collectionViewLayout:layout];
    menuCollectionView.backgroundColor = [UIColor clearColor];
    menuCollectionView.delegate = self;
    menuCollectionView.dataSource = self;
    [bottomView addSubview:menuCollectionView];
    
    //register
    [menuCollectionView registerClass:[HomeCollectionCell class] forCellWithReuseIdentifier:reuse];
}

-(void)initData{
    imageArray = [[NSMutableArray alloc]init];
    [imageArray addObject:[UIImage imageNamed:@"notice"]];
    [imageArray addObject:[UIImage imageNamed:@"tourist"]];
    [imageArray addObject:[UIImage imageNamed:@"shop"]];
    [imageArray addObject:[UIImage imageNamed:@"animation"]];
    [imageArray addObject:[UIImage imageNamed:@"photo"]];
    [imageArray addObject:[UIImage imageNamed:@"pocket"]];
    
    titleArray = [[NSMutableArray alloc]init];
    [titleArray addObject:CountryLanguage(@"Notice")];
    [titleArray addObject:CountryLanguage(@"Tourist destination")];
    [titleArray addObject:CountryLanguage(@"Shop")];
    [titleArray addObject:CountryLanguage(@"Animation")];
    [titleArray addObject:CountryLanguage(@"Photo")];
    [titleArray addObject:CountryLanguage(@"myPocket")];
    
    modelArray = @[
                   @"Notice",
                   @"Tourist destination",
                   @"Shop",
                   @"Animation",
                   @"Photo",
                   @"myPocket"
                   ];
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 6;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    HomeCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuse forIndexPath:indexPath];
    
    //cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuse forIndexPath:indexPath];
    [cell.imgView setImage:[imageArray objectAtIndex:indexPath.row]];
    [cell.titleLabel setText:[titleArray objectAtIndex:indexPath.row] textAlignment:BaseLabelCenter];
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(collectionView.frame.size.width/3, YSpan(107));
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(YSpan(0), XSpan(0), YSpan(0), XSpan(0));
}

//The spacing between each item
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}

//Line spacing between different rows
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    [[NSNotificationCenter defaultCenter]postNotificationName:[modelArray objectAtIndex:indexPath.row] object:nil];
}

- (void)myPocketButton{
    [self.navigationController popViewControllerAnimated:YES];
}



@end
