//
//  MenuCollectionViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/18.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "MenuCollectionViewCell.h"

@implementation MenuCollectionViewCell{
    BaseImageView *imageView;
    BaseLabel *menuLabel;
}

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        self.contentView.frame = self.frame;
        [self createSubviews];
    }
    return self;
}

-(void)createSubviews{
    imageView = [[BaseImageView alloc]init];
    imageView.frame = CGRectMake(XSpan(10), 0, self.contentView.frame.size.height-YSpan(10), self.contentView.frame.size.height-YSpan(10));
//    imageView.backgroundColor = [UIColor redColor];
    [self.contentView addSubview:imageView];
    
    menuLabel = [[BaseLabel alloc]init];
    menuLabel.frame = CGRectMake(CGRectGetMaxX(imageView.frame)+XSpan(10), imageView.frame.origin.y, self.contentView.frame.size.width-CGRectGetMaxX(imageView.frame)-XSpan(20), imageView.frame.size.height);
    [menuLabel setTextFont:BaseLabelDefaultFont textColor:BaseLabelWhite];
//    menuLabel.backgroundColor = [UIColor yellowColor];
    [self.contentView addSubview:menuLabel];
}

-(BaseImageView *)getImageView{
    return imageView;
}

-(BaseLabel *)getmenuLabel{
    return menuLabel;
}

@end
