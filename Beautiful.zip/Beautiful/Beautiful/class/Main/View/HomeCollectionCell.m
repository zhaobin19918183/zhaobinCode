//
//  HomeCollectionCell.m
//  Beautiful
//
//  Created by newland on 2017/7/20.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "HomeCollectionCell.h"

@implementation HomeCollectionCell

-(instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    
    if(self){
        
        self.imgView = [[UIImageView alloc]init];
        [self.contentView addSubview:self.imgView];
        
        self.titleLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.titleLabel];
        
    }
    
    return self;
    
}

-(void)layoutSubviews{
    
    [super layoutSubviews];
    
    self.imgView.frame = CGRectMake(XSpan(32), YSpan(10), (Screen_W/3 - XSpan(64)), (Screen_W/3 - XSpan(64)));
    
    [self.titleLabel setTextFont:14 textColor:BaseLabelBlack];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.frame = CGRectMake(XSpan(2), CGRectGetMaxY(self.imgView.frame)+YSpan(5), (Screen_W/3 - XSpan(4)), YSpan(20));
}

@end
