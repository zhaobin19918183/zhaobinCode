//
//  BaseModel.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject

/**
 辞書が回る model

 @param dic 辞書
 @return model
 */
-(instancetype)initWithDic:(NSDictionary *)dic;

/**
 model 辞書を回転する

 @return 辞書
 */
-(NSDictionary *)getModelDic;

@end
