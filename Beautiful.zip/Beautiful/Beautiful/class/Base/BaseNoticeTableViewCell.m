//
//  BaseTableViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/19.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseNoticeTableViewCell.h"

@implementation BaseNoticeTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.imgView = [[BaseImageView alloc]init];
        [self.contentView addSubview:self.imgView];
        
        self.titleLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.titleLabel];
        
        self.dateLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.dateLabel];
        
        self.authorLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.authorLabel];
    }
    return self;
}
//Location size
-(void)layoutSubviews{
    
    [super layoutSubviews];
    
    self.imgView.frame = customCGRect(10, 5, 120, 100);
    self.imgView.backgroundColor = [UIColor blackColor];
    
    self.titleLabel.frame = CGRectMake(CGRectGetMaxX(self.imgView.frame)+XSpan(5), YSpan(5), Screen_W - CGRectGetMaxX(self.imgView.frame)-XSpan(15), YSpan(60));
    
    self.dateLabel.frame = CGRectMake(CGRectGetMaxX(self.imgView.frame)+XSpan(5), CGRectGetMaxY(self.titleLabel.frame)+YSpan(15), XSpan(125), YSpan(20));
    [self.dateLabel setTextFont:10 textColor:BaseLabelGray];
    
    self.authorLabel.frame = CGRectMake(CGRectGetMaxX(self.dateLabel.frame)+XSpan(5), CGRectGetMaxY(self.titleLabel.frame)+YSpan(15), XSpan(100), YSpan(20));
    [self.authorLabel setTextFont:10 textColor:BaseLabelWhite];
    [self.authorLabel setFillet:5];
    self.authorLabel.backgroundColor = RGBA(0, 86, 102, 1);
    
    [self initData];
}

-(void)initData{
    
    self.imgView.image = [UIImage imageNamed:@"backImage2"];
    
    [self.titleLabel setText:@"通知通知通知通知通知通知通知通知通知通知通知通知" textAlignment:BaseLabelLeft];
    
    [self.dateLabel setText:@"更新日  2017年07月07日" textAlignment:BaseLabelLeft];
    
    [self.authorLabel setText:@"作者作者作者" textAlignment:BaseLabelCenter];
}

@end
