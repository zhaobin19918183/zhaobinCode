//
//  BaseDetailViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseDetailViewController.h"

@interface BaseDetailViewController ()


@end
/**
 * 機能名　　　　：お知らせ詳しい
 * 機能概要　　　：お知らせリスト詳しい
 * 作成者    　 ：郭麗影　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation BaseDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self BackButton];
    [self NavigationRightButton];
    [self CreatBottomView];
}
//Navigation return button
-(void)BackButton{

    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"back"] style:UIBarButtonItemStylePlain target:self action:@selector(backBtn)];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];

}
//Return button event
-(void)backBtn{

    [self.navigationController popViewControllerAnimated:YES];
}
//Navigation title
-(void)NavigationTitle:(NSString *)titleStr{

    self.navigationItem.title = CountryLanguage(titleStr);
    
}
//Navigation right share and my pocket button
-(void)NavigationRightButton{

    BaseButton *shareButton = [[BaseButton alloc] init];
    shareButton.frame = customCGRect(0, 0, 30, 30);
    [shareButton addTarget:self action:@selector(shareButton) forControlEvents:UIControlEventTouchUpInside];
    [shareButton setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
    UIBarButtonItem *shareItem = [[UIBarButtonItem alloc] initWithCustomView:shareButton];
    
    BaseButton *pocketButton = [[BaseButton alloc] init];
    pocketButton.frame = customCGRect(0, 0, 30, 30);
    [pocketButton addTarget:self action:@selector(pocketButton) forControlEvents:UIControlEventTouchUpInside];
    [pocketButton setImage:[UIImage imageNamed:@"myPocket"] forState:UIControlStateNormal];
    UIBarButtonItem *pocketItem = [[UIBarButtonItem alloc] initWithCustomView:pocketButton];

    
    NSArray *actionButtonItems = @[pocketItem,shareItem];
    self.navigationItem.rightBarButtonItems = actionButtonItems;
}
//Share button click event
-(void)shareButton{

 
}
//my pocket button click event
-(void)pocketButton{

    [[NSNotificationCenter defaultCenter]postNotificationName:@"myPocket" object:nil];
}
//Create bottom view
-(void)CreatBottomView{

    self.bottomView = [[UIView alloc]init];
    self.bottomView.frame = CGRectMake(0, Screen_H-130 * KHEIGHT-64, Screen_W, 130 * KHEIGHT);
    self.bottomView.backgroundColor = RGBA(238, 238, 238, 1);
    [self.view addSubview:self.bottomView];
    [self CreatBottomViewSubviews];
}
//Create bottom view Subviews
-(void)CreatBottomViewSubviews{

    for (int i = 0; i<3; i++) {
        BaseButton * but = [BaseButton buttonWithType:UIButtonTypeCustom];
        but.frame = CGRectMake(100 * KWIDTH + (Screen_W-200 * KWIDTH - 120 * KHEIGHT)/2 *i + 40 * KHEIGHT * i, 15 * KHEIGHT, 40 * KHEIGHT, 40 * KHEIGHT);
//        but.backgroundColor = [UIColor blackColor];
        [self.bottomView addSubview:but];
        if (i==0) {
            [but setImage:[UIImage imageNamed:@"facebook"] forState:UIControlStateNormal];
        }else if (i==1){
            [but setImage:[UIImage imageNamed:@"twitter"] forState:UIControlStateNormal];
        }else{
            [but setImage:[UIImage imageNamed:@"line"] forState:UIControlStateNormal];
        }
        
        but.tag = i;
        [but addTarget:self action:@selector(BottomViewButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    self.titleLabel = [[BaseLabel alloc]init];
    [self.bottomView addSubview:self.titleLabel];
    [self.titleLabel setFillet:5];
    self.titleLabel.backgroundColor = [UIColor whiteColor];
    self.titleLabel.frame = customCGRect(40, 70, 295, 45);
    [self.titleLabel setText:@"Cooperative web title" textAlignment:BaseLabelCenter];
}
//bottom view button click event
-(void)BottomViewButtonClick:(UIButton *)button{

    
}

-(CGFloat)getTableViewHeight{
    return Screen_H - 120 * KHEIGHT-64;
}

@end
