//
//  BaseLabel.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

/**label 色枚挙*/
typedef enum : NSUInteger {
    BaseLabelGray,
    BaseLabelBlack,
    BaseLabelBlue,
    BaseLabelRed,
    BaseLabelWhite,
} BaseLabelTextColor;

/**label アラインメント方式*/
typedef enum : NSUInteger {
    BaseLabelLeft,
    BaseLabelRight,
    BaseLabelCenter,
} BaseLabelTextAlignment;

/**フォントのサイズ*/
static CGFloat BaseLabelDefaultFont = 16;

@interface BaseLabel : UILabel
/**
 初期化
 
 @return self
 */
-(instancetype)init;

/**
 初期設定
 
 @param frame コントロールサイズ
 @return self
 */
-(instancetype)initWithFrame:(CGRect)frame;

/**
 文字とフォントを配置して

 @param text 文字
 @param alignment アラインメント方式
 */
-(void)setText:(NSString *)text textAlignment:(BaseLabelTextAlignment)alignment;

/**
 フォントのサイズとフォントの色を設定して

 @param font フォントサイズ
 @param color フォント色
 */
-(void)setTextFont:(CGFloat)font textColor:(BaseLabelTextColor)color;

/**
 適応内容の高さ
 1.先に良い内容を設定しておく必要があります
 2.必ずいいデザインframe設定
 3.先に良いフォントのサイズを設定しなければなりません
 */
-(void)autoLabelHeightFromString;

/**
 角丸サイズを設定する

 @param fillet 角丸サイズ
 */
-(void)setFillet:(CGFloat)fillet;

@end
