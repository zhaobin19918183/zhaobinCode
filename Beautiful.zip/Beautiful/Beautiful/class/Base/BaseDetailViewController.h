//
//  BaseDetailViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseDetailViewController : BaseViewController

@property(nonatomic,strong) UIView * bottomView;//bottom View;
@property(nonatomic,strong) BaseLabel * titleLabel;
-(void)NavigationTitle:(NSString *)titleStr;

-(void)shareButton;

-(CGFloat)getTableViewHeight;

@end
