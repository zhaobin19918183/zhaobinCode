//
//  BaseCollectionView.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseCollectionView.h"

@implementation BaseCollectionView{
    MJRefreshGifHeader *gifHeader;//更新のヘッド
    MJRefreshAutoGifFooter *gifFooter;//更新の足
}

//初期化
-(instancetype)init{
    @try {
        self = [super init];
        if (self) {
            [self initData];
        }
        return self;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

//初期設定
-(instancetype)initWithFrame:(CGRect)frame{
    @try {
        self = [super initWithFrame:frame];
        if (self) {
            [self initData];
        }
        return self;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

//初期設定データ
-(void)initData{
    @try {
        self.backgroundColor = [UIColor whiteColor];
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

#pragma mark - プルダウン更新
-(void)downRefresh{
    @try {
        gifHeader = [MJRefreshGifHeader headerWithRefreshingBlock:^{
            //コールバック
            if (self.headerRefreshBlock) {
                self.headerRefreshBlock(gifHeader);
            }
            [self reloadData];
            [self.mj_header endRefreshing];
        }];
        
        //文字セット
        [gifHeader setTitle:CountryLanguage(@"Drop refresh") forState:MJRefreshStateIdle];
        [gifHeader setTitle:CountryLanguage(@"Loosen refresh") forState:MJRefreshStatePulling];
        [gifHeader setTitle:CountryLanguage(@"Refreshing ...") forState:MJRefreshStateRefreshing];
        
        //フォントを設定
        gifHeader.stateLabel.font = [UIFont systemFontOfSize:15];
        gifHeader.lastUpdatedTimeLabel.font = [UIFont systemFontOfSize:15];
        
        //隠し時間
        gifHeader.lastUpdatedTimeLabel.hidden = YES;
        
        self.mj_header = gifHeader;
        
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
    
}

#pragma mark - プルロード
-(void)upRefresh{
    @try {
        
        gifFooter = [MJRefreshAutoGifFooter footerWithRefreshingBlock:^{
            //コールバック
            if (self.footerRefreshBlock) {
                self.footerRefreshBlock(gifFooter);
            }
            [self reloadData];
            [self.mj_footer endRefreshing];
        }];
        
        //文字セット
        [gifFooter setTitle:CountryLanguage(@"pull up loading") forState:MJRefreshStateIdle];
        [gifFooter setTitle:CountryLanguage(@"loosen load ...") forState:MJRefreshStatePulling];
        [gifFooter setTitle:CountryLanguage(@"is loading ...") forState:MJRefreshStateRefreshing];
        [gifFooter setTitle:CountryLanguage(@"No more data ...") forState:MJRefreshStateNoMoreData];
        
        //フォントサイズを設定
        gifFooter.stateLabel.font = [UIFont systemFontOfSize:15];
        
        self.mj_footer = gifFooter;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
    
}

//ロード時のコールバック
-(void)upRefreshData:(BaseCollectionViewFooterRefresh)refresh{
    self.footerRefreshBlock = refresh;
}

//更新時のフィボナッチリトレースメント
-(void)downRefreshData:(BaseCollectionViewHeaderRefresh)refresh{
    self.headerRefreshBlock = refresh;
}

@end
