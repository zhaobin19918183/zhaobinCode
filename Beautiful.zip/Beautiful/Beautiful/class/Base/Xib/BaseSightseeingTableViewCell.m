//
//  BaseSightseeingTableViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseSightseeingTableViewCell.h"

@implementation BaseSightseeingTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
