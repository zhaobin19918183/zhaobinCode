//
//  BaseShopTableViewCell.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseShopTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet BaseImageView *shopImageVIew;
@property (weak, nonatomic) IBOutlet BaseLabel *titleLabel;
@property (weak, nonatomic) IBOutlet BaseButton *leftButton;

@property (weak, nonatomic) IBOutlet BaseButton *rightButton;

@end
