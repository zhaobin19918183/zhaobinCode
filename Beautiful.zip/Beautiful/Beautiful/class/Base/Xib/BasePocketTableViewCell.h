//
//  BasePocketTableViewCell.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyProcketModel.h"

@interface BasePocketTableViewCell : UITableViewCell
@property (strong, nonatomic)  BaseLabel *titleLabel;
@property (strong, nonatomic)  BaseView *lineLabel;
@property (strong, nonatomic)  BaseTextView *contentTextView;
@property (strong, nonatomic)  BaseView *backView;
@property (strong, nonatomic)  BaseImageView *backImageVIew;
-(void)myPocketCell:(MyProcketModel *)model;

@end
