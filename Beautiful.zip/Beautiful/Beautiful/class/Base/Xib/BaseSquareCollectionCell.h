//
//  BaseSquareCollectionCell.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseSquareCollectionCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet BaseImageView *ImageView;
@property (weak, nonatomic) IBOutlet BaseLabel *titleLabel;

@end
