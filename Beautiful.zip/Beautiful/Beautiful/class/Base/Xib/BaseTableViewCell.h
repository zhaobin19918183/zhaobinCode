//
//  BaseTableViewCell.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet BaseImageView *ImageView;
@property (weak, nonatomic) IBOutlet BaseLabel *titleLabel;
@property (weak, nonatomic) IBOutlet BaseLabel *dateLabel;
@property (weak, nonatomic) IBOutlet BaseLabel *selectLabel;

@end
