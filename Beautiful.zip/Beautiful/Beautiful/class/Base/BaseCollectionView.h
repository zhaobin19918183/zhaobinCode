//
//  BaseCollectionView.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseCollectionView : UICollectionView
/**
 更新状態のフィボナッチリトレースメントに入る
 */
typedef void (^BaseCollectionViewHeaderRefresh)();
typedef void (^BaseCollectionViewFooterRefresh)();

/**
 更新しているフィボナッチリトレースメント
 */
@property(strong, nonatomic) BaseCollectionViewHeaderRefresh headerRefreshBlock;
@property(strong, nonatomic) BaseCollectionViewFooterRefresh footerRefreshBlock;

/**
 初期化
 
 @return self
 */
-(instancetype)init;

/**
 初期設定
 
 @param frame コントロールサイズ
 @return self
 */
-(instancetype)initWithFrame:(CGRect)frame;

/**プルロード*/
-(void)upRefresh;

/**
 ロード時のコールバック
 
 @param refresh MJRefreshGifHeader
 */
-(void)upRefreshData:(BaseCollectionViewFooterRefresh)refresh;

/**プルダウン更新*/
-(void)downRefresh;

/**
 更新時のフィボナッチリトレースメント
 
 @param refresh MJRefreshAutoGifFooter
 */
-(void)downRefreshData:(BaseCollectionViewHeaderRefresh)refresh;

@end
