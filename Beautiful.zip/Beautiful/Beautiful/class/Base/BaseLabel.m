//
//  BaseLabel.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseLabel.h"

@implementation BaseLabel

//初期化
-(instancetype)init{
    @try {
        self = [super init];
        if (self) {
            [self initData];
        }
        return self;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

//初期設定
-(instancetype)initWithFrame:(CGRect)frame{
    @try {
        self = [super initWithFrame:frame];
        if (self) {
            self.frame = frame;
            [self initData];
        }
        return self;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

//初期設定データ
-(void)initData{
    @try {
        self.numberOfLines = 0;
        [self setTextFont:BaseLabelDefaultFont textColor:BaseLabelBlack];
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

#pragma mark - カスタマイズ法
//文字とフォントを配置して
-(void)setText:(NSString *)text textAlignment:(BaseLabelTextAlignment)alignment{
    //フォントの配置を設定して
    switch (alignment) {
        case BaseLabelLeft:
            self.textAlignment = NSTextAlignmentLeft;
            break;
        case BaseLabelRight:
            self.textAlignment = NSTextAlignmentRight;
            break;
        case BaseLabelCenter:
            self.textAlignment = NSTextAlignmentCenter;
            break;
        default:
            break;
    }
    //空に判断して判断する
    if ([text isKindOfClass:[NSNull class]]||text==nil) {
        text = @"";
    }
    //文字セット
    [self setText:CountryLanguage(text)];
}

//フォントのサイズとフォントの色を設定して
-(void)setTextFont:(CGFloat)font textColor:(BaseLabelTextColor)color{
    //フォントの色を設定して
    switch (color) {
        case BaseLabelGray:
            self.textColor = [UIColor grayColor];
            break;
        case BaseLabelBlue:
            self.textColor = [UIColor blueColor];
            break;
        case BaseLabelBlack:
            self.textColor = [UIColor blackColor];
            break;
        case BaseLabelWhite:
            self.textColor = [UIColor whiteColor];
            break;
        case BaseLabelRed:
            self.textColor = [UIColor redColor];
            break;
        default:
            break;
    }
    
    //フォントサイズを設定
    if (font==0) {
        [self adjustsFontSizeToFitWidth];
    }else{
        self.font = [UIFont systemFontOfSize:XSpan(font)];
    }
}

/**
 適応内容の高さ
 1.先に良い内容を設定しておく必要があります
 2.必ずいいデザインframe設定
 3.先に良いフォントのサイズを設定しなければなりません
 */
-(void)autoLabelHeightFromString{
    //計算入力後の高度
    CGFloat labelHeight = [self.text
                           boundingRectWithSize:CGSizeMake(self.frame.size.width, 100000)
                           options:NSStringDrawingUsesLineFragmentOrigin
                           attributes:@{
                                        NSFontAttributeName:
                                            [UIFont systemFontOfSize:self.font.pointSize]
                                        }
                           context:nil].size.height;
    //重新赋值高度给frame
    CGRect labelRect = CGRectMake(self.frame.origin.x,
                                  self.frame.origin.y,
                                  self.frame.size.width,
                                  labelHeight);
    
    self.frame = labelRect;
}

/**
 角丸サイズを設定する
 
 @param fillet 角丸サイズ
 */
-(void)setFillet:(CGFloat)fillet{
    self.layer.masksToBounds = YES;
    if (fillet==0) {
        self.layer.cornerRadius = self.frame.size.width/2;
    }else{
        self.layer.cornerRadius = XSpan(fillet);
    }
}

@end
