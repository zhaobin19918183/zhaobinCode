//
//  BaseViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.translucent = NO;
    self.edgesForExtendedLayout = UIRectEdgeBottom;
    self.view.backgroundColor = [UIColor whiteColor];
    [self leftItemButton];
    [self rightItemButton];
}

- (void)leftItemButton{
    self.leftButton = [[BaseButton alloc] init];
    self.leftButton.frame = customCGRect(0, 0, 30, 30);
    //    self.leftButton.backgroundColor = [UIColor redColor];
    [self.leftButton addTarget:self action:@selector(goBackButton) forControlEvents:UIControlEventTouchUpInside];
    [self.leftButton setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:self.leftButton];
    self.navigationItem.leftBarButtonItem = leftItem;
    [self noTitleGoBackBtnStyle];
}

- (void)rightItemButton{
    self.rightButton = [[BaseButton alloc] init];
    self.rightButton.frame = customCGRect(0, 0, 30, 30);
//    self.rightButton.backgroundColor = [UIColor redColor];
    [self.rightButton addTarget:self action:@selector(myPocketButton) forControlEvents:UIControlEventTouchUpInside];
    [self.rightButton setImage:[UIImage imageNamed:@"myPocket"] forState:UIControlStateNormal];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:self.rightButton];
    self.navigationItem.rightBarButtonItem = rightItem;
}

-(void)goBackButton{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)noTitleGoBackBtnStyle{
    [[UIBarButtonItem appearance] setBackButtonTitlePositionAdjustment:UIOffsetMake(0, -60) forBarMetrics:UIBarMetricsDefault];
}

- (void)myPocketButton{
    [[NSNotificationCenter defaultCenter]postNotificationName:@"myPocket" object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
