//
//  BaseTableViewCell.h
//  Beautiful
//
//  Created by newland on 2017/7/19.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseNoticeTableViewCell : UITableViewCell

@property(nonatomic,strong)BaseImageView  * imgView;//picture
@property(nonatomic,strong)BaseLabel  *titleLabel;//title
@property(nonatomic,strong)BaseLabel  * dateLabel;//date
@property(nonatomic,strong)BaseLabel  * authorLabel;//author

@end
