//
//  TouristDetailViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseDetailViewController.h"
#import "TouristDetailTableViewCell.h"
@interface TouristDetailViewController : BaseDetailViewController<UITableViewDelegate,UITableViewDataSource>

@end
