//
//  TouristDetailViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "TouristDetailViewController.h"

@interface TouristDetailViewController (){
    BaseTableView *touristDetailTableView;
}

@end

@implementation TouristDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = CountryLanguage(@"Tourist destination");
    
    //creat tableview
    touristDetailTableView = [[BaseTableView alloc]init];
    touristDetailTableView.frame = CGRectMake(0, 0, self.view.frame.size.width, [self getTableViewHeight]);
    touristDetailTableView.delegate = self;
    touristDetailTableView.dataSource = self;
    touristDetailTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:touristDetailTableView];
    //請求データ
    [self getRequest];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return tableView.frame.size.height;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuse = @"reuse";
    TouristDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil) {
        cell = [[TouristDetailTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse frame:CGRectMake(0, 0, tableView.frame.size.width, [self tableView:tableView heightForRowAtIndexPath:indexPath])];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

-(void)BottomViewButtonClick:(UIButton *)button{
    
}

#pragma mark - request
-(void)getRequest{
    [NetWorkManager POST:serviceUrl paraments:[self getRequestParament] showHUD:YES success:^(id responseObject) {
        
        [touristDetailTableView reloadData];
    } failure:^(NSError *error) {
        
    }];
}

-(NSDictionary *)getRequestParament{
    NSDictionary *dic = [[NSDictionary alloc]init];
    return dic;
}

@end
