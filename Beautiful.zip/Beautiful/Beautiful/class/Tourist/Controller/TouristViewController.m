//
//  TouristViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/14.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "TouristViewController.h"

@interface TouristViewController (){
    BaseTableView *touristTableView;
}

@end
/**
 * 機能名　　　　：観光地
 * 機能概要　　　：観光のプレビュー
 * 作成者    　 ：郭詠明　2017/07/13
 ***********************************************************************
 ***********************************************************************
 */
@implementation TouristViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = CountryLanguage(@"Tourist destination");
    
    //creat tableview
    touristTableView = [[BaseTableView alloc]init];
    touristTableView.frame = CGRectMake(0, 0, self.view.frame.size.width, MainVc_H);
    touristTableView.delegate = self;
    touristTableView.dataSource = self;
    [self.view addSubview:touristTableView];
    
    //プルロード
    [touristTableView upRefresh];
    //プルダウン更新
    [touristTableView downRefresh];
    //請求データ
    [self getRequest];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 6;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return (tableView.frame.size.height-XSpan(4))/3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuse = @"reuse";
    TouristTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil) {
        cell = [[TouristTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse frame:CGRectMake(0, 0, tableView.frame.size.width, [self tableView:tableView heightForRowAtIndexPath:indexPath])];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    TouristAreaViewController *touristAreaVc = [[TouristAreaViewController alloc]init];
    [self.navigationController pushViewController:touristAreaVc animated:YES];
}

#pragma mark - request
-(void)getRequest{
    [NetWorkManager POST:serviceUrl paraments:[self getRequestParament] showHUD:YES success:^(id responseObject) {
        [touristTableView reloadData];
    } failure:^(NSError *error) {
        
    }];
}

-(NSDictionary *)getRequestParament{
    NSDictionary *dic = [[NSDictionary alloc]init];
    return dic;
}

@end
