//
//  TouristDetailTableViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "TouristDetailTableViewCell.h"

@implementation TouristDetailTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier frame:(CGRect)frame{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        self.contentView.frame = self.frame;
        [self creatSubview];
    }
    return self;
}

-(void)creatSubview{
    BaseLabel *titleLabel = [[BaseLabel alloc]init];
    titleLabel.frame = CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.height/6);
    titleLabel.backgroundColor = [UIColor redColor];
    [self.contentView addSubview:titleLabel];
    
    BaseLabel *heardLabel = [[BaseLabel alloc]init];
    heardLabel.frame = CGRectMake(titleLabel.frame.origin.x, CGRectGetMaxY(titleLabel.frame), titleLabel.frame.size.width, titleLabel.frame.size.height);
    heardLabel.backgroundColor = [UIColor greenColor];
    [self.contentView addSubview:heardLabel];
    
    BaseImageView *imageView = [[BaseImageView alloc]init];
    imageView.frame = CGRectMake(heardLabel.frame.origin.x, CGRectGetMaxY(heardLabel.frame), heardLabel.frame.size.width, self.contentView.frame.size.height/2);
    imageView.backgroundColor = [UIColor magentaColor];
    [self.contentView addSubview:imageView];
    
    BaseLabel *footLabel = [[BaseLabel alloc]init];
    footLabel.frame = CGRectMake(imageView.frame.origin.x, CGRectGetMaxY(imageView.frame), imageView.frame.size.width, heardLabel.frame.size.height);
    footLabel.backgroundColor = [UIColor blueColor];
    [self.contentView addSubview:footLabel];
}

@end
