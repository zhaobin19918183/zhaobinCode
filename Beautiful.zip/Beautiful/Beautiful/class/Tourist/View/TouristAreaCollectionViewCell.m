//
//  TouristAreaCollectionViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "TouristAreaCollectionViewCell.h"
/**
 * 機能名　　　　：観光地
 * 機能概要　　　：観光地の名称リストcell
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation TouristAreaCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        self.contentView.frame = self.frame;
        [self createSubviews];
    }
    return self;
}

-(void)createSubviews{
    BaseImageView *imageView = [[BaseImageView alloc]init];
    imageView.frame = CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.width);
    [imageView setFillet:0];
    imageView.backgroundColor = [UIColor redColor];
    [self.contentView addSubview:imageView];
    
    BaseLabel *addresLabel = [[BaseLabel alloc]init];
    addresLabel.frame = CGRectMake(0, CGRectGetMaxY(imageView.frame), imageView.frame.size.width, self.contentView.frame.size.height-CGRectGetMaxY(imageView.frame));
    [addresLabel setText:@"addres" textAlignment:BaseLabelCenter];
    [self.contentView addSubview:addresLabel];
}

@end
