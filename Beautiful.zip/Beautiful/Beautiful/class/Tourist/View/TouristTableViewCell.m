//
//  TouristTableViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "TouristTableViewCell.h"
/**
 * 機能名　　　　：観光地
 * 機能概要　　　：観光地リストcell
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation TouristTableViewCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier frame:(CGRect)frame{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        self.contentView.frame = self.frame;
        [self creatSubview];
    }
    return self;
}

-(void)creatSubview{
    BaseImageView *imageView = [[BaseImageView alloc]init];
    imageView.frame = CGRectMake(XSpan(4), YSpan(4), self.contentView.frame.size.width-XSpan(8), self.contentView.frame.size.height-YSpan(4));
    imageView.backgroundColor = [UIColor redColor];
    [self.contentView addSubview:imageView];
    
    BaseLabel *titleLabel = [[BaseLabel alloc]init];
    titleLabel.frame = CGRectMake(0, 0, imageView.frame.size.width, YSpan(30));
    titleLabel.center = imageView.center;
    [titleLabel setText:@"title" textAlignment:BaseLabelCenter];
    [imageView addSubview:titleLabel];
}

@end
