//
//  HelperManager.swift
//  Portal
//
//  Created by Kilin on 16/3/15.
//  Copyright © 2016年 Innocellence. All rights reserved.
//

import UIKit

struct HelperManager
{
    static let sharedManager = HelperManager()
    
    private init() {}
    
    static func convertAnyObjectToString <T> (anyObject : T) -> String
    {
        let resultData : NSData!
        do{
            resultData = try NSJSONSerialization.dataWithJSONObject(anyObject as! AnyObject, options: .PrettyPrinted)
        }catch
        {
            resultData = nil
        }
        
        return String(data: resultData, encoding: NSUTF8StringEncoding)!
    }
    
    static func convertStringToAnyObject(string : String) -> AnyObject?
    {
        guard let data = string.dataUsingEncoding(NSUTF8StringEncoding) else
        {
            return nil
        }
        
        let resultAnyObject : AnyObject?
        do{
            resultAnyObject = try NSJSONSerialization.JSONObjectWithData(data, options: .AllowFragments)
        }catch
        {
            resultAnyObject = nil
        }
        
        return resultAnyObject
    }
    
    static func convertHTMLToTextString(html : String) -> String
    {
        let scanner = NSScanner(string: html)
        var text : NSString?
        var convertedHTML : String = ""
        
        while scanner.atEnd == false
        {
            scanner.scanUpToString("<string", intoString: nil)
            scanner.scanUpToString(">", intoString: &text)
            convertedHTML = html.stringByReplacingOccurrencesOfString("\(text!)>", withString: "")
        }
        
        convertedHTML = convertedHTML.stringByReplacingOccurrencesOfString("</string>", withString: "")
        
        let characterSet = NSCharacterSet.whitespaceAndNewlineCharacterSet()
        convertedHTML = convertedHTML.stringByTrimmingCharactersInSet(characterSet)
        convertedHTML = convertedHTML.stringByReplacingOccurrencesOfString("\r", withString: "")
        convertedHTML = convertedHTML.stringByReplacingOccurrencesOfString("\n", withString: "")
        convertedHTML = convertedHTML.stringByReplacingOccurrencesOfString("&nbsp", withString: "")
        convertedHTML = convertedHTML.stringByReplacingOccurrencesOfString("&ldquo;", withString: "")
        convertedHTML = convertedHTML.stringByReplacingOccurrencesOfString("&rdquo;", withString: "")
        
        return convertedHTML
    }
    
    static func convertDateToHomeNewsCellString(date : NSDate?) -> (full : String , day : String , month : String)
    {
        if let avaliableDate = date
        {
            let formatter = NSDateFormatter()
            
            formatter.dateFormat = "yyyy"
            let year = formatter.stringFromDate(avaliableDate)
            
            formatter.dateFormat = "MM"
            var month = formatter.stringFromDate(avaliableDate)
            
            formatter.dateFormat = "dd"
            let day = formatter.stringFromDate(avaliableDate)
            
            switch month {
            case "01":
                month = "January"
            case "02":
                month = "February"
            case "03":
                month = "March"
            case "04":
                month = "April"
            case "05":
                month = "May"
            case "06":
                month = "June"
            case "07":
                month = "July"
            case "08":
                month = "August"
            case "09":
                month = "September"
            case "10":
                month = "October"
            case "11":
                month = "November"
            case "12":
                month = "December"
            default:break
            }
            
            return ("\(day) \(month) \(year)","\(day)","\(month)")
        }else
        {
            return ("无效的日期格式","无效的日期","无效的日期")
        }
    }
}









