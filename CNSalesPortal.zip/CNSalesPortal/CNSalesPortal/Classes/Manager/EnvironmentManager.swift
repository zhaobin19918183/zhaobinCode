//
//  EnvironmentManager.swift
//  CNSalesPortal
//
//  Created by Kilin on 16/5/20.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

struct EnvironmentManager
{
    static let sharedManager = EnvironmentManager()
    
    static var settingModel : SettingModel = {
        if let settings = SettingsDAO.retrive()
        {
            let settingModel = SettingModel.convertFromEntity(settings)
            return settingModel
        }else
        {
            let settingModel = SettingModel.convertFromPlist(NSBundle.mainBundle().pathForResource("SP_Settings", ofType: "plist")!)
            SettingsDAO.create(settingModel)
            return settingModel
        }
    }()
    
    private init(){}
}

//MARK:- Settings
extension EnvironmentManager
{
    static func getURLs() -> [String]
    {
        return [self.settingModel.urlLOCAL! ,self.settingModel.urlDEV! ,self.settingModel.urlQA! ,self.settingModel.urlPRD!]
    }
    
    static func getRootURL() -> String
    {
        let base64String = self.settingModel.rootURL()
        let base64Data   = NSData(base64EncodedString: base64String, options: .IgnoreUnknownCharacters)!
        return String(data: base64Data, encoding: NSUTF8StringEncoding)!
    }
    
    static func isLocalEnvironment() -> Bool
    {
        return self.settingModel.isLocalEnvironment()
    }
    
    static func updateEnvironment(url : String , completion : () -> Void)
    {
        let environment = self.settingModel.getEnvironment(url)
        self.settingModel.environment = environment
        SettingsDAO.update(self.settingModel)
        completion()
    }
    
    static func getCurrentUser() -> String?
    {
        return self.settingModel.localUser
    }
    
    static func updateLocalUser(user : String , completion : () -> Void)
    {
        self.settingModel.localUser = user
        SettingsDAO.update(self.settingModel)
        completion()
    }
}

//MARK:- Folder
extension EnvironmentManager
{
    static func generateFolders()
    {
        EnvironmentManager.generateForlderWith(PATH_FOLDER_COREDATA)
        EnvironmentManager.generateForlderWith(PATH_FOLDER_APP)
        EnvironmentManager.generateForlderWith(PATH_FOLDER_LOGGER)
    }
    
    static func generateForlderWith(path : String)
    {
        let fileManager = NSFileManager.defaultManager()
        
        var isDir : ObjCBool = true
        if !fileManager.fileExistsAtPath(path, isDirectory: &isDir)
        {
            let attributes = [ NSFileProtectionKey : NSFileProtectionComplete]
            do {
                try fileManager.createDirectoryAtPath(path, withIntermediateDirectories: true, attributes: attributes)
            }catch
            {
                print("Create Folder Directory Failed")
            }
        }
    }
    
    static func deleteFileWith(path : String)
    {
        let fileManager = NSFileManager.defaultManager()
        do{
            try fileManager.removeItemAtPath(path)
        }catch
        {
            print("Delete File Failed")
        }
    }
    
    static func clearFolderWith(path : String)
    {
        let fileManager = NSFileManager.defaultManager()
        
        var fileNameArray = NSArray()
        do{
            fileNameArray = try fileManager.contentsOfDirectoryAtPath(path)
        }catch
        {
            print("Folder is empty")
        }
        
        fileNameArray.enumerateObjectsUsingBlock { (obj, idx, stop) in
            do{
                try fileManager.removeItemAtPath(path + "/" + (obj as! String))
            }catch
            {
                print("Delete single file failed")
            }
        }
    }
}








