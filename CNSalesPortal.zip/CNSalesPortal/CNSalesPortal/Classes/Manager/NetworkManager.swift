//
//  NetworkManager.swift
//  Portal
//
//  Created by Kilin on 16/3/15.
//  Copyright © 2016年 Innocellence. All rights reserved.
//

import UIKit
import Alamofire

typealias CompletionHandlerString   = Alamofire.Response<String, NSError> -> Void
typealias CompletionHandlerJSON     = Alamofire.Response<AnyObject, NSError> -> Void
typealias CompletionHandlerResponse = (request:NSURLRequest?,response: NSHTTPURLResponse?,data: NSData?,error : NSError?) -> Void

struct NetworkManager
{
    static let sharedManager = NetworkManager()
    
    private let manager : Manager
    private var networkReachabilityManager : NetworkReachabilityManager! = NetworkReachabilityManager()
    
    private init()
    {
        let configuration = NSURLSessionConfiguration.defaultSessionConfiguration()
        configuration.HTTPAdditionalHeaders = Manager.defaultHTTPHeaders
        configuration.timeoutIntervalForRequest = 300
        self.manager = Manager(configuration: configuration, delegate: Manager.SessionDelegate(), serverTrustPolicyManager: nil)
        
        self.addAuthenticationChallenge()
        self.networkReachabilityManager.startListening()
    }
    
    private func addAuthenticationChallenge()
    {
        self.manager.delegate.sessionDidReceiveChallenge = { session, challenge in
            var disposition: NSURLSessionAuthChallengeDisposition = .PerformDefaultHandling
            var credential: NSURLCredential?
            
            if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust {
                disposition = NSURLSessionAuthChallengeDisposition.UseCredential
                credential = NSURLCredential(forTrust: challenge.protectionSpace.serverTrust!)
            } else {
                if challenge.previousFailureCount > 0 {
                    disposition = .CancelAuthenticationChallenge
                } else {
                    if let identify = AccountManager.identify
                    {
                        credential = NSURLCredential(identity: identify, certificates: nil, persistence: .ForSession)
                    }
                    
                    if credential != nil {
                        disposition = .UseCredential
                    }
                }
            }
            return (disposition, credential)
        }
    }
}

//MARK: LISTENING
extension NetworkManager
{
    func isNetworkEnable() -> Bool
    {
        if let isReachable = self.networkReachabilityManager?.isReachable
        {
            return isReachable
        }else
        {
            return false
        }
    }
}

//MARK: NETWORK FUNCTIONS
extension NetworkManager
{
    func get(URL urlString : String , Parameters parameters : [String : AnyObject]? , CompletionHandlerString completionString : CompletionHandlerString)
    {
        manager
            .request(.GET, urlString, parameters: parameters, encoding: .JSON)
            .authenticate(user: AccountManager.username()!, password: AccountManager.password()!)
            .responseString { (response) in
                completionString(response)
        }
    }
    
    func download(URL urlString : String , CompleteBytes completeBytes : (completeBytes : Int) -> (), CompletionHandlerResponse completion : CompletionHandlerResponse)
    {
        let destination = Alamofire.Request.suggestedDownloadDestination(directory: .CachesDirectory, domain: .UserDomainMask)
        manager
            .download(.GET, urlString, destination: destination)
            .progress { (bytesRead, totalBytesRead, totalBytesExpectedToRead) -> Void in
                dispatch_async(dispatch_get_main_queue(), {
                    completeBytes(completeBytes: Int(totalBytesRead))
                })
            }.response { (request, response, data, error) in
                completion(request: request, response: response, data: data, error: error)
        }
    }
    
    func post(URL urlString : String, Parameters parameters : [String : AnyObject]? , CompletionHandlerString completionString : CompletionHandlerString)
    {
        manager
            .request(.POST , urlString, parameters: parameters , encoding: .JSON)
            .responseString { (response) in
                completionString(response)
        }
    }
    
    func upload(URL urlString : String, uploadFileURL : NSURL , completion : CompletionHandlerString)
    {
        manager
            .upload(.POST, urlString, file: uploadFileURL)
            .validate()
            .responseString { (response) in
                completion(response)
        }
    }
    
    func uploadMultipartForm(URL urlString : String, uploadFileURL : NSURL , completion : CompletionHandlerString)
    {
        manager
            .upload(.POST, urlString ,
            multipartFormData: { multipartFormData in
                multipartFormData.appendBodyPart(fileURL: uploadFileURL, name: "uploadFile")
            },
            encodingCompletion: { encodingResult in
                switch encodingResult {
                case .Success(let upload, _, _):
                    upload.responseString { response in
                        completion(response)
                    }
                case .Failure(let encodingError):
                    print(encodingError)
                }
            }
        )
    }
}












