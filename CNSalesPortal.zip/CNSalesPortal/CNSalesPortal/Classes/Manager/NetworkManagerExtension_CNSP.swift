//
//  NetworkManagerExtension_CNSP.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/5/17.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit
import Alamofire

let SOAGAuthenticationError1 = "<message>authentication failed</message>"
let SOAGAuthenticationError2 = "policyResult status=\"Authentication Required\""
let SOAGAuthenticationError3 = "policyResult status=\"Authentication Failed\""
let SOAGPolicyError          = "policyResult status=\""

extension NetworkManager
{
    static func getAppSyncURLString() -> String
    {
        return EnvironmentManager.getRootURL() + "lcsp/api/innocellence.salesportal.engine/modulesapi?active=true&userAccount=" + AccountManager.username()! + "&parameters=" + AppDAO.retriveAppVersions()
    }
    
    static func getTheFirstThreeNewsURLString()-> String
    {
        return EnvironmentManager.getRootURL() + "lcsp/api/innocellence.salesportal.engine/newsapi?active=true&userAccount=" +
            AccountManager.username()! + "&parameters=" + NewsDAO.retriveNewsVersions() + "&count=3"
    }
    
    static func getNewsBodyURLString(newsID:String)->String
    {
        return EnvironmentManager.getRootURL() + "lcsp/api/innocellence.salesportal.engine/newsapi?id=" + newsID
    }
    
    static func getPackageDownloadURLString(package : String) -> String
    {
        return EnvironmentManager.getRootURL() + "lcsp/media?file=" + package
    }
}

extension NetworkManager
{
    enum ResponseState
    {
        case AuthenRequired     //SOAG Required Authentation
        case SOAGPolicyError    //SOAG Policy Error
        case OtherError         //Other Error & Status Code != 200
        case ResponseDataError  //Status Code == 200 but can not convert response data to json object
        case Timeout            //Timeout
        case Success            //Success
    }
    
    static func checkResponse(response : Response<String, NSError>) -> (state :ResponseState , result : AnyObject?)
    {
        if let timeoutCode = response.result.error?.code where timeoutCode == -1001
        {
            return (ResponseState.Timeout , nil)
        }

        if let responseString = response.result.value
        {
            if response.response?.statusCode != 200
            {
                if responseString.containsString(SOAGAuthenticationError1) || responseString.containsString(SOAGAuthenticationError2) || responseString.containsString(SOAGAuthenticationError3)
                {
                    return (ResponseState.AuthenRequired , nil)
                }else if responseString.containsString(SOAGPolicyError)
                {
                    return (ResponseState.SOAGPolicyError , nil)
                }else
                {
                    return (ResponseState.OtherError , nil)
                }
            }else
            {
                if let result = HelperManager.convertStringToAnyObject(responseString)
                {
                    return (ResponseState.Success , result)
                }else
                {
                    return (ResponseState.ResponseDataError , nil)
                }
            }
        }else
        {
            return (ResponseState.ResponseDataError , nil)
        }
    }
}