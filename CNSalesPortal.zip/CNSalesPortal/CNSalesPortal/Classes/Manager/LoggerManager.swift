//
//  LoggerManager.swift
//  CN SalesPortal
//
//  Created by Zhao.bin on 16/7/4.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

struct LoggerManager
{
    private static let formatter : NSDateFormatter = {
        let formatter        = NSDateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        formatter.timeZone   = NSTimeZone(forSecondsFromGMT: 3600 * 8)
        return formatter
    }()
    
    private static let filePath : String = {
        let timeString = formatter.stringFromDate(NSDate())
        return PATH_FOLDER_LOGGER + "/\(timeString).txt"
    }()
    
    static func createRecordFile()
    {
        let record = "Logger Begin"
        do{
            try record.writeToFile(self.filePath, atomically: true, encoding: NSUTF8StringEncoding)
        }catch { }
    }
    
    static func appendLogger(anyObject : AnyObject , file : String = #file , line : Int = #line , function : String = #function)
    {
        var record = "FILE : \(file)\n"
        record.appendContentsOf("LINE : \(line)\n")
        record.appendContentsOf("FUNC : \(function)\n")
        record.appendContentsOf("DATE : \(formatter.stringFromDate(NSDate()))\n")
        record.appendContentsOf("MESSAGE : \(String(anyObject))")
        
        var records = try! String(contentsOfFile: self.filePath)
        records.appendContentsOf("\n")
        records.appendContentsOf("\n")
        records.appendContentsOf("\n")
        records.appendContentsOf(record)
        do{
            try records.writeToFile(self.filePath, atomically: true, encoding: NSUTF8StringEncoding)
        }catch { }
    }
}
