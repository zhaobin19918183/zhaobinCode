//
//  AccountManager.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/5/17.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

struct AccountManager
{
    static func username() -> String?
    {
        if EnvironmentManager.isLocalEnvironment()
        {
            //TODO:
//            return EnvironmentManager.defaultUser();
            return ""
        }else
        {
            guard LYKeyChainManager.getLillyAccountUserIdFromKeychain() != nil else
            {
                return ""
            }
            
            return LYKeyChainManager.getLillyAccountUserIdFromKeychain()
        }
    }
    
    static func password() -> String?
    {
        if EnvironmentManager.isLocalEnvironment()
        {
            return ""
        }else
        {
            guard LYKeyChainManager.getLillyAccountPasswordFromKeychain() != nil else
            {
                return ""
            }
    
            return LYKeyChainManager.getLillyAccountPasswordFromKeychain()
        }
    }
    
    static var identify : SecIdentityRef?
    {
        guard LYKeyChainManager.getLillyUserIdentityCopyFromKeychain() != nil else
        {
            return nil
        }
        
        return LYKeyChainManager.getLillyUserIdentityCopyFromKeychain().takeUnretainedValue()
    }
}
