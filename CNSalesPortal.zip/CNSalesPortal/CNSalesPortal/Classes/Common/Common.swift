//
//  Common.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/5/18.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

//PATH
//Level - 1
let ROOTPATH  = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true).first! as String
let TEMPPATH  = NSSearchPathForDirectoriesInDomains(.CachesDirectory, .UserDomainMask, true).first! as String

//Level - 2
let PATH_FOLDER_COREDATA = ROOTPATH + "/CoreData/"
let PATH_FOLDER_APP      = ROOTPATH + "/APP/"
let PATH_FOLDER_LOGGER   = ROOTPATH + "/Logger/"

//Level - 3
let PATH_FILE_COREDATA   = PATH_FOLDER_COREDATA + "CNSalesPortal_CoreData.Sqlite"


let PROJECT_VERSION      = Double((NSBundle.mainBundle().infoDictionary?["CFBundleShortVersionString"])! as! String)!







