//
//  NavigationController.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/7/6.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class NavigationController: UINavigationController  {

    @IBOutlet weak var bar: UINavigationBar!

    var tapGesture : UITapGestureRecognizer?
    var isTapAdded = false
    var avaliableTapCount = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.navigationBarTapped(_:)))
        self.addTapGesture()
    }
    
    func addTapGesture()
    {
        if isTapAdded == false
        {
            self.bar.addGestureRecognizer(self.tapGesture!)
            isTapAdded = true
        }
    }
    
    func removeTapGesture()
    {
        if isTapAdded == true
        {
            self.bar.removeGestureRecognizer(self.tapGesture!)
            isTapAdded = false
        }
    }
    
    func navigationBarTapped(sender : UITapGestureRecognizer)
    {
        let touchPosition = sender.locationInView(sender.view)
        if avaliableTapCount >= 0 && avaliableTapCount < 5 && touchPosition.x > 0 && touchPosition.x < 100
        {
            avaliableTapCount += 1
        }else if avaliableTapCount >= 5 && avaliableTapCount < 10 && touchPosition.x > 900 && touchPosition.x < 1024
        {
            avaliableTapCount += 1
        }else if avaliableTapCount >= 10 && avaliableTapCount < 13 && touchPosition.x > 420 && touchPosition.x < 600
        {
            avaliableTapCount += 1
            if avaliableTapCount == 13
            {
                let homeViewController = self.visibleViewController as! HomeViewController
                homeViewController.displayDevelopmentScene()
            }
        }else
        {
            avaliableTapCount = 0
        }
    }
}
