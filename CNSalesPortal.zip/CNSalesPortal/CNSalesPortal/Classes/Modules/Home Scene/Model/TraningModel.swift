//
//  TraningModel.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/6/3.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

struct TraningModel
{
    var identify        : NSNumber?
    var navigationLink  : String?
    var order           : NSNumber?
    var title           : String?
    var version         : NSNumber?
    
    static func conventDicToModel(traningInfo : [String : AnyObject]) -> TraningModel
    {
        var model            = TraningModel()
        model.identify       = traningInfo["Id"] as? NSNumber
        model.navigationLink = traningInfo["NavigationLink"] as? String
        model.title          = traningInfo["Title"] as? String
        
        if let order = traningInfo["Order"] as? NSNumber
        {
            model.order          = order
        }else
        {
            model.order          = 99999
        }
        
        if let versionString = traningInfo["Version"] as? String
        {
            model.version        = Double(versionString)
        }else
        {
            model.version        = 0
        }
        
        return model
    }
}


struct TraningModels
{
    var models = [TraningModel]()
}

extension TraningModels
{
    mutating func processSyncedData(informations : [String : AnyObject])
    {
        let modules = informations["trainings"] as! NSArray
        
        self.models = modules.map { (traningDic) -> TraningModel in
            let model = TraningModel.conventDicToModel(traningDic as! [String : AnyObject])
            TraningDAO.updateTraningWith(model)
            return model
        }
    }
    
    mutating func loadModels()
    {
        if let models = TraningDAO.retriveTranings()
        {
            self.models = models.map({
                TraningModel(identify: $0.identify!, navigationLink: $0.navigationLink!, order: $0.order!, title: $0.title, version: $0.version)
            })
        }
    }
}


