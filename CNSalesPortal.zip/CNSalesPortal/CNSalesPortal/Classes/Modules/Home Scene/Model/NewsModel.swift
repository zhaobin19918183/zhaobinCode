//
//  NewsModel.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/7/7.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

struct NewsModel
{
    var body                   : String?
    var file                   : String?
    var image                  : String?
    var title                  : String?
    var category               : String?
    var attachment             : String?
    
    var createTime             : NSDate?
    
    var isRead                 : NSNumber?
    var version                : NSNumber?
    var identifier             : NSNumber?
    var isBodyDownloadComplete : NSNumber?
    
    static func convertFrom(dictionary : [String : AnyObject]) -> NewsModel
    {
        var model = NewsModel()
        model.body                   = dictionary["Body"]        as? String
        model.file                   = dictionary["File"]        as? String
        model.title                  = dictionary["Title"]       as? String
        model.category               = dictionary["Catagory"]    as? String
        model.attachment             = dictionary["Attachment"]  as? String
        model.image                  = dictionary["Image"]       as? String
        
        if let dateString = dictionary["CreateTime"]  as? String
        {
            let formatter            = NSDateFormatter()
            formatter.dateFormat     = "yyyy-MM-dd\'T\'HH:mm:ss"
            formatter.timeZone       = NSTimeZone(forSecondsFromGMT: 3600*8)
            let date                 = formatter.dateFromString(dateString)
            model.createTime         = date
        }else
        {
            model.createTime         = NSDate()
        }
        
        model.identifier             = dictionary["Id"]          as? NSNumber
        model.isRead                 = false
        model.isBodyDownloadComplete = false
        
        if let version = dictionary["Version"] as? NSNumber
        {
            model.version = version
        }else
        {
            model.version = 1.0
        }
        
        return model
    }
    
    static func convertFrom(entity : News) -> NewsModel
    {
        var model = NewsModel()
        model.body                   = entity.body
        model.file                   = entity.file
        model.title                  = entity.title
        model.category               = entity.category
        model.attachment             = entity.attachment
        model.image                  = entity.image
        model.createTime             = entity.createTime
        model.identifier             = entity.identifier
        model.isRead                 = entity.isRead
        model.isBodyDownloadComplete = entity.isBodyDownloadComplete
        model.version                = entity.version
        
        return model
    }
}

struct NewsModels
{
    var models = [NewsModel]()
    
    mutating func processSyncedData(informations : [[String : AnyObject]])
    {
        self.models = [NewsModel]()
        for (_ , dictionary) in informations.enumerate()
        {
            let model = NewsModel.convertFrom(dictionary)
            self.models.append(model)
        }
        
        NewsDAO.update(self.models)
        
        //NewsDAO.updateMultipleNewsWith(self.models)
    }
    
    mutating func loadModels()
    {
        if let newsAll = NewsDAO.retriveAllNews()
        {
            self.models = newsAll.map({ (news) -> NewsModel in
                return NewsModel.convertFrom(news)
            })
        }
    }
}












