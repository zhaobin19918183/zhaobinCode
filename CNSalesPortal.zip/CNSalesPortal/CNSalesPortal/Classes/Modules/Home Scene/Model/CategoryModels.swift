//
//  CategoryModel.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/5/18.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import Foundation

struct CategoryModel
{
    var index : Int
    var name : String
}

struct CategoryModels
{
    var models = [CategoryModel]()
}

extension CategoryModels
{
    mutating func loadModels()
    {
        if let models = CategoryDAO.retriveAllCategories()
        {
            self.models = models.map({
                CategoryModel(index: $0.index!.integerValue, name: $0.name!)
            })
        }
    }
    
    mutating func processSyncedData(informations : [String : AnyObject])
    {
        if let categories = informations["categories"] as? [String]
        {
            self.models = [CategoryModel]()
            for (index , value) in categories.enumerate()
            {
                self.models.append(CategoryModel(index: index, name: value))
            }
            CategoryDAO.updateMultipleCategoryWith(self.models)
        }
    }
}


