//
//  AppModel.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/5/18.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

struct AppModel
{
    var appID: NSNumber?
    var order: NSNumber?
    var category: NSNumber?
    var fileSize: NSNumber?
    
    var version: NSNumber?
    
    var isNew: NSNumber?
    var isPopupLink: NSNumber?
    var isMandatoryPackage: NSNumber?
    var isMandatoryVersion: NSNumber?
    var isPackageDownloadComplete : NSNumber?
    
    var icon: String?
    var title: String?
    var package: String?
    var userList: String?
    var checkCode: String?
    var createTime: String?
    var appDescription: String?
    var navigationLink: String?
    
    func unzipedAPPFolderName() -> String
    {
        return "\(self.appID!)_\(self.title!)"
    }
    
    func zipFileName() -> String
    {
        guard let zipFileName = self.package?.componentsSeparatedByString("/").last else
        {
            return ""
        }
        
        return zipFileName
    }
    
    static func convertEntityToModel(app : App) -> AppModel
    {
        var model                       = AppModel()
        model.appID                     = app.appID
        model.order                     = app.order
        model.category                  = app.category
        model.fileSize                  = app.fileSize
        model.version                   = app.version
        model.isNew                     = app.isNew
        model.isPopupLink               = app.isPopupLink
        model.isMandatoryPackage        = app.isMandatoryPackage
        model.isMandatoryVersion        = app.isMandatoryVersion
        model.icon                      = app.icon
        model.title                     = app.title
        model.package                   = app.package
        model.userList                  = app.userList
        model.checkCode                 = app.checkCode
        model.createTime                = app.createTime
        model.appDescription            = app.appDescription
        model.navigationLink            = app.navigationLink
        model.isPackageDownloadComplete = app.isPackageDownloadComplete
        
        return model
    }
    
    static func convertDictionaryToModel(appInformation : [String : AnyObject]) -> AppModel
    {
        var model                = AppModel()
        model.appID              = appInformation["Id"] as? NSNumber
        model.fileSize           = appInformation["FileSize"] as? NSNumber
        model.isNew              = appInformation["isNew"] as? NSNumber
        model.isPopupLink        = appInformation["IsPopupLink"] as? NSNumber
        model.isMandatoryPackage = appInformation["IsMandatoryPackage"] as? NSNumber
        model.isMandatoryVersion = appInformation["IsMandatoryVersion"] as? NSNumber
        
        model.icon               = appInformation["Icon"] as? String
        model.title              = appInformation["Title"] as? String
        model.package            = appInformation["Package"] as? String
        model.userList           = appInformation["UserList"] as? String
        model.checkCode          = appInformation["CheckCode"] as? String
        model.createTime         = appInformation["CreateTime"] as? String
        model.appDescription     = appInformation["Description"] as? String
        model.navigationLink     = appInformation["NavigationLink"] as? String
        
        if let order = appInformation["Order"] as? NSNumber
        {
            model.order          = order
        }else
        {
            model.order          = 99999
        }
        
        if let category = appInformation["Category"] as? String
        {
            model.category       = Int(category)
        }
        else
        {
            model.category       = -1
        }
        
        
        if let versionString = appInformation["Version"] as? String
        {
            model.version        = Double(versionString)
        }else
        {
            model.version        = 0
        }
        
        model.isPackageDownloadComplete = false
        
        return model
    }
}

struct AppModels
{
    var models = [[AppModel]]()
}

extension AppModels
{
    mutating func processSyncedData(informations : [String : AnyObject])
    {
        let modules   = informations["modules"] as! [[String : AnyObject]]
        var newModels = [AppModel]()
        
        for (_ , value) in modules.enumerate()
        {
            let model = AppModel.convertDictionaryToModel(value)
            newModels.append(model)
        }
        AppDAO.updateMultipleAppWith(newModels)
    }
    
    mutating func loadModels()
    {
        let categories = CategoryDAO.retriveAllCategories()!
        
        self.models = categories.map { (category) -> [AppModel] in
            let apps = AppDAO.retriveCategoryedAppWith(category.index!)!
            var models = [AppModel]()
            for (_ , app) in apps.enumerate()
            {
                models.append(AppModel.convertEntityToModel(app))
            }
            return models
        }
    }
    
    func loadModelFromCoreData(model : AppModel) -> AppModel
    {
        if let app = AppDAO.retriveAppWith(model.appID!)
        {
            return AppModel.convertEntityToModel(app)
        }else
        {
            return AppModel()
        }
    }
}
















