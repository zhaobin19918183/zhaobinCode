//
//  HomeCollectionViewCell.swift
//  CNSalesPortal
//
//  Created by Kilin on 16/5/20.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell
{
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var button: UIButton!
    private var tipsLabel : UILabel?
    private var model : AppModel!
    
    private let handler = HomeCollectionViewCellHandler()
}

//MARK:- SETUP FUNCTIONS
extension HomeCollectionViewCell
{
    func setupWith(model : AppModel)
    {
        self.model = model
        self.setupImageWith(self.model.icon!)
        self.setupTitleWith(self.model.title!)
        
        self.updateApp()
    }
    
    private func setupImageWith(imageBase64String : String)
    {
        let decodeData = NSData(base64EncodedString: imageBase64String, options: .IgnoreUnknownCharacters)
        let image = UIImage(data: decodeData!)
        self.imageView.image = image
    }
    
    private func setupTitleWith(title : String)
    {
        self.titleLabel.text = title
    }
}

//MARK:- UPDATE APP FUNCTIONS
extension HomeCollectionViewCell
{
    func updateApp()
    {
        if self.handler.checkPackageUpdatable(self.model)
        {
            self.startUpdateApp()
        }
    }
    
    private func startUpdateApp()
    {
        self.button.enabled = false
        
        let progressView = self.createPorgressView()
        self.imageView!.addSubview(progressView)
        
        self.handler.startDownloadPackage(self.model, progress: { (progress) in
            progressView.progress = CGFloat(progress)
        }) { (isSuccess) in
            progressView.removeFromSuperview()
            self.processDownloadPackageCompleted(isSuccess)
        }
    }
    
    private func processDownloadPackageCompleted(isSuccess : Bool)
    {
        self.tipsLabel = self.createTipsLabel()
        self.imageView.addSubview(self.tipsLabel!)
        
        if isSuccess == true
        {
            self.tipsLabel!.text = NSLocalizedString("I_CollectionCell_Unzipping", comment: "")
            self.handler.startUnzipPackage(self.model, completion: { (isSuccess) in
                self.processUnzipComplete(isSuccess)
            })
        }else
        {
            self.tipsLabel!.text = NSLocalizedString("I_CollectionCell_DownloadFailed", comment: "")
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, Int64(2.0 * Double(NSEC_PER_SEC))), dispatch_get_main_queue(), {
                self.button.enabled = true
                self.tipsLabel?.removeFromSuperview()
            })
        }
    }
    
    private func processUnzipComplete(isSuccess : Bool)
    {
        var delayTime = 1.0
        
        if isSuccess == true
        {
            self.tipsLabel!.text = NSLocalizedString("I_CollectionCell_UnzipSuccess", comment: "")
            self.model.isPackageDownloadComplete = true
            AppDAO.updateAppWith(self.model)
        }else
        {
            self.tipsLabel!.text = NSLocalizedString("I_CollectionCell_UnzipFailure", comment: "")
            delayTime = 2.0
        }
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, Int64(delayTime * Double(NSEC_PER_SEC))), dispatch_get_main_queue(), {
            self.button.enabled = true
            self.tipsLabel?.removeFromSuperview()
        })
    }
    
    private func createPorgressView() -> SDTransparentPieProgressView
    {
        let progressView = SDTransparentPieProgressView.progressView() as! SDTransparentPieProgressView
        progressView.frame = self.imageView.frame
        progressView.progress = 0.0
        progressView.userInteractionEnabled = true
        
        //NOTE: IF THE CORNER RADIUS OF APP'S ICON CHANGED , THE layer.cornerRadius WILL BE CHANGED TOO.
        self.imageView.layer.cornerRadius = 20
        self.imageView.clipsToBounds = true
        
        return progressView
    }
    
    private func createTipsLabel() -> UILabel
    {
        let tipsLabel = UILabel(frame: CGRectMake(0,0,self.imageView.frame.size.width,self.imageView.frame.size.height))
        tipsLabel.backgroundColor = UIColor(red: 100.0/255.0, green: 100.0/255.0, blue: 100.0/255.0, alpha: 0.8)
        tipsLabel.textColor = UIColor.whiteColor()
        tipsLabel.textAlignment = .Center
        tipsLabel.numberOfLines = 2
        tipsLabel.userInteractionEnabled = true
        tipsLabel.font = UIFont(name: "DINPro-Regular", size: 13)
        
        return tipsLabel
    }
}

extension HomeCollectionViewCell
{
    @IBAction func buttonClicked(sender: AnyObject)
    {
        self.handler.checkAppStateAndUpdatable(self.model) {
            EnvironmentManager.clearFolderWith(TEMPPATH)
            self.updateApp()
        }
    }
}











