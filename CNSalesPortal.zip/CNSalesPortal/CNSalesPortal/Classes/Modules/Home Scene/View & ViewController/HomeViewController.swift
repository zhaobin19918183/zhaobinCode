//
//  HomeViewController.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/5/17.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

let NOTIFICATION_SCHEMELAUNCHAPP = "com.lilly.innocellence.cnsalesportal.schemeLaunchApp"

class HomeViewController: UIViewController , HUDOperable , AlertDisplayable , Developable ,UINavigationControllerDelegate
{
    var hud : MBProgressHUD = {
        let mbProgressHUD = MBProgressHUD()
        mbProgressHUD.minSize = CGSizeMake(160, 90)
        return mbProgressHUD
    }()
    
    @IBOutlet weak var homeNavigationItem: UINavigationItem!
    
    @IBOutlet weak var appsCollectionView: UICollectionView!
    @IBOutlet weak var newsTableView: UITableView!
    
    @IBOutlet weak var leftBackgroundeView: UIView!
    @IBOutlet weak var tipsLabel: UILabel!
    @IBOutlet var traningLabels: [UILabel]!
    
    private var viewModel : HomeViewModel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        LoggerManager.appendLogger("Come in Home view controller.")
        
        self.view.addSubview(self.hud)
        self.hideLeftBackgroundAndCollectionView()
        self.setupNavigationBarItem()
        self.addNotifications()
        self.navigationController?.delegate = self
        
        viewModel = HomeViewModel()
        viewModel.loadModelsCompletion = self.loadModelsCompletion
        
        appsCollectionView.delegate = viewModel
        appsCollectionView.dataSource = viewModel
        
        newsTableView.delegate = viewModel
        newsTableView.dataSource = viewModel
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, Int64(0.5 * Double(NSEC_PER_SEC))), dispatch_get_main_queue(), {
            if AppDelegate.isScheme == false
            {
                self.syncAppInformation()
            }else{
                self.showLeftBackgroundAndCollectionView()
            }
        })
    }
    
    @IBAction func allNewsAction(sender: UIButton)
    {
        let storyboard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        let newsViewController = storyboard.instantiateViewControllerWithIdentifier("NewsViewControllerID") as! NewsViewController
        self.navigationController?.pushViewController(newsViewController, animated:true)
    }
    
    private func showWarning(userInfo : AnyObject)
    {
        let title   = userInfo["WARNING_TITLE"] as! String
        let message = userInfo["WARNING_CONTENT"] as! String
        let confirmAction = UIAlertAction(title: NSLocalizedString("I_Common_OK", comment: ""), style: .Default, handler: nil)
        self.showAlertWith(title, message: message, confirmAction: confirmAction, cancelAction: nil)
    }
}

//MARK:- VIEWS SETUP
extension HomeViewController
{
    private func hideLeftBackgroundAndCollectionView()
    {
        self.leftBackgroundeView.hidden = true
        self.appsCollectionView.hidden = true
    }
    
    private func showLeftBackgroundAndCollectionView()
    {
        self.leftBackgroundeView.hidden = false
        self.appsCollectionView.hidden = false
    }
    
    private func setupNavigationBarItem()
    {
        let image = UIImage(contentsOfFile: NSBundle.mainBundle().pathForResource("P_Home_LillyLogo_96x52", ofType: ".png")!)
        let imageView = UIImageView(image: image)
        imageView.frame = CGRectMake(imageView.frame.origin.x, imageView.frame.origin.y, imageView.frame.size.width / 2 , imageView.frame.size.height / 2)
        let lillyLogoBarItem = UIBarButtonItem(customView: imageView)
        self.homeNavigationItem.leftBarButtonItem = lillyLogoBarItem
        
        let titleLabel = UILabel(frame: CGRectMake(0,0, 100, 30 ))
        titleLabel.font = UIFont(name: "DINPro-Regular", size: 20)
        titleLabel.text = "Sales Portal"
        titleLabel.textColor = UIColor.whiteColor()
        self.homeNavigationItem.titleView = titleLabel
    }
    
    private func setupTipsLabel(Hide hide : Bool)
    {
        self.tipsLabel.text = NSLocalizedString("I_Error_SOAG_Other", comment: "")
        self.tipsLabel.hidden = hide
    }
    
    private func setupTraningLabels()
    {
        for (index, model) in self.viewModel.traningModels.models.enumerate()
        {
            if index >= 3
            {
                return
            }
            self.traningLabels[index].text = model.title!
        }
    }
    
    func loadModelsCompletion()
    {
        self.appsCollectionView.reloadData()
        self.setupTraningLabels()
    }
    
    @IBAction func traningClicked(sender: UIButton)
    {
        let index = sender.tag
        let model = self.viewModel.traningModels.models[index]
        let url   = NSURL(string: model.navigationLink!)
        UIApplication.sharedApplication().openURL(url!)
    }
}

//MARK:- SYNC DATA
extension HomeViewController
{
    private func syncAppInformation()
    {
        guard NetworkManager.sharedManager.isNetworkEnable() else
        {
            LoggerManager.appendLogger("无网络，无法请求App信息。")
            self.newsTableView.hidden = true
            self.appsCollectionView.hidden = true
            self.leftBackgroundeView.hidden = true
            self.hudHideManuallyWith(NSLocalizedString("I_Error_SOAG_Network", comment: ""), duration: 2.0)
            return
        }
        
        self.hudAwaysShowIndicatorWith(NSLocalizedString("I_Home_Synchronizing", comment: ""))
        self.viewModel.startSyncAPPInformation { (state, isVersionError) in
            if isVersionError == true
            { 
                let title = NSLocalizedString("I_Home_TipsCNSPUpdatable_Title", comment: "")
                let message = NSLocalizedString("I_Home_TipsCNSPUpdatable_Content", comment: "")
                let confirmAction = UIAlertAction(title: NSLocalizedString("I_Common_OK", comment: ""), style: .Default, handler: { (action) in
                    exit(0)
                })
                self.showAlertWith(title, message: message, confirmAction: confirmAction, cancelAction: nil)
            }else
            {
                self.showSyncAppState(state)
            }
        }
    }
    
    private func syncNewsInformation()
    {
        guard NetworkManager.sharedManager.isNetworkEnable() else
        {
            LoggerManager.appendLogger("无网络，无法请求News信息。")
            return
        }
        
        self.viewModel.startSyncNewsInformation { (isSuccess) in
            self.viewModel.newsModels.loadModels()
            self.newsTableView.reloadData()
        }
    }
    
    private func showSyncAppState(state : NetworkManager.ResponseState)
    {
        switch state{
        case .AuthenRequired:
            self.hudHideManuallyWith(NSLocalizedString("I_Error_SOAG_Other", comment: ""), duration: 2.0)
            self.showLeftBackgroundAndCollectionView()
        case .SOAGPolicyError:
            self.hudHideManuallyWith(NSLocalizedString("I_Error_SOAG_Self", comment: ""), duration: 2.0)
            self.showLeftBackgroundAndCollectionView()
        case .OtherError:
            self.hudHideManuallyWith(NSLocalizedString("I_Error_SOAG_Other", comment: ""), duration: 2.0)
            self.setupTipsLabel(Hide: false)
        case .ResponseDataError:
            self.hudHideManuallyWith(NSLocalizedString("I_Error_SOAG_Data", comment: ""), duration: 2.0)
            self.showLeftBackgroundAndCollectionView()
        case .Timeout:
            self.hudHideManuallyWith(NSLocalizedString("I_Error_SOAG_Timeout", comment: ""), duration: 2.0)
            self.showLeftBackgroundAndCollectionView()
        case .Success:
            self.syncNewsInformation()
            self.hudHideManuallyWith(NSLocalizedString("I_Home_SynchronizationCompletion", comment: ""), duration: 0.5)
            self.showLeftBackgroundAndCollectionView()
        }
        
        if state != .OtherError
        {
            self.viewModel.loadModels()
        }
    }
}

//MARK:- NOTIFICATIONS
extension HomeViewController
{
    func addNotifications()
    {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(HomeViewController.homeCollectionViewNotification(_:)), name: NOTIFICATION_HOMECOLLECTIONVIEWCELL, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(HomeViewController.launchByScheme(_:)), name: NOTIFICATION_SCHEMELAUNCHAPP, object: nil)
    }
}

//MARK:- APP OPERATION FUNCTIONS
extension HomeViewController
{
    func homeCollectionViewNotification(sender : AnyObject)
    {
        let userInfo = sender.valueForKey("userInfo")!
        guard let type = userInfo["TYPE"] as? String else
        {
            return
        }
        
        switch type {
        case "LAUNCHAPP":
            let appID = userInfo["APP_ID"] as! NSNumber
            if let app = AppDAO.retriveAppWith(appID)
            {
                self.launchApp(AppModel.convertEntityToModel(app) , scheme: nil)
            }
        case "EXTERNAL":
            self.openExternalLink(userInfo)
        case "WARNING":
            self.showWarning(userInfo)
        default:
            print("DO NOTHING")
        }
    }
    
    private func launchApp(model : AppModel , scheme : String?)
    {
        let storyboard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        let hybridViewController = storyboard.instantiateViewControllerWithIdentifier("HybridViewControllerBundleID") as! HybridViewController
        self.presentViewController(hybridViewController, animated: true, completion: {
            hybridViewController.initialWebViewWith(model, scheme: scheme)
        })
    }
    
    private func openExternalLink(userInfo : AnyObject)
    {
        let externalLink = userInfo["EXTENRAL_LINK"] as! String
        if externalLink.lowercaseString.hasPrefix("http://") || externalLink.lowercaseString.hasPrefix("https://")
        {
            UIApplication.sharedApplication().openURL(NSURL(string: externalLink)!)
        }else if externalLink.lowercaseString.containsString("://")
        {
            let canOpenURL = UIApplication.sharedApplication().openURL(NSURL(string: externalLink)!)
            if canOpenURL == false
            {
                let confirmAction = UIAlertAction(title: NSLocalizedString("I_Common_OK", comment: ""), style: .Default, handler: nil)
                self.showAlertWith(NSLocalizedString("I_Home_OpenExternalTipsTitle", comment: ""), message: NSLocalizedString("I_Home_OpenExternalTipsContent", comment: ""), confirmAction: confirmAction, cancelAction: nil)
            }
        }else
        {
            let canOpenURL = UIApplication.sharedApplication().openURL(NSURL(string: externalLink)!)
            if canOpenURL == false
            {
                let confirmAction = UIAlertAction(title: NSLocalizedString("I_Common_OK", comment: ""), style: .Default, handler: nil)
                self.showAlertWith("无效链接", message: "无法打开外部链接，因为这是一个无效的链接。", confirmAction: confirmAction, cancelAction: nil)
            }
        }
    }
}

//MARK:-
extension HomeViewController
{
    func launchByScheme(notification : NSNotification)
    {
        let urlString = notification.object as? String
        self.displayHomeViewController(urlString)
    }
    
    private func displayHomeViewController(scheme : String?)
    {
        if self.navigationController?.visibleViewController == self
        {
            let seperatedArray = scheme?.componentsSeparatedByString("/")
            if seperatedArray?.count >= 3
            {
                let appName = seperatedArray![2] 
                if let app = AppDAO.retriveAppWith(appName)
                {
                    self.launchApp(AppModel.convertEntityToModel(app) , scheme: scheme)
                }else
                {
                    let message       = NSLocalizedString("I_Home_SchemeLaunchedAppNotExist", comment: "")
                    let confirmAction = UIAlertAction(title: NSLocalizedString("I_Common_OK", comment: ""), style: .Default, handler: nil)
                    self.showAlertWith("", message: message, confirmAction: confirmAction, cancelAction: nil)
                }
            }
        }else
        {
            if self.navigationController?.topViewController == self.navigationController?.visibleViewController
            {
                self.navigationController?.popToRootViewControllerAnimated(false)
                self.displayHomeViewController(scheme)
            }else
            {
                self.navigationController?.visibleViewController?.dismissViewControllerAnimated(true, completion: {
                    self.displayHomeViewController(scheme)
                })
            }
        }
    }
}

//MARK:- UINavigationController Delegate
extension HomeViewController
{
    func navigationController(navigationController: UINavigationController, didShowViewController viewController: UIViewController, animated: Bool)
    {
        let nController = navigationController as! NavigationController
        if viewController == self
        {
            nController.addTapGesture()
        }else
        {
            nController.removeTapGesture()
        }
    }
}




