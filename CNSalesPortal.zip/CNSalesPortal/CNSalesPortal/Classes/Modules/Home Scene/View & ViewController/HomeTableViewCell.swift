//
//  HomeTableViewCell.swift
//  CN SalesPortal
//
//  Created by Zhao.bin on 16/6/21.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class HomeTableViewCell: UITableViewCell {

    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var LatestInformationLabel: UILabel!
    @IBOutlet weak var backgroundImageView: UIImageView!
    
    @IBOutlet weak var dateLabel: UILabel!
  
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var grayView: UIView!
  
    var newsNetWorkDataArray = NSMutableArray()
    
    func enableLatestNewsTag()
    {
        self.LatestInformationLabel.hidden = false
    }
    
    func setupNews(model : NewsModel)
    {
        self.backgroundColor = UIColor.clearColor()
        if let imageString = model.image where imageString.characters.count > 0
        {
            let decodedData =
                NSData(base64EncodedString:imageString, options:NSDataBase64DecodingOptions())
            let decodedimage = UIImage(data: decodedData!)! as UIImage
            self.backgroundImageView.image = decodedimage
            self.dayLabel.hidden = true
            self.monthLabel.hidden = true
            self.grayView.backgroundColor = UIColor.blackColor().colorWithAlphaComponent(0.5)
        }else
        {
            self.dayLabel.hidden = false
            self.monthLabel.hidden = false
            self.grayView.backgroundColor = UIColor.blackColor().colorWithAlphaComponent(0.5)
        }
        
        self.titleLabel.text = model.title
        
        let dateInfor = HelperManager.convertDateToHomeNewsCellString(model.createTime)
        self.dateLabel.text = dateInfor.full
        self.dayLabel.text = dateInfor.day
        self.monthLabel.text = dateInfor.month
    }
}
