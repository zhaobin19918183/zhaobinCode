//
//  HomeCollectionReusableView.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/5/19.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class HomeCollectionReusableView: UICollectionReusableView
{
    @IBOutlet weak var titleLabel: UILabel!   
}
