//
//  SDTransparentPieProgressView.h
//  SDProgressView
//
//

#import "SDBaseProgressView.h"

@interface SDTransparentPieProgressView : SDBaseProgressView

@end