//
//  HomeViewModel.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/5/17.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class HomeViewModel : NSObject
{
    var appModels      = AppModels()
    var categoryModels = CategoryModels()
    var traningModels  = TraningModels()
    var newsModels     = NewsModels()
    
    var loadModelsCompletion : (() -> Void)?
}

//MARK:- UITableViewDataSource & UITableViewDelegate
extension HomeViewModel : UITableViewDataSource, UITableViewDelegate
{
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCellWithIdentifier("tableViewCell", forIndexPath: indexPath) as! HomeTableViewCell
        
        if indexPath.row == 0
        {
            cell.enableLatestNewsTag()
        }
        
        cell.setupNews(self.newsModels.models[indexPath.row])

        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
//        let storyboard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
//        let newsViewController = storyboard.instantiateViewControllerWithIdentifier("NewsViewControllerID") as! NewsViewController
//        newsViewController.newsDataArray = self.newsArray
//        newsViewController.index = indexPath.row
//        self.viewCotroller.pushViewController(newsViewController, animated: true)
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        let cellNumber = self.newsModels.models.count
        return cellNumber > 3 ? 3 : cellNumber
    }
}

//MARK:- UICollectionViewDelegate & UICollectionViewDataSource
extension HomeViewModel : UICollectionViewDelegate , UICollectionViewDataSource
{
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return self.appModels.models[section].count
    }
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int
    {
        return self.categoryModels.models.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("CollectionViewID", forIndexPath: indexPath) as? HomeCollectionViewCell
        cell?.setupWith(self.appModels.models[indexPath.section][indexPath.row])
        
        return cell!
    }
    
    func collectionView(collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, atIndexPath indexPath: NSIndexPath) -> UICollectionReusableView
    {
        let headerView = collectionView.dequeueReusableSupplementaryViewOfKind(kind, withReuseIdentifier: "CollectionReusableViewID", forIndexPath: indexPath) as? HomeCollectionReusableView
        let categoryModel = self.categoryModels.models[indexPath.section]
        headerView?.titleLabel.text = categoryModel.name
        
        return headerView!
    }
}

//MARK:- Sync App Infroamtion
extension HomeViewModel
{
    func startSyncAPPInformation(completion : (state : NetworkManager.ResponseState , isVersionError : Bool) -> Void)
    {
        LoggerManager.appendLogger("请求App信息开始。")
        NetworkManager.sharedManager.get(URL: NetworkManager.getAppSyncURLString(), Parameters: nil) { (response) in
            let (state , result) = NetworkManager.checkResponse(response)
            EnvironmentManager.clearFolderWith(TEMPPATH)
            if state == .Success
            {
                LoggerManager.appendLogger("请求App信息成功。")
                let informations = result as! [String : AnyObject]
                if self.checkVersionAvaliable(informations) == false
                {
                    completion(state: .Success, isVersionError: true)
                }else
                {
                    self.categoryModels.processSyncedData(informations)
                    self.appModels.processSyncedData(informations)
                    self.traningModels.processSyncedData(informations)
                    completion(state: .Success, isVersionError: false)
                }
            }else
            {
                LoggerManager.appendLogger("请求App信息失败，response = \(response)")
                completion(state: state, isVersionError: false)
            }
        }
    }
    
    private func checkVersionAvaliable(informations : [String : AnyObject]) -> Bool
    {
        let versionDic = informations["version"] as! [String : AnyObject]
        let version    = versionDic["Version"] as! Double
        
        return version == PROJECT_VERSION
    }
    
    func loadModels()
    {
        self.categoryModels.loadModels()
        self.appModels.loadModels()
        self.traningModels.loadModels()
        self.newsModels.loadModels()
        self.loadModelsCompletion?()
    }
}

//MARK:- Sync News Infroamtion
extension HomeViewModel
{
    func startSyncNewsInformation(completion : (isSuccess : Bool) -> Void)
    {
        LoggerManager.appendLogger("请求News信息开始。")
        NetworkManager.sharedManager.get(URL:NetworkManager.getTheFirstThreeNewsURLString(), Parameters:nil) { (response) in
            let (state , result) = NetworkManager.checkResponse(response)
            if state == .Success
            {
                LoggerManager.appendLogger("请求News信息成功。")
                if let informations = result as? [[String : AnyObject]]
                { 
                    self.newsModels.processSyncedData(informations)
                    completion(isSuccess: true)
                }else
                {
                    LoggerManager.appendLogger("请求News信息失败，response = \(response)")
                    completion(isSuccess: false)
                }
            }
            else
            {
                LoggerManager.appendLogger("请求News信息失败，response = \(response)")
                completion(isSuccess: false)
            }
        }
    }
}

