//
//  HomeCollectionViewCellHandler.swift
//  CNSalesPortal
//
//  Created by Kilin on 16/5/27.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit
import Alamofire
import ZipArchive

let DEFAULT_FILE_SIZE : Int = 5000000
let NOTIFICATION_HOMECOLLECTIONVIEWCELL = "com.lilly.innocellence.cnsalesportal.homeCollectionViewCell"

struct HomeCollectionViewCellHandler
{
    func startDownloadPackage(model : AppModel , progress : (progress : Float) -> Void ,completion : (isSuccess : Bool) -> Void)
    {
        var totalFileSize = DEFAULT_FILE_SIZE
        if let serverFileSize = model.fileSize?.integerValue where serverFileSize > 0
        {
            totalFileSize = serverFileSize
        }
        
        NetworkManager.sharedManager.download(URL: NetworkManager.getPackageDownloadURLString(model.package!), CompleteBytes: { (completeBytes) in
            let pro = Float(completeBytes)/Float(totalFileSize)
            progress(progress: pro > 0.99 ? 0.99 : pro)
        }) { (request, response, data, error) in
            if error != nil && error?.code != 516
            {
                completion(isSuccess: false)
            }else
            {
                completion(isSuccess: true)
            }
        }
    }
    
    func startUnzipPackage(model : AppModel , completion : (isSuccess : Bool) -> Void)
    {
        let tempFolder = TEMPPATH
        let tempFilePath = "\(tempFolder)/" + model.zipFileName()
        
        let destinationFilePath = PATH_FOLDER_APP + model.unzipedAPPFolderName()
        
        SSZipArchive.unzipFileAtPath(tempFilePath, toDestination: destinationFilePath, overwrite: true, password: nil, progressHandler: nil) { (content, success, error) in
            completion(isSuccess: success)
        }
    }
}

extension HomeCollectionViewCellHandler
{
    func checkPackageUpdatable(model : AppModel) -> Bool
    {
        if model.isPopupLink?.boolValue == true
        {
            return false
        }
        
        if model.isMandatoryPackage?.boolValue == true && model.isMandatoryVersion?.boolValue == true && model.isPackageDownloadComplete?.boolValue == false
        {
            return true
        }
        
        return false
    }
    
    func checkAppStateAndUpdatable(model :AppModel , updatable : () -> Void)
    {
        if self.checkIsExtenralLink(model.isPopupLink, navigationLink: model.navigationLink) == true
        {
            return
        }

        if model.isPackageDownloadComplete == false
        {
            updatable()
            return
        }
    
        let message = [ "APP_ID" : model.appID! ,
                        "TYPE"   : "LAUNCHAPP"  ]
        self.postNotificationWith(message)
        return
    }
    
    private func checkIsExtenralLink(isPopupLink : NSNumber? , navigationLink : String?) -> Bool
    {
        guard let isExternalApp = isPopupLink?.boolValue where isExternalApp == true else
        {
            return false
        }
        
        guard let externalLink = navigationLink where externalLink.characters.count > 0 else
        {
            let message = [ "WARNING_TITLE"   : "操作失败" ,
                            "WARNING_CONTENT" : "外部链接为空，无法打开。" ,
                            "TYPE"            : "WARNING"  ]
            self.postNotificationWith(message)
            return true
        }
        
        if externalLink.lowercaseString.hasPrefix("http://") || externalLink.lowercaseString.hasPrefix("https://")
        {
            let message = [ "EXTENRAL_LINK" : externalLink ,
                            "TYPE"          : "EXTERNAL"  ]
            self.postNotificationWith(message)
            return true
        }
        
        if externalLink.containsString("://")
        {      
            let url = NSURL(string: externalLink)
            if UIApplication.sharedApplication().openURL(url!) == false
            {
                let message = [ "WARNING_TITLE"   : "无法打开外部链接" ,
                                "WARNING_CONTENT" : "此链接无效，无法打开外部链接",
                                "TYPE"            : "WARNING"  ]
                self.postNotificationWith(message)
                return true
            }
        }
        
        return true
    }
    
    private func postNotificationWith(userInfor : [String : AnyObject])
    {
        NSNotificationCenter.defaultCenter().postNotificationName(NOTIFICATION_HOMECOLLECTIONVIEWCELL, object: nil, userInfo: userInfor)
    }
}

