//
//  HybridViewControllerExtension.swift
//  CNSalesPortal
//
//  Created by Kilin on 16/5/31.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

//MARK:- LAUNCH PHOTO OR LAUNCH LIBRARY
extension HybridViewController
{
    func launchTakePhoto()
    {
        guard self.chiefHandler.checkCameraAuthorization() == true else
        {
            self.notifyLibrartAccessDenied(NSLocalizedString("I_Hybrid_CameraAuthencationFailure", comment: ""))
            return
        }
        
        guard self.chiefHandler.checkCameraAvaliable() == true else
        {
            self.notifyLibrartAccessDenied(NSLocalizedString("I_Hybrid_CameraUnavaliable", comment: ""))
            return
        }
        
        guard self.chiefHandler.checkPhotoLibraryAvaliable() == true else
        {
            self.notifyLibrartAccessDenied(NSLocalizedString("I_Hybrid_LibraryUnavaliable", comment: ""))
            return
        }
        
        HybridViewController.isImagePickerControllerEnable = true
        
        let imagePickerController = UIImagePickerController()
        imagePickerController.sourceType = .Camera
        imagePickerController.delegate   = self
        self.presentViewController(imagePickerController, animated: true, completion: nil)
    }
    
    func launchPhotoLibrary()
    {
        guard self.chiefHandler.chechPhotoLibraryAuthorization() == true else
        {
            self.notifyLibrartAccessDenied(NSLocalizedString("I_Hybrid_LibraryAuthencationFailure", comment: ""))
            return
        }
        
        guard self.chiefHandler.checkPhotoLibraryAvaliable() == true else
        {
            self.notifyLibrartAccessDenied(NSLocalizedString("I_Hybrid_LibraryUnavaliable", comment: ""))
            return
        }
        
        HybridViewController.isImagePickerControllerEnable = true
        
        let imagePickerController = UIImagePickerController()
        imagePickerController.sourceType = .PhotoLibrary
        imagePickerController.delegate   = self
        self.presentViewController(imagePickerController, animated: true, completion: nil)
    }
    
    private func notifyLibrartAccessDenied(message : String)
    {
        let confirmAction = UIAlertAction(title: NSLocalizedString("I_Common_OK", comment: ""), style: .Default, handler: nil)
        self.showAlertWith("", message: message, confirmAction: confirmAction, cancelAction: nil)
    }
}

//MARK:- UIImagePickerControllerDelegate
extension HybridViewController : UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject])
    {
        HybridViewController.isImagePickerControllerEnable = false
        picker.dismissViewControllerAnimated(true, completion: {
            dispatch_async(dispatch_get_main_queue()) {
                self.hudAwaysShowIndicatorWith(NSLocalizedString("I_ImageDisplayView_PhotoProcessing", comment: ""))
            }
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, Int64(1 * Double(NSEC_PER_SEC))), dispatch_get_main_queue(), {
                self.chiefHandler.processImageWith(picker.sourceType, info: info)
            })
        })
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController)
    {
        HybridViewController.isImagePickerControllerEnable = false
        picker.dismissViewControllerAnimated(true, completion: nil)
    }
}


