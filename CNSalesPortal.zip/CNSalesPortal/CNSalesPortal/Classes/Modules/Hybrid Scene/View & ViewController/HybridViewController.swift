//
//  HybridViewController.swift
//  CNSalesPortal
//
//  Created by Kilin on 16/5/27.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class HybridViewController: UIViewController , HUDOperable , AlertDisplayable
{
    var hud : MBProgressHUD = {
        let mbProgressHUD = MBProgressHUD()
        mbProgressHUD.minSize = CGSizeMake(160, 90)
        return mbProgressHUD
    }()
    
    @IBOutlet weak var webView: UIWebView!
 
    static var isImagePickerControllerEnable = false
    var chiefHandler = CHIEFHandler()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.view.addSubview(self.hud)
        LoggerManager.appendLogger("Come in Hybrid View Controller.")
    }
    
    override func viewWillAppear(animated: Bool)
    {
        super.viewWillAppear(animated)
        self.chiefHandler.addPhotoNotificaions()
    }
    
    override func viewDidDisappear(animated: Bool)
    {
        super.viewDidDisappear(animated)
        self.chiefHandler.removePhotoNotifications()
    }
    
    func initialWebViewWith(model : AppModel , scheme : String?)
    {
        let (state , path) = CHIEFHandler.indexHTMLPath(model)
        if state == false
        {
            let title = NSLocalizedString("I_Hybrid_LoadHtmlFailure", comment: "")
            let confirmAction = UIAlertAction(title: NSLocalizedString("I_Common_OK", comment: ""), style: .Default, handler: { (_) in
                self.backToHome()
            })
            self.showAlertWith(title, message: "", confirmAction: confirmAction, cancelAction: nil)
            return
        }else
        {
            if let webScrollView = self.webView.subviews.first as? UIScrollView
            {
                webScrollView.bounces = false
            }
            
            self.chiefHandler.setupWith(self.webView, model: model)
            self.chiefHandler.scheme                         = scheme
            self.chiefHandler.showAttachmentFunction         = showAttachmentPopupController
            self.chiefHandler.showAlertFunction              = self.showAlertWith
            self.chiefHandler.backToHomeFunction             = backToHome
            self.chiefHandler.hudIndicatorFunction           = self.hudAwaysShowIndicatorWith
            self.chiefHandler.hudHideWithFunction            = self.hudHideManuallyWith
            self.chiefHandler.displayAttachmentImageFunciton = self.displayImage
            self.chiefHandler.createAttachmentFolder()
            self.chiefHandler.registerBridgeHandler()
            
            let url = NSURL(string: path)
            let urlRequest = NSURLRequest(URL: url!)
            self.webView.loadRequest(urlRequest)
        }
    }
}

//MARK:- Assistant Functions
extension HybridViewController
{
    func displayImage(path : String)
    {
        let nibs = NSBundle.mainBundle().loadNibNamed("ImageDisplayView", owner: nil, options: nil)
        let imageDisplayView = nibs.first as! ImageDisplayView
        imageDisplayView.frame = CGRectMake(0, 0, 1024, 768)
        imageDisplayView.image = UIImage(contentsOfFile: path)
        imageDisplayView.resetUILayout()
        self.webView.addSubview(imageDisplayView)
    }
    
    func showAttachmentPopupController(touchX : NSNumber , touchY : NSNumber)
    {
        let nibs = NSBundle.mainBundle().loadNibNamed("AttachmentViewController", owner: nil, options: nil)
        let attachmentViewController = nibs.first as? AttachmentViewController
        
        let popoverController = UIPopoverController(contentViewController: attachmentViewController!)
        popoverController.setPopoverContentSize(CGSizeMake(320, 180), animated: true)
        
        if (touchX.floatValue < 512)
        {
            popoverController.presentPopoverFromRect(CGRectMake(CGFloat(touchX), CGFloat(touchY), 5, 5), inView: self.webView, permittedArrowDirections: .Left, animated: true)
        }else{
            popoverController.presentPopoverFromRect(CGRectMake(CGFloat(touchX), CGFloat(touchY), 5, 5), inView: self.webView, permittedArrowDirections: .Right, animated: true)
        }
        
        attachmentViewController?.photograph = {
            popoverController.dismissPopoverAnimated(false)
            self.launchTakePhoto()
        }
        attachmentViewController?.launchLibrary = {
            popoverController.dismissPopoverAnimated(false)
            self.launchPhotoLibrary()
        }
    }
    
    private func backToHome()
    {
        self.dismissViewControllerAnimated(true) {}
    }
}
