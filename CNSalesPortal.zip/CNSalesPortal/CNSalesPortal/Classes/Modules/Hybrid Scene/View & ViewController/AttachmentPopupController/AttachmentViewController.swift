//
//  AttachmentViewController.swift
//  CNSalesPortal
//
//  Created by Kilin on 16/5/31.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class AttachmentViewController: UIViewController
{
    @IBOutlet weak var titleLabel           : UILabel!
    @IBOutlet weak var photographButton     : UIButton!
    @IBOutlet weak var launchLibraryButton  : UIButton!
    
    var photograph : (() -> Void)?
    var launchLibrary : (() -> Void)?
    
    override func viewDidLoad()
    {
        self.titleLabel.text = NSLocalizedString("I_Attachment_AddNewAttachment", comment: "")
        
        self.photographButton.setTitle(NSLocalizedString("I_Attachment_Camera", comment: ""), forState: .Normal)
        self.photographButton.setTitle(NSLocalizedString("I_Attachment_Camera", comment: ""), forState: .Highlighted)
        self.launchLibraryButton.setTitle(NSLocalizedString("I_Attachment_Library", comment: ""), forState: .Normal)
        self.launchLibraryButton.setTitle(NSLocalizedString("I_Attachment_Library", comment: ""), forState: .Highlighted)
    }
    
    @IBAction func photographClicked(sender: AnyObject)
    {
        self.photograph?()
    }
    
    @IBAction func launchLibraryClicked(sender: AnyObject)
    {
        self.launchLibrary?()
    }
}
