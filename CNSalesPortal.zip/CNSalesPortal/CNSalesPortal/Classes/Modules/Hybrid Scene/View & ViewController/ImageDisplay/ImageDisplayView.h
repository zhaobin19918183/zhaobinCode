//
//  ImageDisplayView.h
//
//  Copyright ( C ) 2015 Eli Lilly and Company. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageDisplayView : UIView <UIAlertViewDelegate>

@property (nonatomic,strong) UIImage *image;

- (void)resetUILayout;

@end
