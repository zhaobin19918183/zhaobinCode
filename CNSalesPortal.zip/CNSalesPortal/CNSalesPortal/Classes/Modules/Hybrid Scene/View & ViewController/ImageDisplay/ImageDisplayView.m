//
//  ImageDisplay.m
//
//  Copyright ( C ) 2015 Eli Lilly and Company. All rights reserved.
//

#import "ImageDisplayView.h"
#import <QuartzCore/QuartzCore.h>

#define kLengthButtonWidth      	50.0f
#define kLengthButtonHeight         50.0f

#define kLengthButtonSpace          15.0f
#define kLengthButtonTopSpace       20.0f

#define kTimeImageViewResize        0.3f

#define kScaleMax                   3.0f
#define kScaleMin                   0.5f

#define kTimeTipLabelDelay          1.5f
#define kTimeTipLabelFadeOut        0.5f

typedef NS_ENUM(NSUInteger, eRectType) {
    eRectTypeImageView  = 0,
    eRectTypeClose      = 1,
    eRectTypeOrigin     = 2,
    eRectTypeFull       = 3,
    eRectTypeSave       = 4,
    eRectTypeRotation   = 5,
    eRectTypeShieldView = 6,
};;

@interface ImageDisplayView()
{
    __weak IBOutlet UIImageView *_imageView;
    __weak IBOutlet UIView *_shieldView;
    
    __weak IBOutlet UIButton *_closeButton;
    __weak IBOutlet UIButton *_fullButton;
    __weak IBOutlet UIButton *_originButton;
    __weak IBOutlet UIButton *_saveButton;
    __weak IBOutlet UIButton *_rotationButton;
    
    CGRect _originFrame;
    
    BOOL _imageSaved;
    BOOL _isInAnimation;
    BOOL _isInTipLabel;
    
    int _iamgeOrientation;
}

@end

@implementation ImageDisplayView
#pragma mark -
#pragma mark Initial
- (id)init
{
    self = [super init];
    if (self) {
        _imageSaved    = NO;
        _isInAnimation = NO;
        _isInTipLabel  = NO;
    }
    return self;
}

#pragma mark -
#pragma mark Button Click Event
- (IBAction)closeClicked:(id)sender
{
    [self removeFromSuperview];
}

- (IBAction)originClicked:(id)sender
{
    [self imageViewAnimationWithDuration:kTimeImageViewResize targetFrame:[self rectWithWidget:eRectTypeImageView]];
}

- (IBAction)fullClicked:(id)sender
{
    float scaleWidthCoe = _imageView.frame.size.width / self.frame.size.width;
    float scaleHeightCoe = _imageView.frame.size.height / self.frame.size.height;
    float scaleCoe = 1.0;
    
    if (scaleWidthCoe < 1.0 && scaleHeightCoe < 1.0)
    {
        scaleCoe = (scaleWidthCoe >= scaleHeightCoe ? 1.0 / scaleWidthCoe : 1.0 / scaleHeightCoe);
    }else if (scaleWidthCoe > 1.0 || scaleHeightCoe > 1.0)
    {
        scaleWidthCoe = 1.0 / scaleWidthCoe;
        scaleHeightCoe = 1.0 / scaleHeightCoe;
        scaleCoe = (scaleWidthCoe <= scaleHeightCoe ? scaleWidthCoe : scaleHeightCoe);
    }else if (scaleWidthCoe == 1.0 || scaleHeightCoe == 1.0)
    {
        scaleCoe = 1.0;
    }
    
    CGSize displaySize = CGSizeMake(_imageView.frame.size.width * scaleCoe, _imageView.frame.size.height * scaleCoe);
    [self imageViewAnimationWithDuration:kTimeImageViewResize
                             targetFrame:CGRectMake((self.frame.size.width - displaySize.width) / 2,
                                                    (self.frame.size.height - displaySize.height) / 2,
                                                    displaySize.width, displaySize.height)];
}

- (IBAction)saveClicked:(id)sender
{
    if (_imageSaved)
    {
        [[[UIAlertView alloc] initWithTitle:@""
                                    message:@"该图片已经保存，是否再次保存？"
                                   delegate:self
                          cancelButtonTitle:@"否"
                          otherButtonTitles:@"是", nil] show];
        return;
    }else{
        UIImageWriteToSavedPhotosAlbum(_imageView.image, self, @selector(image:didFinishSavingWithError:contextInfo:),nil);
    }
}

- (IBAction)raotationClicked:(id)sender
{
    _iamgeOrientation += 1;
    switch (_iamgeOrientation % 2) {
        case 0:
        {
            UIImage *image = [UIImage imageWithCGImage:_imageView.image.CGImage scale:1 orientation:UIImageOrientationUp];
            [_imageView setImage:image];
        }break;
        case 1:
        {
            UIImage *image = [UIImage imageWithCGImage:_imageView.image.CGImage scale:1 orientation:UIImageOrientationDown];
            [_imageView setImage:image];
        }break;
        default:break;
    }
}

#pragma mark -
- (void)resetUILayout
{
    self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.6];
    [self setClipsToBounds:YES];
    
    UIPinchGestureRecognizer *pinchGesture = [[UIPinchGestureRecognizer alloc] initWithTarget:self
                                                                                       action:@selector(pinchGesture:)];
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self
                                                                                 action:@selector(panGesture:)];
    [_imageView addGestureRecognizer:pinchGesture];
    [_imageView addGestureRecognizer:panGesture];
    [_imageView setUserInteractionEnabled:YES];
    [_imageView setFrame:[self rectWithWidget:eRectTypeImageView]];
    [_imageView setImage:_image];
    
    [_shieldView setFrame:[self rectWithWidget:eRectTypeShieldView]];
    [_shieldView setBackgroundColor:[[UIColor blackColor] colorWithAlphaComponent:0.3]];
    [_shieldView.layer setCornerRadius:15];
    
    [_closeButton setFrame:[self rectWithWidget:eRectTypeClose]];
    [_originButton setFrame:[self rectWithWidget:eRectTypeOrigin]];
    [_fullButton setFrame:[self rectWithWidget:eRectTypeFull]];
    [_saveButton setFrame:[self rectWithWidget:eRectTypeSave]];
    [_rotationButton setFrame:[self rectWithWidget:eRectTypeRotation]];
}

- (CGRect)rectWithWidget:(eRectType)rectType
{
    float width = self.frame.size.width;
    float height = self.frame.size.height;
    
    float buttonWidth = kLengthButtonWidth;
    float buttonHeight = kLengthButtonHeight;
    
    float imageWidth = _image.size.width;
    float imageHeight = _image.size.height;
    
    CGRect rect = CGRectZero;
    
    switch (rectType) {
        case eRectTypeImageView:
        {
            float widthScale = imageWidth / width;
            float heightScale = imageHeight / height;
            float scale = 1.0;
            
            if (widthScale > 1.0 || heightScale > 1.0)
            {
                scale = widthScale > heightScale ? widthScale : heightScale;
            }else
            {
                scale = 1;
            }
            
            _originFrame = CGRectMake((width - imageWidth / scale) / 2,
                                      (height - imageHeight / scale) / 2,
                                      imageWidth / scale, imageHeight / scale);
            rect = _originFrame;
        }break;
        case eRectTypeClose:
        {
            rect = CGRectMake(width - (kLengthButtonSpace + buttonWidth) * eRectTypeClose, kLengthButtonTopSpace, buttonWidth, buttonHeight);
        }break;
        case eRectTypeOrigin:
        {
            rect = CGRectMake(width - (kLengthButtonSpace + buttonWidth) * eRectTypeOrigin, kLengthButtonTopSpace, buttonWidth, buttonHeight);
        }break;
        case eRectTypeFull:
        {
            rect = CGRectMake(width - (kLengthButtonSpace + buttonWidth) * eRectTypeFull, kLengthButtonTopSpace, buttonWidth, buttonHeight);
        }break;
        case eRectTypeSave:
        {
            rect = CGRectMake(width - (kLengthButtonSpace + buttonWidth) * eRectTypeSave, kLengthButtonTopSpace, buttonWidth, buttonHeight);
        }break;
        case eRectTypeRotation:
        {
            rect = CGRectMake(width - (kLengthButtonSpace + buttonWidth) * eRectTypeRotation, kLengthButtonTopSpace, buttonWidth, buttonHeight);
        }break;
        case eRectTypeShieldView:
        {
            rect = CGRectMake(width - (kLengthButtonSpace + buttonWidth) * (eRectTypeShieldView - 1) - 10, -50, width, buttonHeight + 30 + 50);
        }break;
        default:break;
    }
    
    return rect;
}

- (void)image:(UIImage*)image didFinishSavingWithError:(NSError*)error contextInfo:(id)info
{
    if (error == nil)
    {
        _imageSaved = YES;
        
        [self saveImageToLibiarySuccessTip];
    }else
    {
        [[[UIAlertView alloc] initWithTitle:@"保存失败"
                                    message:nil
                                   delegate:self
                          cancelButtonTitle:@"好"
                          otherButtonTitles:nil] show];
    }
}

#pragma mark -
#pragma mark UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1)
    {
        UIImageWriteToSavedPhotosAlbum(_imageView.image, self, @selector(image:didFinishSavingWithError:contextInfo:),nil);
    }
}

#pragma mark -
#pragma mark Save Image
- (void)imageViewAnimationWithDuration:(float)time targetFrame:(CGRect)frame
{
    if (_isInAnimation == NO)
    {
        _isInAnimation = YES;
        [UIView animateWithDuration:time
                         animations:^{
                             [_imageView setFrame:frame];
                         }
                         completion:^(BOOL finished) {
                             _isInAnimation = NO;
                         }];
    }
}

- (void)saveImageToLibiarySuccessTip
{
    if (_isInTipLabel)
    {
        return;
    }
    
    _isInTipLabel = YES;
    
    UILabel *tipLabel = [[UILabel alloc] initWithFrame:CGRectMake(512 - 200 / 2, 384 - 60 / 2, 300, 60)];
    [tipLabel setBackgroundColor:[UIColor blackColor]];
    [tipLabel setFont:[UIFont fontWithName:@"Arial" size:20]];
    [tipLabel setText:@"保存成功"];
    [tipLabel setTextAlignment:NSTextAlignmentCenter];
    [tipLabel setTextColor:[UIColor whiteColor]];
    tipLabel.layer.cornerRadius = 8;
    [self addSubview:tipLabel];
    
    [UIView animateWithDuration:kTimeTipLabelFadeOut
                          delay:kTimeTipLabelDelay
                        options:UIViewAnimationOptionCurveLinear
                     animations:^{
                         [tipLabel setAlpha:0];
                     }
                     completion:^(BOOL finished) {
                         [tipLabel removeFromSuperview];
                         _isInTipLabel = NO;
                     }];
}

#pragma mark -
#pragma mark Gestrue
- (void)pinchGesture:(UIPinchGestureRecognizer*)sender
{
    float scaled = _imageView.frame.size.width / _originFrame.size.width;
    float scaleVelocity = sender.velocity;
    float currentScale = 0.0;
    if (scaleVelocity > 0)
    {
        currentScale = 0.03;
    }else
    {
        currentScale = -0.03;
    }
    
    scaled += currentScale;
    
    if (scaled >= kScaleMax)
    {
        scaled = kScaleMax;
    }
    if (scaled <= kScaleMin)
    {
        scaled = kScaleMin;
    }
    
    float width = _originFrame.size.width * scaled;
    float height = _originFrame.size.height * scaled;
    [_imageView setFrame:CGRectMake(_imageView.center.x - (width / 2), _imageView.center.y - (height / 2), width, height)];
}

- (void)panGesture:(UIPanGestureRecognizer*)sender
{
    CGPoint point = [sender translationInView:self];
    sender.view.center = CGPointMake(sender.view.center.x + point.x, sender.view.center.y + point.y);
    [sender setTranslation:CGPointMake(0, 0) inView:self];
}

@end
