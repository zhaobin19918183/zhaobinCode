//
//  ExtensionHandlerNetwork.swift
//  CNSalesPortal
//
//  Created by Kilin on 16/5/30.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit
import Alamofire
extension CHIEFHandler
{
    func handleNetworkRequestWith(data : AnyObject)
    {
        guard let urlString = data["url"] as? String else
        {
            let callbackHandlerName = data["handlerString"] as! String
            self.callbackHandlerFailure(handlerName: callbackHandlerName, message: "URL is empty.")
            return
        }
        
        if urlString == "sphome"
        {
            if let methodName = data["methodName"] as? String where methodName == "login"
            {
                self.login(data)
            }
        }else
        {
            self.networkWith(data)
        }
    }
}

//MARK:- NETWORK FUNCTIONS
extension CHIEFHandler
{
    private func networkWith(data : AnyObject)
    {
        guard let method = data["methodType"] as? String else
        {
            let callbackHandlerName = data["handlerString"] as! String
            self.callbackHandlerFailure(handlerName: callbackHandlerName, message: "Method type is wrong. -> \(data)")
            return
        }
        
        if method == "POST"
        {
            self.postDataWith(data)
        }
        
        if method == "GET"
        {
            self.getDataWith(data)
        }
    }
    
    private func checkData(data : AnyObject) -> (valid : Bool , requestURLString : String? , parameters : [String : AnyObject]?)
    {
        let callbackHandlerName = data["handlerString"] as! String
        
        guard NetworkManager.sharedManager.isNetworkEnable() == true else
        {
            LoggerManager.appendLogger("无网络，无法发送数据到CHIEF服务器。")
            self.callbackHandlerFailureBlock(handlerName: callbackHandlerName, message:NSLocalizedString("I_Error_SOAG_Network", comment: ""))
            return (false , nil , nil)
        }
        
        let requestURLString = data["url"] as! String
        var parameters = [ String : AnyObject ]()
        if let para = data["data"] as? [ String : AnyObject ]
        {
            parameters = para
        }
        
        return (true , requestURLString , parameters)
    }
    
    private func postDataWith(data : AnyObject)
    {
        let result = self.checkData(data)
        
        if result.valid == false
        {
            return
        }else
        {
            LoggerManager.appendLogger("POST数据到CHIEF。")
            self.disableWebView?()
            NetworkManager.sharedManager.post(URL: result.requestURLString!, Parameters: result.parameters) { (response) in
                self.enableWebView?()
                if response.result.isSuccess
                {
                    LoggerManager.appendLogger("POST数据到CHIEF成功")
                    self.processNetworkSuccess(data,result: response.result.value)
                }else
                {
                    LoggerManager.appendLogger("POST数据到CHIEF失败，response = \(response)")
                    self.processNetworkFailed(data, response: response)
                }
            }
        }
    }
    
    private func getDataWith(data : AnyObject)
    {
        let result = self.checkData(data)
        
        if result.valid == false
        {
            return
        }else
        {
            LoggerManager.appendLogger("从CHIEF服务器GET数据。")
            self.disableWebView?()
            NetworkManager.sharedManager.get(URL: result.requestURLString!, Parameters: nil) { (response) in
                self.enableWebView?()
                if response.result.isSuccess
                {
                    LoggerManager.appendLogger("从CHIEF服务器GET数据成功。")
                    self.processNetworkSuccess(data,result: response.result.value)
                }else
                {
                    LoggerManager.appendLogger("从CHIEF服务器GET失败，response = \(response)")
                    self.processNetworkFailed(data, response: response)
                }
            }
        }
    }
    
    private func processNetworkSuccess(data : AnyObject , result : String?)
    {
        let callbackHandlerName = data["handlerString"] as! String
        self.callbackHandlerSuccess(handlerName: callbackHandlerName, message: result!)
    }
    
    private func processNetworkFailed(data : AnyObject , response : Alamofire.Response<String, NSError>)
    {
        let callbackHandlerName = data["handlerString"] as! String
        var errorMessage = ""

        let result = NetworkManager.checkResponse(response)
        switch result.0 {
        case .Timeout:
            errorMessage =  NSLocalizedString("I_Error_SOAG_Timeout", comment: "")
        case .AuthenRequired:
            errorMessage =  NSLocalizedString("I_Error_SOAG_Authencation", comment: "")
        case .SOAGPolicyError:
            errorMessage =  NSLocalizedString("I_Error_SOAG_Self", comment: "")
        case .OtherError:
            errorMessage =  NSLocalizedString("I_Error_SOAG_Other", comment: "")
        case .ResponseDataError:
            errorMessage =  NSLocalizedString("I_Error_SOAG_Data", comment: "")
        default:
            errorMessage = NSLocalizedString("I_Error_SOAG_Other", comment: "")
        }
        
        self.callbackHandlerFailureBlock(handlerName: callbackHandlerName, message: errorMessage)
    }
}

//MARK:- LOGIN
extension CHIEFHandler
{
    private func login(data : AnyObject)
    {
        guard NetworkManager.sharedManager.isNetworkEnable() == true else
        {
            LoggerManager.appendLogger("无网络，无法登录CHIEF")
            let callbackHandlerName = data["handlerString"] as! String
            self.callbackHandlerFailureBlock(handlerName: callbackHandlerName, message:NSLocalizedString("I_Error_SOAG_Network", comment: ""))
            return
        }
        
        LoggerManager.appendLogger("请求登录CHIEF")
        self.disableWebView?()
        let requestURLString = self.loginRequestURLString(data)
        NetworkManager.sharedManager.post(URL: requestURLString, Parameters: nil) { (response) in
            self.enableWebView?()
            if response.result.isSuccess
            {
                LoggerManager.appendLogger("登录CHIEF成功")
                self.processLoginSuccess(data,result: response.result.value)
            }else
            {
                LoggerManager.appendLogger("登录CHIEF失败，response = \(response)")
                self.processLoginFailed(data, response: response)
            }
        }
    }
    
    private func processLoginSuccess(data : AnyObject , result : String?)
    {
        let callbackHandlerName = data["handlerString"] as! String
        
        guard let token = result where token != "null" else
        {
            self.callbackHandlerFailure(handlerName: callbackHandlerName, message: "Token is null.")
            return
        }
        
        guard token.characters.count != 0 else
        {
            self.callbackHandlerFailure(handlerName: callbackHandlerName, message: "Token length is 0.")
            return
        }
        
        var tokenString = ""
        if token.lowercaseString.hasPrefix("<string") || token.lowercaseString.hasSuffix("</string>")
        {
            tokenString = HelperManager.convertHTMLToTextString(token)
        }
        
        if token.lowercaseString.hasPrefix("\"") || token.lowercaseString.hasSuffix("\"")
        {
            tokenString = token.stringByReplacingOccurrencesOfString("\"", withString: "")
        }
        
        self.callbackHandlerSuccess(handlerName: callbackHandlerName, message: HelperManager.convertAnyObjectToString([ tokenString , AccountManager.username()! ]))
    }
    
    private func processLoginFailed(data : AnyObject , response : Alamofire.Response<String, NSError>)
    {
        let callbackHandlerName = data["handlerString"] as! String
        var errorMessage = ""
        
        let result = NetworkManager.checkResponse(response)
        switch result.0 {
        case .Timeout:
            errorMessage =  NSLocalizedString("I_Error_SOAG_Timeout", comment: "")
        case .AuthenRequired:
            errorMessage =  NSLocalizedString("I_Error_SOAG_Authencation", comment: "")
        case .SOAGPolicyError:
            errorMessage =  NSLocalizedString("I_Error_SOAG_Self", comment: "")
        case .OtherError:
            errorMessage =  NSLocalizedString("I_Error_SOAG_Other", comment: "")
        case .ResponseDataError:
            errorMessage =  NSLocalizedString("I_Error_SOAG_Data", comment: "")
        default:
            errorMessage = NSLocalizedString("I_Error_SOAG_Other", comment: "")
        }
        self.callbackHandlerFailureBlock(handlerName: callbackHandlerName, message: errorMessage)
    }
    
    private func loginRequestURLString(data : AnyObject) -> String
    {
        let callbackHandlerName = data["handlerString"] as! String
        
        guard let loginData = data["data"] else
        {
            self.callbackHandlerFailure(handlerName: callbackHandlerName, message: "Login data is empty.")
            return ""
        }
        
        guard let rootURL = loginData?["url"] as? String else
        {
            self.callbackHandlerFailure(handlerName: callbackHandlerName, message: "Login url is empty.")
            return ""
        }
        
        let encryptLoginString = StringEncryption.encryptUserInfor(AccountManager.username()!, password: AccountManager.password()!)
        return "\(rootURL)?s=\(encryptLoginString)"
    }
}


