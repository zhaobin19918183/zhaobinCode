//
//  ExtensionHandler_Photo.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/6/1.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

let NOTIFICATION_PHOTOCOMPLETION = "com.lilly.innocellence.cnsalesportal.takePhotoCompletion"

//MARK:- PROCESS IMAGE INFO
extension CHIEFHandler
{
    func processImageWith(sourceType : UIImagePickerControllerSourceType ,info : [String : AnyObject])
    {
        if sourceType == .Camera
        {
            self.processCameraPhotoWith(info)
        }
        
        if sourceType == .PhotoLibrary
        {
            self.processLibraryPhotoWith(info)
        }
    }
    
    private func savePhotoToAlbum(image : UIImage , metadata : [String : AnyObject] , completion : (success : Bool) -> Void)
    {
        let library = ALAssetsLibrary()
        library.writeImageToSavedPhotosAlbum(image.CGImage, metadata: metadata) { (url, error) in
            completion(success: error == nil)
        }
    }
    
    private func savePhotoToFolder(imageData : NSData)
    {
        let destination  = self.attachmentFolder() + "/"
        
        let photoName    = AttachmentDataManager.sharedManager.data["AttachmentName"] as! String
        let fileSavePath = destination + photoName
        imageData.writeToFile(fileSavePath, atomically: true)
    }
    
    private func addMetadataToImage(image : UIImage , metadata : NSDictionary) -> (success : Bool , metadataImageData : NSData?)
    {
        guard let originImageData = UIImageJPEGRepresentation(image, 0.4) else
        {
            return (false , nil)
        }
        
        guard let imageSource = CGImageSourceCreateWithData(originImageData, nil) else
        {
            return (false , nil)
        }
        
        guard let UTI = CGImageSourceGetType(imageSource) else
        {
            return (false , nil)
        }
        
        let newMetadata = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(newMetadata, UTI, 1, nil) else
        {
            return (false , nil)
        }
        
        CGImageDestinationAddImageFromSource(destination, imageSource, 0, metadata)
        
        if CGImageDestinationFinalize(destination) == true
        {
            return (true , newMetadata)
        }else
        {
            return (false , nil)
        }
    }
}

//MARK:- PROCESS CAMERA PHOTO
extension CHIEFHandler
{
    private func processCameraPhotoWith(info : [String : AnyObject])
    {
        let image = info[UIImagePickerControllerOriginalImage] as! UIImage
        self.generateMetadataWith(info) { (metadata) in
            let result = self.addMetadataToImage(image, metadata: metadata)
            if result.success == true
            {
                self.savePhotoToFolder(result.metadataImageData!)
                self.savePhotoToAlbum(image, metadata: metadata, completion: { (success) in
                    dispatch_async(dispatch_get_main_queue(), { 
                        self.hudHideWithFunction?(message:NSLocalizedString("I_ImageDisplayView_PhotoProcessCompletion", comment: ""), duration: 0.5)
                    })
                    NSNotificationCenter.defaultCenter().postNotificationName(NOTIFICATION_PHOTOCOMPLETION, object: nil, userInfo: [ "RESULT" : true])
                })
            }else
            {
                dispatch_async(dispatch_get_main_queue(), {
                    self.hudHideWithFunction?(message:NSLocalizedString("I_ImageDisplayView_PhotoProcessError", comment: ""), duration: 2.0)
                })
                NSNotificationCenter.defaultCenter().postNotificationName(NOTIFICATION_PHOTOCOMPLETION, object: nil, userInfo: [ "RESULT" : false])
            }
        }
    }
    
    private func generateMetadataWith(info : [String : AnyObject] , completion : (metadata : [String : AnyObject]) -> Void)
    {
        var metadata = info[UIImagePickerControllerMediaMetadata] as! [String : AnyObject]
        self.generateEXIFInfoWith(metadata) { (exifInfo) in
            metadata[String(kCGImagePropertyExifDictionary)] = exifInfo
            completion(metadata: metadata)
        }
    }
    
    private func generateEXIFInfoWith(metadata : [String : AnyObject] , completion : (exifInfo : [String : AnyObject]) -> Void)
    {
        var exifDic = metadata[String(kCGImagePropertyExifDictionary)] as! [String : AnyObject]
        self.generateValidCNSPInfo { (cnspInfo) in
            exifDic[String(kCGImagePropertyExifCameraOwnerName)] = HelperManager.convertAnyObjectToString(cnspInfo)
            completion(exifInfo: exifDic)
        }
    }
    
    private func generateValidCNSPInfo(completion : (cnspInfo : [String : AnyObject]) -> Void)
    {
        var cnspInfoDic                   = [String : AnyObject]()
        cnspInfoDic["UserID"]             = AccountManager.username()!
        cnspInfoDic["IsServerTime"]       = false
        cnspInfoDic["IsSalesPortalPhoto"] = true
        cnspInfoDic["ServerTime"]         = "\(NSDate().dateByAddingTimeInterval(3600*8))"
        
        LocationManager.sharedManager.completion = { (isSuccess , location , address) in
            if isSuccess == true
            {
                cnspInfoDic["Latitude"]           = Double(location!.coordinate.latitude)
                cnspInfoDic["Longitude"]          = Double(location!.coordinate.longitude)
                cnspInfoDic["Location"]           = address!
                completion(cnspInfo: cnspInfoDic)
            }else
            {
                cnspInfoDic["Latitude"]           = 10000
                cnspInfoDic["Longitude"]          = 10000
                cnspInfoDic["Location"]           = "定位失败"
                completion(cnspInfo: cnspInfoDic)
            }
        }
        LocationManager.sharedManager.startLocate()
    }
}

//MARK:- PROCESS LIBRARY PHOTO
extension CHIEFHandler
{
    private func processLibraryPhotoWith(info : [String : AnyObject])
    {
        let url = info[UIImagePickerControllerReferenceURL] as! NSURL
        let library = ALAssetsLibrary()
        
        library.assetForURL(url, resultBlock: { (asset) in
            let metadata    = asset.defaultRepresentation().metadata()
            let newMetadata = self.generateLibraryPhotoMetadataWith(metadata as! [String : AnyObject])
            let image       = info[UIImagePickerControllerOriginalImage] as! UIImage
            let result      = self.addMetadataToImage(image, metadata: newMetadata)
            if result.success == true
            {
                self.savePhotoToFolder(result.metadataImageData!)
                dispatch_async(dispatch_get_main_queue(), {
                    self.hudHideWithFunction?(message:NSLocalizedString("I_ImageDisplayView_PhotoProcessCompletion", comment: ""), duration: 0.5)
                })
            }else
            {
                dispatch_async(dispatch_get_main_queue(), {
                    self.hudHideWithFunction?(message:NSLocalizedString("I_ImageDisplayView_PhotoProcessError", comment: ""), duration: 2.0)
                })
            }
            NSNotificationCenter.defaultCenter().postNotificationName(NOTIFICATION_PHOTOCOMPLETION, object: nil, userInfo: [ "RESULT" : result.success])
        }) { (error) in
            dispatch_async(dispatch_get_main_queue(), {
                self.hudHideWithFunction?(message:NSLocalizedString("I_ImageDisplayView_PhotoProcessError", comment: ""), duration: 2.0)
            })
            NSNotificationCenter.defaultCenter().postNotificationName(NOTIFICATION_PHOTOCOMPLETION, object: nil, userInfo: [ "RESULT" : false])
        }
    }
    
    private func generateLibraryPhotoMetadataWith(metadata : [String : AnyObject]) -> [String : AnyObject]
    {
        var newMetadata = metadata
        
        guard let exifDic = metadata[String(kCGImagePropertyExifDictionary)] as? [String : AnyObject] else
        {
            newMetadata[String(kCGImagePropertyExifDictionary)] = self.generateEmptyExifInfo()
            return newMetadata
        }
        
        guard let _ = exifDic[String(kCGImagePropertyExifCameraOwnerName)] as? String else
        {
            var newEXIFDic = exifDic
            let cnspInfo = self.generateInvalidCNSPInfo()
            newEXIFDic[String(kCGImagePropertyExifCameraOwnerName)] = HelperManager.convertAnyObjectToString(cnspInfo)
            newMetadata[String(kCGImagePropertyExifDictionary)]     = newEXIFDic
            return newMetadata
        }
        
        return newMetadata
    }
    
    private func generateEmptyExifInfo() -> [String : AnyObject]
    {
        var exifDic = [String : AnyObject]()
        let cnspInfo = self.generateInvalidCNSPInfo()
        exifDic[String(kCGImagePropertyExifCameraOwnerName)] = HelperManager.convertAnyObjectToString(cnspInfo)
        
        return exifDic
    }
    
    private func generateInvalidCNSPInfo() -> [String : AnyObject]
    {
        var cnspInfoDic                   = [String : AnyObject]()
        cnspInfoDic["UserID"]             = AccountManager.username()!
        cnspInfoDic["IsServerTime"]       = false
        cnspInfoDic["IsSalesPortalPhoto"] = false
        cnspInfoDic["Latitude"]           = 10000
        cnspInfoDic["Longitude"]          = 10000
        cnspInfoDic["Location"]           = "非Sales Portal拍摄的图片，无法正确获取地理位置信息"
        cnspInfoDic["ServerTime"]         = "0000-00-00 00:00:00"
        
        return cnspInfoDic
    }
}

//MARK:- CHECK FUNCTIONS
extension CHIEFHandler
{
    func checkCameraAuthorization() -> Bool
    {
        let status = AVCaptureDevice.authorizationStatusForMediaType(AVMediaTypeVideo)
        switch status {
        case .Denied:
            return false
        case .Restricted:
            return false
        case .NotDetermined:
            return true
        case .Authorized:
            return true
        }
    }
    
    func checkCameraAvaliable() -> Bool
    {
        return UIImagePickerController.isSourceTypeAvailable(.Camera)
    }
    
    func chechPhotoLibraryAuthorization() -> Bool
    {
        let status = PHPhotoLibrary.authorizationStatus()
        switch status {
        case .Denied:
            return false
        case .Restricted:
            return false
        case .NotDetermined:
            return true
        case .Authorized:
            return true
        }
    }
    
    func checkPhotoLibraryAvaliable() -> Bool
    {
        return UIImagePickerController.isSourceTypeAvailable(.PhotoLibrary)
    }
}
















