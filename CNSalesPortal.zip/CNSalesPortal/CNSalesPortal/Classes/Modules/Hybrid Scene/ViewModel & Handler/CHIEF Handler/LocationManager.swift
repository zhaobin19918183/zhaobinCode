//
//  LocationService.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/6/29.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class LocationManager : NSObject , CLLocationManagerDelegate
{
    static let sharedManager = LocationManager()
    
    var manager = CLLocationManager()
    var completion : ((isSuccess : Bool , location : CLLocation? , address : String? ) -> Void)!
    var isCompletion = true
    
    private override init(){}
}

extension LocationManager
{
    func startLocate()
    {
        isCompletion = true
        guard CLLocationManager.locationServicesEnabled() == true else
        {
            self.completion(isSuccess: false, location: nil, address: nil)
            return
        }
        
        guard CLLocationManager.authorizationStatus() != .Denied else
        {
            self.completion(isSuccess: false, location: nil, address: nil)
            return
        }
        
        guard CLLocationManager.authorizationStatus() != .Restricted else
        {
            self.completion(isSuccess: false, location: nil, address: nil)
            return
        }
        
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.startUpdatingLocation()
    }
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        manager.stopUpdatingLocation()
        
        if isCompletion == true
        {
            isCompletion = false
            let location = locations.first!
            self.getGEOCoderAddress(location)
        }
    }
    
    private func getGEOCoderAddress(location : CLLocation)
    {
        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(location) { (placemarks, error) in
            if error != nil
            {
                self.completion!(isSuccess: false, location: nil, address: nil)
            }
            
            var plackmark : CLPlacemark?
            if placemarks?.count > 0
            {
                plackmark = placemarks![0]
            }else
            {
                self.completion!(isSuccess: false, location: nil, address: nil)
            }
            
            if let addresses = plackmark?.addressDictionary?["FormattedAddressLines"]
            {
                self.completion!(isSuccess: true, location: location, address: addresses.firstObject as? String)
            }
        }
    }
}
