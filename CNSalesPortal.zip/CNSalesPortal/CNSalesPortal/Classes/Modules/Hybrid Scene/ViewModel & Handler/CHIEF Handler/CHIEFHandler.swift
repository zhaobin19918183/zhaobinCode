//
//  CHIEFHandler.swift
//  CNSalesPortal
//
//  Created by Kilin on 16/5/27.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class CHIEFHandler
{
    var bridge : WebViewJavascriptBridge!
    var model  : AppModel!
    var scheme : String?
    var schemeFirstUsed  = false
    var schemeSecondUsed = false
    
    var showAlertFunction : ((title : String , message : String , confirmAction : UIAlertAction , cancelAction : UIAlertAction?) -> Void)?
    var backToHomeFunction : (() -> Void)?
    var showAttachmentFunction : ((touchX : NSNumber , touchY : NSNumber) -> Void)?
    var hudIndicatorFunction : ((message : String) -> Void)?
    var hudHideWithFunction : ((message : String , duration : NSTimeInterval) -> Void)?
    var displayAttachmentImageFunciton : ((path : String) -> Void)?
    var enableWebView : (() -> Void)?
    var disableWebView : (() -> Void)?
    
    func setupWith(webView : UIWebView! , model : AppModel)
    {
        self.bridge = WebViewJavascriptBridge.bridgeForWebView(webView, handler: nil) as! WebViewJavascriptBridge
        self.model  = model
    }
    
    func attachmentFolder() -> String
    {
        return PATH_FOLDER_APP + self.model.unzipedAPPFolderName() + "/AttachmentFolders"
    }
    
    func createAttachmentFolder()
    {
        EnvironmentManager.generateForlderWith(self.attachmentFolder())
    }
    
    func registerBridgeHandler()
    {
        self.bridge.registerHandler("ios_Js_NormarlFunction") { (data, callback) in
            self.handleCommonRequestWith(data)
        }

        self.bridge.registerHandler("IOS_JS_Attachment") { (data, callback) in
            self.handleAttachmentRequestWith(data)
        }
        
        self.bridge.registerHandler("ajaxCallWebMethod") { (data, callback) in
            self.handleNetworkRequestWith(data)
        }
    }
}

//MARK:- COMMON CALLBACK HANDLER
extension CHIEFHandler
{
    func callbackHandlerSuccess(handlerName handlerName : String , message : String)
    {
        var callbackData = [String]()
        callbackData.append("OK")
        callbackData.append(message)
        self.bridge.callHandler(handlerName, data: HelperManager.convertAnyObjectToString(callbackData))
    }
    
    func callbackHandlerFailure(handlerName handlerName : String , message : String)
    {
        var callbackData = [String]()
        callbackData.append("ERROR_NORMAL")
        callbackData.append(message)
        self.bridge.callHandler(handlerName, data: HelperManager.convertAnyObjectToString(callbackData))
    }
    
    func callbackHandlerFailureBlock(handlerName handlerName : String , message : String)
    {
        var callbackData = [String]()
        callbackData.append("ERROR_BLOCK")
        callbackData.append(message)
        self.bridge.callHandler(handlerName, data: HelperManager.convertAnyObjectToString(callbackData))
    }
}

//MARK:- STATIC FUNCTIONS
extension CHIEFHandler
{
    static func indexHTMLPath(model : AppModel) -> (hasPath : Bool , path : String)
    {
        let indexPath = PATH_FOLDER_APP + model.unzipedAPPFolderName() + "/index.htm"
        
        return (NSFileManager.defaultManager().fileExistsAtPath(indexPath) , indexPath)
    }
}
