//
//  ExtensionHandlerAttachment.swift
//  CNSalesPortal
//
//  Created by Kilin on 16/5/30.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

enum AttachmentOperationType : Int {
    case Show       = 0
    case Clear      = 1
    case Upload     = 2
    case Download   = 3
    case Delete     = 4
    case Unknown    = 999
    
    static func convertToAttachmentOperationType(number : Int) -> AttachmentOperationType
    {
        switch number {
        case 0:
            return .Show
        case 1:
            return .Clear
        case 2:
            return .Upload
        case 3:
            return .Download
        case 4:
            return .Delete
        default :
            return .Unknown
        }
    }
}

extension CHIEFHandler
{
    func handleAttachmentRequestWith(data : AnyObject)
    {
        AttachmentDataManager.sharedManager.setupWith(data as! [String : AnyObject])
        guard let dataType = data["DataType"] as? NSNumber else
        {
            let callbackHandlerName = AttachmentDataManager.sharedManager.data["CallBackHandlerName"] as! String
            self.callbackHandlerFailure(handlerName: callbackHandlerName, message: "DataType is wrong.")
            return
        }
        
        let attachmentOperationType = AttachmentOperationType.convertToAttachmentOperationType(Int(dataType))
        switch attachmentOperationType {
        case .Show:
            self.showAttachmentOperationList(data)
        case .Clear:
            self.clearAttachmentFolder()
        case .Upload:
            self.uploadAttachments()
        case .Download:
            self.downloadAttachment()
        case .Delete:
            self.deleteAttachment()
        default :
            let callbackHandlerName = AttachmentDataManager.sharedManager.data["CallBackHandlerName"] as! String
            self.callbackHandlerFailure(handlerName: callbackHandlerName, message: "DataType is wrong.")
        }
    }
}

//MARK:- SHOW ATTACHMENT LIST FUNCTIONS
extension CHIEFHandler
{
    private func showAttachmentOperationList(data : AnyObject)
    {
        let touchPosX = data["TouchPosX"] as! NSNumber
        let touchPosY = data["TouchPosY"] as! NSNumber
        
        self.showAttachmentFunction?(touchX: touchPosX, touchY: touchPosY)
    }
    
    func addPhotoNotificaions()
    {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(CHIEFHandler.attachmentChoosePhtoCompletion(_:)), name: NOTIFICATION_PHOTOCOMPLETION, object: nil)
    }
    
    func removePhotoNotifications()
    {
        NSNotificationCenter.defaultCenter().removeObserver(self, name: NOTIFICATION_PHOTOCOMPLETION, object: nil)
    }
    
    @objc func attachmentChoosePhtoCompletion(sender : AnyObject)
    {
        let result  = sender.valueForKey("userInfo") as! [String : AnyObject]
        let success = result["RESULT"] as! Bool
        
        self.sendImageToJS(success)
    }
    
    private func sendImageToJS(success : Bool)
    {
        let touchbuttonID       = AttachmentDataManager.sharedManager.data["TouchButtonID"]       as! String
        let photoName           = AttachmentDataManager.sharedManager.data["AttachmentName"]      as! String
        let callbackHandlerName = AttachmentDataManager.sharedManager.data["CallBackHandlerName"] as! String
        
        var callbackData = [AnyObject]()
        callbackData.append(touchbuttonID)
        callbackData.append(photoName)
        callbackData.append([String : AnyObject]())
        self.bridge.callHandler(callbackHandlerName, data: HelperManager.convertAnyObjectToString(callbackData))
    }
}

//MARK:- UPLOAD ATTACHMENTS
extension CHIEFHandler
{
    private func uploadAttachments()
    {
        let attachmentList      = AttachmentDataManager.sharedManager.data["AttachmentNameList"] as! NSArray
        let fileUploadURLString = AttachmentDataManager.sharedManager.data["FileUploadURL"] as! String
        
        let totalFileCount      = attachmentList.count
        var uploadFileCount     = 0
        var uploadSuccess       = true
        var errorMessage        = ""

        attachmentList.enumerateObjectsUsingBlock { (obj, idx, stop) in
            let fileName = obj as! String
            let filePath = self.attachmentFolder() + "/" + fileName
            let fileURL  = NSURL(fileURLWithPath: filePath)
            
            LoggerManager.appendLogger("上传附件到CHIEF服务器。")
            NetworkManager.sharedManager.uploadMultipartForm(URL: fileUploadURLString, uploadFileURL: fileURL, completion: { (response) in
                uploadFileCount += 1
                if let result = response.result.value where result != "OK"
                {
                    errorMessage = NSLocalizedString("I_Error_SOAG_Data", comment: "")
                    uploadSuccess = false
                    LoggerManager.appendLogger("上传附件失败，response = \(response)")
                }
                
                if uploadFileCount == totalFileCount
                {
                    LoggerManager.appendLogger("上传附件到CHIEF服务器成功。")
                    self.checkUploadCompletion(uploadSuccess, errorMessage: errorMessage)
                }
            })
        }
    }
    
    private func checkUploadCompletion(success : Bool , errorMessage : String)
    {
        let callbackHandlerName = AttachmentDataManager.sharedManager.data["CallBackHandlerName"] as! String
        if success == true
        {
            EnvironmentManager.clearFolderWith(self.attachmentFolder())
            self.callbackHandlerSuccess(handlerName: callbackHandlerName, message: "OK")
        }else
        {
            self.callbackHandlerFailure(handlerName: callbackHandlerName, message: errorMessage)
        }
    }
}

//MARK:- DOWNLOAD ATTACHMENTS
extension CHIEFHandler
{
    private func downloadAttachment()
    {
        let callbackHandlerName = AttachmentDataManager.sharedManager.data["CallBackHandlerName"] as! String
        
        if self.checkAtttachmentExist() == true
        {
            self.displayAttachmentImage()
            self.callbackHandlerSuccess(handlerName: callbackHandlerName, message: "Attachment already downloaded.")
        }else
        {
            let urlString = self.getAttachmentDownloadURLString()
            LoggerManager.appendLogger("从CHIEF服务器下载附件。")
            NetworkManager.sharedManager.download(URL: urlString, CompleteBytes: {(completeBytes) in}, CompletionHandlerResponse: { (request, response, data, error) in
                if response?.statusCode == 200
                {
                    LoggerManager.appendLogger("从CHIEF服务器下载附件成功。")
                    let fileManager = NSFileManager.defaultManager()
                    do{
                        try fileManager.moveItemAtPath(TEMPPATH + "/" + self.getAttachmentName(), toPath: self.getAttachmentPath())
                    }catch
                    {
                        self.callbackHandlerFailure(handlerName: callbackHandlerName, message: "Attachment download failure.")
                        return
                    }
                    self.displayAttachmentImage()
                    self.callbackHandlerSuccess(handlerName: callbackHandlerName, message: "OK")
                }else
                {
                    LoggerManager.appendLogger("从CHIEF服务器下载附件失败，response = \(response)")
                    self.callbackHandlerFailure(handlerName: callbackHandlerName, message: "Attachment download failure.")
                }
            })
        }
    }
    
    private func displayAttachmentImage()
    {
        self.displayAttachmentImageFunciton?(path: self.getAttachmentPath())
    }
    
    private func checkAtttachmentExist() -> Bool
    {
        let downloadedAttachmentPath = self.getAttachmentPath()
        let fileManager = NSFileManager.defaultManager()
        if fileManager.fileExistsAtPath(downloadedAttachmentPath)
        {
            return true
        }else
        {
            return false
        }
    }
    
    private func getAttachmentDownloadURLString() -> String
    {
        if let attachmentURL = AttachmentDataManager.sharedManager.data["AttachmentDownloadUrl"] as? String
        {
            return attachmentURL
        }else
        {
            return ""
        }
    }
    
    private func getAttachmentName() -> String
    {
        if let attachmentName = AttachmentDataManager.sharedManager.data["AttachmentName"] as? String
        {
            return attachmentName
        }else
        {
            return ""
        }
    }
    
    private func getAttachmentPath() -> String
    {
        return self.attachmentFolder() + "/" + self.getAttachmentName()
    }
}

//MARK:- DELETE AND CLEAR ATTACHMENT
extension CHIEFHandler
{
    private func clearAttachmentFolder()
    {
        EnvironmentManager.clearFolderWith(self.attachmentFolder())
    }
    
    private func deleteAttachment()
    {
        let touchbuttonID  = AttachmentDataManager.sharedManager.data["TouchButtonID"]  as! String
        let photoName      = AttachmentDataManager.sharedManager.data["AttachmentName"] as! String
        
        let deleteFilePath = self.attachmentFolder() + "/" + photoName
        EnvironmentManager.deleteFileWith(deleteFilePath)
        
        let callbackHandlerName = AttachmentDataManager.sharedManager.data["CallBackHandlerName"] as! String
        self.callbackHandlerSuccess(handlerName: callbackHandlerName, message: touchbuttonID)
    }
}







