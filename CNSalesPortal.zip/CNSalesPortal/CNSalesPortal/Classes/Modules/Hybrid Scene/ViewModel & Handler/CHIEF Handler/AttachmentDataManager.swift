//
//  AttachmentDataManager.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/6/1.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

struct AttachmentDataManager
{
    static var sharedManager = AttachmentDataManager()
    private init(){}
    
    var data = [String : AnyObject]()
    
    mutating func setupWith(data : [String : AnyObject])
    {
        self.data = data
    }
}
