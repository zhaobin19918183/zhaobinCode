//
//  ExtensionHandlerCommon.swift
//  CNSalesPortal
//
//  Created by Kilin on 16/5/30.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

enum NormalHandlerType : Int {
    case showAlert       = 0
    case BackToHome      = 1
    case LaunchByScheme  = 2
    case Unknown         = 999
    
    static func convertToNormalHandlerType(number : Int) -> NormalHandlerType
    {
        switch number {
        case 0:
            return .showAlert
        case 1:
            return .BackToHome
        case 2:
            return .LaunchByScheme
        default :
            return .Unknown
        }
    }
}

extension CHIEFHandler
{
    func handleCommonRequestWith(data : AnyObject)
    {
        guard let dataType = data["DataType"] as? NSNumber else
        {
            let callbackHandlerName = data["CallBackHandlerName"] as! String
            self.callbackHandlerFailure(handlerName: callbackHandlerName, message: "Data type is unknown.")
            return
        }
        
        let normalHandlerType = NormalHandlerType.convertToNormalHandlerType(Int(dataType))
        
        switch normalHandlerType {
        case .showAlert :
            self.showAlert(data)
        case .BackToHome:
            self.backToHome()
        case .LaunchByScheme:
            self.launchByScheme(data)
        default:
            let callbackHandlerName = data["CallBackHandlerName"] as! String
            self.callbackHandlerFailure(handlerName: callbackHandlerName, message: "Data type is wrong.")
        }
    }
}

extension CHIEFHandler
{
    private func showAlert(data : AnyObject)
    {
        let callbackHandlerName = data["CallBackHandlerName"] as! String
        
        guard let isConfirmed = data["IsConfirmAlertView"] else
        { 
            self.callbackHandlerFailure(handlerName: callbackHandlerName, message: "IsConfirmAlertView is empty.")
            return
        }
        
        let isConfirmedAlertView = isConfirmed?.boolValue
        
        var title = ""
        if let string = data["AlertTitle"] as? String
        {
            title = string
        }
        
        var message = ""
        if let string = data["AlertMessage"] as? String
        {
            message = string
        }
        
        let cancelButtonTitle = NSLocalizedString("I_Common_NO", comment: "")
        
        let cancelAction = UIAlertAction(title: cancelButtonTitle, style: .Default) { (action) in
            self.bridge.callHandler(callbackHandlerName, data: "\"NO\"")
        }
        
        let confirmButtonTitle = isConfirmedAlertView == true ? NSLocalizedString("I_Common_YES", comment: "") : NSLocalizedString("I_Common_OK", comment: "")
        let confirmAction = UIAlertAction(title: confirmButtonTitle, style: .Default) { (action) in
            self.bridge.callHandler(callbackHandlerName, data: isConfirmedAlertView == true ? "\"YES\"" : "\"OK\"")
        }
        
        if isConfirmedAlertView == true
        {
            self.showAlertFunction?(title: title, message: message, confirmAction: confirmAction, cancelAction: cancelAction)
        }else
        {
            self.showAlertFunction?(title: title, message: message, confirmAction: confirmAction, cancelAction: nil)
        }
    }
    
    private func backToHome()
    {
        self.backToHomeFunction?()
    }
    
    private func launchByScheme(data : AnyObject)
    {
        let callbackHandlerName = data["CallBackHandlerName"] as? String
        let callbackData        = NSMutableDictionary()
        
        if let scheme = self.scheme
        {
            if self.schemeFirstUsed == false
            {
                callbackData["value"] = "NOTEMPTY"
                callbackData["mailLink1"] = scheme
                callbackData["mailLink"] = "mailLink1"
                self.schemeFirstUsed = true
            }else if self.schemeSecondUsed == false
            {
                callbackData["value"] = "NOTEMPTY"
                callbackData["mailLink2"] = scheme
                callbackData["mailLink"] = "mailLink2"
                self.schemeSecondUsed = true
            }
        }else
        {
            callbackData["value"] = "EMPTY"
        }
        
        self.bridge.callHandler(callbackHandlerName, data: HelperManager.convertAnyObjectToString(callbackData))
    }
}














