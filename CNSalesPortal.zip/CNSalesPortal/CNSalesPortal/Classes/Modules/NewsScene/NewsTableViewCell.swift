//
//  NewsTableViewCell.swift
//  CN SalesPortal
//
//  Created by Zhao.bin on 16/6/21.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class NewsTableViewCell: UITableViewCell {

    @IBOutlet weak var backVIew: UIView!
    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var newsImageView: UIImageView!
    @IBOutlet weak var newsTitleLabel: UILabel!
    @IBOutlet weak var newsDateLabel: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }

    func setupNews(info : [String : AnyObject])
    {
        if let imageString = info["Image"] as? String where imageString.characters.count > 0
        {
            let decodedData =
                NSData(base64EncodedString:imageString, options:NSDataBase64DecodingOptions())
            let decodedimage = UIImage(data: decodedData!)! as UIImage
            self.newsImageView.image = decodedimage
            self.dayLabel.hidden = true
            self.monthLabel.hidden = true
            self.backVIew.hidden = true
        }
        else
        {
            self.dayLabel.hidden = false
            self.monthLabel.hidden = false
            self.backVIew.hidden = false
        }
        
        if let title = info["Title"] as? String
        {
            self.newsTitleLabel.text = title
        }
        
//        if let dateString = info["CreateTime"] as? String
//        {
//            self.newsDateLabel.text = HelperManager.convertServerTimeToLocalTime(dateString)
//            let dayAndMonth = HelperManager.convertServerTimeToDateString(dateString)
//            self.dayLabel.text = dayAndMonth.day
//            self.monthLabel.text = dayAndMonth.month
//        }
    }
}