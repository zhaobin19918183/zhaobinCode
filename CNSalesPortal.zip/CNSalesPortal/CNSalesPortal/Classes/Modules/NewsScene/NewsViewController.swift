//
//  NewsViewController.swift
//  CN SalesPortal
//
//  Created by Zhao.bin on 16/6/21.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class NewsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UIWebViewDelegate {
    
    @IBOutlet weak var _newsView: NewsView!
    @IBOutlet weak var newsWebView: UIWebView!
    @IBOutlet weak var newsTableVIew: UITableView!
    
    var  index = Int()
    var  newsDataArray = NSMutableArray()
    var progressHUD : MBProgressHUD!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        LoggerManager.appendLogger("Come in News view controller.")
        self.navigationItem.title = "News"
    }
 
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCellWithIdentifier("NewsTableViewCellID", forIndexPath: indexPath) as! NewsTableViewCell
        let infoDic = self.newsDataArray.objectAtIndex(indexPath.row) as? [String : AnyObject]
        if (infoDic != nil)
        {
            cell.setupNews(infoDic!)
        }
        if indexPath.row == self.index
        {
            self.setupNewsCellData(indexPath ,cell: cell)
        }
        else if self.index == -1 && indexPath.row == 0
        {
            self.setupNewsCellData(indexPath,cell: cell)
        }
        else
        {
            cell.backgroundColor = UIColor.whiteColor()
        }
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! NewsTableViewCell
        cell.backgroundColor = UIColor(red: 236/255, green: 241/255, blue: 245/255, alpha: 1)
        if let infoDic = self.newsDataArray.objectAtIndex(indexPath.row) as? [String : AnyObject]
        {
            _newsView.setupNewsWebViewTitle(infoDic)
        }
        
        if indexPath.row != index
        {
            self.index = indexPath.row
            tableView.reloadData()
        }
        let dicData = self.newsDataArray.objectAtIndex(indexPath.row) as! [String:AnyObject]
        let newID = String(format:"%@",dicData["Id"] as! NSNumber)
        self.newsNetWorkData(newID)
    }
    
    
    func tableView(tableView: UITableView, didDeselectRowAtIndexPath indexPath: NSIndexPath)
    {
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! NewsTableViewCell
        cell.backgroundColor = UIColor.whiteColor()
    }
    
    func  setupNewsCellData(indexPath:NSIndexPath,cell:NewsTableViewCell)
    {
        cell.backgroundColor = UIColor(red: 236/255, green: 241/255, blue: 245/255, alpha: 1)
        let infoDic = self.newsDataArray.objectAtIndex(indexPath.row) as? [String : AnyObject]
        _newsView.setupNewsWebViewTitle(infoDic!)
        let dicData = self.newsDataArray.objectAtIndex(indexPath.row) as! [String:AnyObject]
        self.hudHideManuallyWith(NSLocalizedString("I_News_TopNews", comment: ""), duration: 0.5)
        let newID   = String(format:"%@",dicData["Id"] as! NSNumber)
        self.newsNetWorkData(newID)
    }
    
    func newsNetWorkData(newsId:String)
    {
        LoggerManager.appendLogger(self)
        NetworkManager.sharedManager.get(URL:NetworkManager.getNewsBodyURLString(newsId), Parameters:nil) { (response) in
            let (state , result) = NetworkManager.checkResponse(response)
            if state == .Success
            {
                LoggerManager.appendLogger(self)
                let informations = result as! [String : AnyObject]
                let bodyString   = informations["Body"] as! String
                self.newsWebView.loadHTMLString(bodyString, baseURL: nil)
            }
            else
            {
                LoggerManager.appendLogger("获取新闻内容失败，response = \(response)")
            }
        }
    }
 
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.newsDataArray.count
    }

    func webViewDidFinishLoad(webView: UIWebView)
    {
        self.progressHUD.hide(true)
    }
    func webView(webView: UIWebView, shouldStartLoadWithRequest request: NSURLRequest, navigationType: UIWebViewNavigationType) -> Bool
    {
        UIApplication.sharedApplication().openURL(request.URL!)
        return true
    }
   

    func hudHideManuallyWith(message : String, duration : NSTimeInterval)
    {
        self.progressHUD = MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        self.progressHUD.labelText = message
        self.progressHUD.dimBackground = true
    }
}