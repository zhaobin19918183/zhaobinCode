//
//  NewsView.swift
//  CN SalesPortal
//
//  Created by Zhao.bin on 16/6/27.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class NewsView: UIView {
    
    @IBOutlet weak var NewsMonthLabel: UILabel!
    @IBOutlet weak var NewsDayLabel: UILabel!
    @IBOutlet weak var newsTitleDateLabel: UILabel!
    @IBOutlet weak var newsTitleLabel: UILabel!
    @IBOutlet weak var newsTitleVIew: UIView!
    @IBOutlet weak var NewsTitleImage: UIImageView!
    @IBOutlet var _newsView: NewsView!
    
    required init(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)!
        resetUILayout()
    }
    
    func setupNewsWebViewTitle(info:[String:AnyObject])
    {
        if let title = info["Title"] as? String
        {
            self.newsTitleLabel.text = title
        }
        if let dateString = info["CreateTime"] as? String
        {
//            self.newsTitleDateLabel.text = HelperManager.convertServerTimeToLocalTime(dateString)
        }
        if let imageString = info["Image"] as? String where imageString.characters.count > 0
        {
            self.NewsTitleImage.hidden = false
            let decodedData =
                NSData(base64EncodedString:imageString, options:NSDataBase64DecodingOptions())
            let decodedimage = UIImage(data: decodedData!)! as UIImage
            self.NewsTitleImage.image = decodedimage
            self.NewsDayLabel.hidden = true
            self.NewsMonthLabel.hidden = true
        }
        else
        {
            if let dateString = info["CreateTime"] as? String
            {
//                let dayAndMonth = HelperManager.convertServerTimeToDateString(dateString)
//                self.NewsDayLabel.text = dayAndMonth.day
//                self.NewsMonthLabel.text = dayAndMonth.month
            }
            self.NewsTitleImage.hidden = true
            self.NewsDayLabel.hidden = false
            self.NewsMonthLabel.hidden = false
        }
    }
    
    func resetUILayout()
    {
        NSBundle.mainBundle().loadNibNamed("NewsView", owner:self,options:nil)
        self.newsTitleVIew.backgroundColor = UIColor.blackColor().colorWithAlphaComponent(0.5)
        self.addSubview(_newsView)
    }
}
