//
//  UIViewController+MBHUDProgress.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/5/17.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

protocol HUDOperable
{
    var hud : MBProgressHUD { get }
    
    func hudAwaysShowWith(message : String)
    func hudAwaysShowIndicatorWith(message : String)
    func hudHideManuallyWith(message : String , duration : NSTimeInterval)
}

extension HUDOperable
{
    func hudAwaysShowWith(message : String)
    {
        dispatch_async(dispatch_get_main_queue())
        {
            self.hud.show(true)
            self.hud.mode = MBProgressHUDModeText
            self.hud.labelText = message
        }
    }

    func hudAwaysShowIndicatorWith(message : String)
    {
        dispatch_async(dispatch_get_main_queue())
        {
            self.hud.show(true)
            self.hud.mode = MBProgressHUDModeIndeterminate
            self.hud.labelText = message
        }
    }
    
    func hudHideManuallyWith(message : String, duration : NSTimeInterval)
    {
        dispatch_async(dispatch_get_main_queue())
        {
            self.hud.show(true)
            self.hud.mode = MBProgressHUDModeText
            self.hud.labelText = message
            self.hud.hide(true, afterDelay: duration)
        }
    }
}









