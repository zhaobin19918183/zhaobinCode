//
//  UIImagePickerControllerRotation.swift
//  CNSalesPortal
//
//  Created by Kilin on 16/6/1.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

extension UIImagePickerController
{
    public override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask
    {
        return .Landscape
    }
    
    public override func preferredStatusBarStyle() -> UIStatusBarStyle
    {
        return .LightContent
    }
    
    public override func prefersStatusBarHidden() -> Bool
    {
        return true
    }
}
