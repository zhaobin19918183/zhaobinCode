//
//  Ex_Alert.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/6/3.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

protocol AlertDisplayable
{
    func showAlertWith(title : String , message : String , confirmAction : UIAlertAction , cancelAction : UIAlertAction?)
}

extension AlertDisplayable where Self : UIViewController
{
    func showAlertWith(title : String , message : String , confirmAction : UIAlertAction , cancelAction : UIAlertAction?)
    {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        
        if let action = cancelAction
        {
            alertController.addAction(action)
        }
        
        alertController.addAction(confirmAction)
        self.presentViewController(alertController, animated: true, completion: nil)
    }
}

