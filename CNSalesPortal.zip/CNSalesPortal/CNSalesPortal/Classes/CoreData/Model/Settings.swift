//
//  Settings.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/7/6.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import Foundation
import CoreData


class Settings: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
