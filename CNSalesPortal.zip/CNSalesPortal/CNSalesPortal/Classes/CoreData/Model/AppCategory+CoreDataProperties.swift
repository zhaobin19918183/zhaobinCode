//
//  AppCategory+CoreDataProperties.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/5/18.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension AppCategory {

    @NSManaged var index: NSNumber?
    @NSManaged var name: String?

}
