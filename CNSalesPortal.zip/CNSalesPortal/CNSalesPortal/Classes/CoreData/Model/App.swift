//
//  App.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/5/18.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import Foundation
import CoreData


class App: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
