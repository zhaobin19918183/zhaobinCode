//
//  News.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/7/7.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import Foundation
import CoreData


class News: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
