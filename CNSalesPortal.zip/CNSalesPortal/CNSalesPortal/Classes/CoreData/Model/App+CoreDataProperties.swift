//
//  App+CoreDataProperties.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/5/18.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension App {

    @NSManaged var category: NSNumber?
    @NSManaged var checkCode: String?
    @NSManaged var createTime: String?
    @NSManaged var appDescription: String?
    @NSManaged var fileSize: NSNumber?
    @NSManaged var icon: String?
    @NSManaged var appID: NSNumber?
    @NSManaged var isMandatoryPackage: NSNumber?
    @NSManaged var isMandatoryVersion: NSNumber?
    @NSManaged var isNew: NSNumber?
    @NSManaged var isPopupLink: NSNumber?
    @NSManaged var navigationLink: String?
    @NSManaged var order: NSNumber?
    @NSManaged var package: String?
    @NSManaged var title: String?
    @NSManaged var userList: String?
    @NSManaged var version: NSNumber?
    @NSManaged var isPackageDownloadComplete: NSNumber?

}
