//
//  Traning.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/6/3.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import Foundation
import CoreData


class Traning: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
