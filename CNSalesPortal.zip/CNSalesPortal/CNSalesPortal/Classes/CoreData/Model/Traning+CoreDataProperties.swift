//
//  Traning+CoreDataProperties.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/6/3.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension Traning {

    @NSManaged var identify: NSNumber?
    @NSManaged var navigationLink: String?
    @NSManaged var order: NSNumber?
    @NSManaged var title: String?
    @NSManaged var version: NSNumber?

}
