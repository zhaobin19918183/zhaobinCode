//
//  Settings+CoreDataProperties.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/7/6.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension Settings {

    @NSManaged var environment: String?
    @NSManaged var urlLOCAL: String?
    @NSManaged var urlDEV: String?
    @NSManaged var urlQA: String?
    @NSManaged var urlPRD: String?
    @NSManaged var localUser: String?

}
