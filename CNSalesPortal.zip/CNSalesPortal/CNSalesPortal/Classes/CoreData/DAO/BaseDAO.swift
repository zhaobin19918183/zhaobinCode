//
//  BaseDAO.swift
//  Portal
//
//  Created by Kilin on 16/3/16.
//  Copyright © 2016年 Innocellence. All rights reserved.
//

import Foundation
import CoreData

class BaseDAO {
    
    static let managedObjectModel : NSManagedObjectModel = {
        let modelURL = NSBundle.mainBundle().URLForResource("CNSalesPortalCoreData", withExtension: "momd")
        return NSManagedObjectModel(contentsOfURL: modelURL!)!
    }()
    
    static let persistentStoreCoordinator : NSPersistentStoreCoordinator =
    {
        let sqliteURL = NSURL.fileURLWithPath(PATH_FILE_COREDATA)
        let persistentStoreCoordinator = NSPersistentStoreCoordinator(managedObjectModel: BaseDAO.managedObjectModel)
        do
        {
            try persistentStoreCoordinator.addPersistentStoreWithType(NSSQLiteStoreType, configuration: nil, URL: sqliteURL, options: nil)
        }catch
        {
            print("Initial persistent store coordinator failed - \(error)")
            abort()
        }
        
        let fileManager = NSFileManager.defaultManager()
        let attributeDic = NSDictionary(object: NSFileProtectionComplete, forKey: NSFileProtectionKey)
        do{
            try fileManager.setAttributes(attributeDic as! [String : AnyObject], ofItemAtPath: PATH_FOLDER_COREDATA)
        }catch
        {
            print("Protection for coredata failed")
        }
        
        return persistentStoreCoordinator
    }()
    
    static let backgroundMOC : NSManagedObjectContext =
    {
        let coordinator = BaseDAO.persistentStoreCoordinator
        let moc = NSManagedObjectContext(concurrencyType: .PrivateQueueConcurrencyType)
        moc.persistentStoreCoordinator = coordinator
        return moc
    }()
    
    static let mainMOC : NSManagedObjectContext =
    {
        let moc = NSManagedObjectContext(concurrencyType: .MainQueueConcurrencyType)
        moc.parentContext = BaseDAO.backgroundMOC
        return moc
    }()
    
    static func workMOC() -> NSManagedObjectContext
    {
        let moc = NSManagedObjectContext(concurrencyType: .PrivateQueueConcurrencyType)
        moc.parentContext = BaseDAO.mainMOC
        return moc
    }
    
    static func save() -> Bool
    {
        if BaseDAO.mainMOC.hasChanges
        {
            do{
                try BaseDAO.mainMOC.save()
            }catch{
                return false
            }
            
            BaseDAO.backgroundMOC.performBlock { () -> Void in
                do{
                    try BaseDAO.backgroundMOC.save()
                }catch{
                    return
                }
            }
            
            return true
        }else
        {
            return false
        }
    }
}