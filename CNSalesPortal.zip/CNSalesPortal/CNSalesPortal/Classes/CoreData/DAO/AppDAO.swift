//
//  AppDAO.swift
//  Portal
//
//  Created by Kilin on 16/3/16.
//  Copyright © 2016年 Innocellence. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class AppDAO : BaseDAO
{
    //MARK: - COREDATA FUNCTIONS
    static func createAppWith(model : AppModel) -> Bool
    {
        let app = NSEntityDescription.insertNewObjectForEntityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC) as! App
        app.category                  = model.category
        app.checkCode                 = model.checkCode
        app.createTime                = model.createTime
        app.appDescription            = model.appDescription
        app.fileSize                  = model.fileSize
        app.icon                      = model.icon
        app.appID                     = model.appID
        app.isMandatoryPackage        = model.isMandatoryPackage
        app.isMandatoryVersion        = model.isMandatoryVersion
        app.isNew                     = model.isNew
        app.isPopupLink               = model.isPopupLink
        app.navigationLink            = model.navigationLink
        app.order                     = model.order
        app.package                   = model.package
        app.title                     = model.title
        app.userList                  = model.userList
        app.version                   = model.version
        app.isPackageDownloadComplete = model.isPackageDownloadComplete
        
        return self.save()
    }

    static func updateAppWith(model : AppModel) -> Bool
    {
        let app : App? = self.retriveAppWith(model.appID!)
        app!.category                  = model.category
        app!.checkCode                 = model.checkCode
        app!.createTime                = model.createTime
        app!.appDescription            = model.appDescription
        app!.fileSize                  = model.fileSize
        app!.icon                      = model.icon
        app!.appID                     = model.appID
        app!.isMandatoryPackage        = model.isMandatoryPackage
        app!.isMandatoryVersion        = model.isMandatoryVersion
        app!.isNew                     = model.isNew
        app!.isPopupLink               = model.isPopupLink
        app!.navigationLink            = model.navigationLink
        app!.order                     = model.order
        app!.package                   = model.package
        app!.title                     = model.title
        app!.userList                  = model.userList
        app!.version                   = model.version
        app!.isPackageDownloadComplete = model.isPackageDownloadComplete
        
        return self.save()
    }
    
    static func deleteApp(identifier : NSNumber) -> Bool
    {
        if let app = self.retriveAppWith(identifier)
        {
            self.mainMOC.deleteObject(app)
        }
        
        return self.save()
    }
    
    static func retriveApps() -> [App]?
    {
        let fetchRequest = NSFetchRequest()
        fetchRequest.entity = NSEntityDescription.entityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC)
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "order", ascending: true)]
        let apps : [App]?
        do{
            apps = try self.mainMOC.executeFetchRequest(fetchRequest) as? [App]
        }catch{
            apps = nil
        }
        
        return apps
    }
    
    static func retriveAppWith(identifier : NSNumber) -> App?
    {
        let fetchRequest = NSFetchRequest()
        fetchRequest.entity = NSEntityDescription.entityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC)
        fetchRequest.predicate = NSPredicate(format: "appID = %@", identifier)
        
        let app : App?
        do{
            let apps = try self.mainMOC.executeFetchRequest(fetchRequest)
            app = apps.first as? App
        }catch{
            app = nil
        }
        
        return app
    }
    
    static func retriveAppWith(title : String) -> App?
    {
        let fetchRequest = NSFetchRequest()
        fetchRequest.entity = NSEntityDescription.entityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC)
        fetchRequest.predicate = NSPredicate(format: "title = %@", title)
        
        let app : App?
        do{
            let apps = try self.mainMOC.executeFetchRequest(fetchRequest)
            app = apps.first as? App
        }catch{
            app = nil
        }
        
        return app
    }
    
    static func retriveCategoryedAppWith(category : NSNumber) -> [App]?
    {
        let fetchRequest = NSFetchRequest()
        fetchRequest.entity = NSEntityDescription.entityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC)
        fetchRequest.predicate = NSPredicate(format: "category = %@", category)
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "order", ascending: true)]
        
        do{
            let apps = try self.mainMOC.executeFetchRequest(fetchRequest)
            return apps as? [App]
        }catch{
            return nil
        }
    }
    
    static func retriveAppVersions() -> String
    {
        if let localApps = self.retriveApps()
        {
            return localApps.reduce("", combine: { (versionInfo, app) -> String in
                return versionInfo + "\(app.appID!):\(app.version!),"
            })
        }else
        {
            return ""
        }
    }
    
    static func retriveAppWith(category : Int) -> [App]?
    {
        let fetchRequest = NSFetchRequest()
        fetchRequest.entity = NSEntityDescription.entityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC)
        fetchRequest.predicate = NSPredicate(format: "category = \(category)")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "order", ascending: true)]
        
        let apps : [App]?
        do{
            apps = try self.mainMOC.executeFetchRequest(fetchRequest) as? [App]
        }catch{
            apps = nil
        }
        
        return apps
    }
    
    private static func getEntityName() -> String
    {
        return "App"
    }
}

//MARK: - LOGIC FUNCTIONS
extension AppDAO
{
    static func updateMultipleAppWith(models : [AppModel])
    {
        let remainingLocalApps = AppDAO.removeServerDeletedApp(Models: models)
        
        for (_ , model) in models.enumerate()
        {
            let apps = remainingLocalApps?.filter({ (app) -> Bool in
                return app.appID == model.appID
            })
            
            if let app = apps?.first
            {
                if (model.version?.floatValue > app.version?.floatValue)
                {
                    self.updateAppWith(model)
                }else
                {
                    //Don't need to do anything
                }
            }else
            {
                self.createAppWith(model)
            }
        }
    }
    
    //Retrive local apps which is not exist in models and delete it from coredata
    private static func removeServerDeletedApp(Models models : [AppModel]) -> [App]?
    {
        let ids = models.map { $0.appID }
        
        let localApps = AppDAO.retriveApps()
        let deletedApps = localApps?.filter({ (app) -> Bool in
            return !ids.contains({ (id) -> Bool in
                return id == app.appID
            })
        })
        
        for (_ , app) in (deletedApps?.enumerate())!
        {
            AppDAO.deleteApp(app.appID!)
        }
        
        return localApps?.filter({ (app) -> Bool in
            return !(deletedApps?.contains(app))!
        })
    }
    
    static func clearApp()
    {
        if let apps = self.retriveApps()
        {
            for (_ , app) in apps.enumerate()
            {
                self.mainMOC.deleteObject(app)
            }
        }
        
        self.save()
    }
}





