//
//  TraningDAO.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/6/3.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit
import CoreData

class TraningDAO: BaseDAO
{
    //MARK: - COREDATA FUNCTIONS
    static func createTraningWith(model : TraningModel) -> Bool
    {
        let traning = NSEntityDescription.insertNewObjectForEntityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC) as! Traning
        traning.identify        = model.identify
        traning.navigationLink  = model.navigationLink
        traning.order           = model.order
        traning.title           = model.title
        traning.version         = model.version
        
        return self.save()
    }
    
    static func updateTraningWith(model : TraningModel) -> Bool
    {
        if let traning = self.retriveTraningWith(model.identify!)
        {
            traning.identify        = model.identify
            traning.navigationLink  = model.navigationLink
            traning.order           = model.order
            traning.title           = model.title
            traning.version         = model.version
        }else
        {
            self.createTraningWith(model)
        }
        
        return self.save()
    }
    
    static func deleteTraning(identifier : NSNumber) -> Bool
    {
        if let traning = self.retriveTraningWith(identifier)
        {
            self.mainMOC.deleteObject(traning)
        }
        
        return self.save()
    }
    
    static func retriveTranings() -> [Traning]?
    {
        let fetchRequest = NSFetchRequest()
        fetchRequest.entity = NSEntityDescription.entityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC)
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "order", ascending: true)]
        let tranings : [Traning]?
        do{
            tranings = try self.mainMOC.executeFetchRequest(fetchRequest) as? [Traning]
        }catch{
            tranings = nil
        }
        
        return tranings
    }
    
    static func retriveTraningWith(identifier : NSNumber) -> Traning?
    {
        let fetchRequest = NSFetchRequest()
        fetchRequest.entity = NSEntityDescription.entityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC)
        fetchRequest.predicate = NSPredicate(format: "identify = %@", identifier)
        
        let traning : Traning?
        do{
            let tranings = try self.mainMOC.executeFetchRequest(fetchRequest)
            traning = tranings.first as? Traning
        }catch{
            traning = nil
        }
        
        return traning
    }
    
    private static func getEntityName() -> String
    {
        return "Traning"
    }
    
    static func clearTranings()
    {
        if let tranings = self.retriveTranings()
        {
            for (_ , traning) in tranings.enumerate()
            {
                self.mainMOC.deleteObject(traning)
            }
        }
        
        self.save()
    }
}
