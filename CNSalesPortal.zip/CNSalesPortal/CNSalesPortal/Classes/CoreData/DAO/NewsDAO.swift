//
//  NewsDAO.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/7/7.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit
import CoreData

class NewsDAO : BaseDAO
{
    //MARK: - COREDATA FUNCTIONS
    static func create(model : NewsModel) -> Bool
    {
        let news = NSEntityDescription.insertNewObjectForEntityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC) as! News
        news.attachment             = model.attachment
        news.body                   = model.body
        news.category               = model.category
        news.createTime             = model.createTime
        news.file                   = model.file
        news.identifier             = model.identifier
        news.image                  = model.image
        news.title                  = model.title
        news.isBodyDownloadComplete = model.isBodyDownloadComplete
        news.isRead                 = model.isRead
        news.version                = model.version
        
        return self.save()
    }
    
//    
//    static func retriveAppWith(title : String) -> App?
//    {
//        let fetchRequest = NSFetchRequest()
//        fetchRequest.entity = NSEntityDescription.entityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC)
//        fetchRequest.predicate = NSPredicate(format: "title = %@", title)
//        
//        let app : App?
//        do{
//            let apps = try self.mainMOC.executeFetchRequest(fetchRequest)
//            app = apps.first as? App
//        }catch{
//            app = nil
//        }
//        
//        return app
//    }
//    
//    static func retriveCategoryedAppWith(category : NSNumber) -> [App]?
//    {
//        let fetchRequest = NSFetchRequest()
//        fetchRequest.entity = NSEntityDescription.entityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC)
//        fetchRequest.predicate = NSPredicate(format: "category = %@", category)
//        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "order", ascending: true)]
//        
//        do{
//            let apps = try self.mainMOC.executeFetchRequest(fetchRequest)
//            return apps as? [App]
//        }catch{
//            return nil
//        }
//    }
//    
//
//    static func retriveAppWith(category : Int) -> [App]?
//    {
//        let fetchRequest = NSFetchRequest()
//        fetchRequest.entity = NSEntityDescription.entityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC)
//        fetchRequest.predicate = NSPredicate(format: "category = \(category)")
//        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "order", ascending: true)]
//        
//        let apps : [App]?
//        do{
//            apps = try self.mainMOC.executeFetchRequest(fetchRequest) as? [App]
//        }catch{
//            apps = nil
//        }
//        
//        return apps
//    }
    
    private static func getEntityName() -> String
    {
        return "News"
    }
}

//MARK:- Retrive
extension NewsDAO
{
    static func retriveAllNews() -> [News]?
    {
        let fetchRequest = NSFetchRequest()
        fetchRequest.entity = NSEntityDescription.entityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC)
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "createTime", ascending: false)]
        let newsAll : [News]?
        do{
            newsAll = try self.mainMOC.executeFetchRequest(fetchRequest) as? [News]
        }catch{
            newsAll = nil
        }
        
        return newsAll
    }
    
    static func retriveWith(identifier : NSNumber) -> News?
    {
        let fetchRequest = NSFetchRequest()
        fetchRequest.entity = NSEntityDescription.entityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC)
        fetchRequest.predicate = NSPredicate(format: "identifier = %@", identifier)
        
        let news : News?
        do{
            let newsAll = try self.mainMOC.executeFetchRequest(fetchRequest)
            news = newsAll.first as? News
        }catch{
            news = nil
        }
        
        return news
    }
    
    static func retriveNewsVersions() -> String
    {
        if let localNews = self.retriveAllNews()
        {
            return localNews.reduce("", combine: { (versionInfo, news) -> String in
                return versionInfo + "\(news.identifier!):\(news.version!),"
            })
        }else
        {
            return ""
        }
    }

}

//MARK:- Update
extension NewsDAO
{
    static func update(model : NewsModel) -> Bool
    {
        if let news = self.retriveWith(model.identifier!)
        {
            news.attachment             = model.attachment
            news.body                   = model.body
            news.category               = model.category
            news.createTime             = model.createTime
            news.file                   = model.file
            news.identifier             = model.identifier
            news.image                  = model.image
            news.title                  = model.title
            news.isBodyDownloadComplete = false
            news.isRead                 = false
            news.version                = model.version
        }else
        {
            self.create(model)
        }
        
        return self.save()
    }
    
    static func update(models : [NewsModel])
    {
        for (_ , model) in models.enumerate()
        {
            self.update(model)
        }
    }
}

//MARK:- Delete
extension NewsDAO
{
    static func delete(identifier : NSNumber) -> Bool
    {
        if let news = self.retriveWith(identifier)
        {
            self.mainMOC.deleteObject(news)
        }
        
        return self.save()
    }
}

//MARK:- Login Fcuntions
extension NewsDAO
{
    static func updateMultipleNewsWith(models : [NewsModel])
    {
        let remainingLocalNews = NewsDAO.removeServerDeletedNews(Models: models)
        
        for (_ , model) in models.enumerate()
        {
            let newsAll = remainingLocalNews?.filter({ (news) -> Bool in
                return news.identifier! == model.identifier!
            })
            
            if let news = newsAll?.first
            {
                if (model.version?.floatValue > news.version?.floatValue)
                {
                    self.update(model)
                }
            }else
            {
                self.create(model)
            }
        }
    }
    
    //Retrive local apps which is not exist in models and delete it from coredata
    private static func removeServerDeletedNews(Models models : [NewsModel]) -> [News]?
    {
        let ids = models.map { $0.identifier }
        
        let localNews = NewsDAO.retriveAllNews()
        let deletedNews = localNews?.filter({ (news) -> Bool in
            return !ids.contains({ (id) -> Bool in
                return id == news.identifier
            })
        })
        
        for (_ , news) in (deletedNews?.enumerate())!
        {
            NewsDAO.delete(news.identifier!)
        }
        
        return localNews?.filter({ (news) -> Bool in
            return !(deletedNews?.contains(news))!
        })
    }
    
    static func clearNews()
    {
        if let newsAll = self.retriveAllNews()
        {
            for (_ , news) in newsAll.enumerate()
            {
                self.mainMOC.deleteObject(news)
            }
        }
        
        self.save()
    }
}

