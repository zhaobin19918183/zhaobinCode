//
//  EnvironmentDAO.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/7/6.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit
import CoreData

struct SettingModel
{
    var environment : String?
    var urlLOCAL    : String?
    var urlDEV      : String?
    var urlQA       : String?
    var urlPRD      : String?
    var localUser   : String?
    
    static func convertFromPlist(path : String) -> SettingModel
    {
        let settingsInfo   = NSDictionary(contentsOfFile: path)!

        let environment    = settingsInfo["Environment"] as! String
        let localUser      = settingsInfo["LocalUser"]   as? String
        
        let urlEnvironment = settingsInfo["URL"]         as! [String : String]
        let urlLOCAL       = urlEnvironment["LOCAL"]
        let urlDEV         = urlEnvironment["DEV"]       
        let urlQA          = urlEnvironment["QA"]        
        let urlPRD         = urlEnvironment["PRD"]
        
        return SettingModel(environment: environment, urlLOCAL: urlLOCAL, urlDEV: urlDEV, urlQA: urlQA, urlPRD: urlPRD, localUser: localUser)
    }
    
    static func convertFromEntity(entity : Settings?) -> SettingModel
    {
        if let settings = entity
        {
            return SettingModel(environment: settings.environment, urlLOCAL: settings.urlLOCAL, urlDEV: settings.urlDEV, urlQA: settings.urlQA, urlPRD: settings.urlPRD, localUser: settings.localUser)
        }else
        {
            return SettingModel()
        }
    }
    
    func isLocalEnvironment() -> Bool
    {
        return self.environment! == "LOCAL"
    }
    
    func rootURL() -> String
    {
        switch self.environment! {
        case "LOCAL":
            return self.urlLOCAL!
        case "DEV":
            return self.urlDEV!
        case "QA":
            return self.urlQA!
        case "PRD":
            return self.urlPRD!
        default:
            return ""
        }
    }
    
    func getEnvironment(url : String) -> String
    {
        switch url {
        case self.urlLOCAL!:
            return "LOCAL"
        case self.urlDEV!:
            return "DEV"
        case self.urlQA!:
            return "QA"
        case self.urlPRD!:
            return "PRD"
        default:
            return ""
        }
    }
}

class SettingsDAO : BaseDAO
{
    static func create(newSettings : SettingModel) -> Bool
    {
        let settings = NSEntityDescription.insertNewObjectForEntityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC) as! Settings
        settings.environment = newSettings.environment
        settings.urlLOCAL    = newSettings.urlLOCAL
        settings.urlDEV      = newSettings.urlDEV
        settings.urlQA       = newSettings.urlQA
        settings.urlPRD      = newSettings.urlPRD
        settings.localUser   = newSettings.localUser
        
        return self.save()
    }
    
    static func update(newSettings : SettingModel) -> Bool
    {
        let settings = self.retrive()!
        settings.environment = newSettings.environment
        settings.urlLOCAL    = newSettings.urlLOCAL
        settings.urlDEV      = newSettings.urlDEV
        settings.urlQA       = newSettings.urlQA
        settings.urlPRD      = newSettings.urlPRD
        settings.localUser   = newSettings.localUser
        
        return self.save()
    }
    
    static func retrive() -> Settings?
    {
        let fetchRequest = NSFetchRequest()
        fetchRequest.entity = NSEntityDescription.entityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC)
        let settings : Settings?
        do{
            let entities = try self.mainMOC.executeFetchRequest(fetchRequest) as? [Settings]
            settings = entities?.first
        }catch{
            settings = nil
        }
        
        return settings
    }
    
    private static func getEntityName() -> String
    {
        return "Settings"
    }
}
