//
//  CategoryDAO.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/5/18.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit
import CoreData

//MARK:- PRIVATE FUNCTIONS
class CategoryDAO: BaseDAO
{
    //MARK: - COREDATA FUNCTIONS
    private static func createCategoryWith(category : CategoryModel) -> Bool
    {
        let categoryEntity = NSEntityDescription.insertNewObjectForEntityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC) as! AppCategory
        categoryEntity.index = category.index
        categoryEntity.name = category.name
        
        return self.save()
    }
    
    private static func deleteCategory() -> Bool
    {
        for (_ , category) in (self.retriveCategories()?.enumerate())!
        {
            self.mainMOC.deleteObject(category)
        }
        
        return self.save()
    }
    
    private static func retriveCategories() -> [AppCategory]?
    {
        let fetchRequest = NSFetchRequest()
        fetchRequest.entity = NSEntityDescription.entityForName(self.getEntityName(), inManagedObjectContext: self.mainMOC)
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "index", ascending: true)]
        let categories : [AppCategory]?
        do{
            categories = try self.mainMOC.executeFetchRequest(fetchRequest) as? [AppCategory]
        }catch{
            categories = nil
        }
        
        return categories
    }
    
    private static func getEntityName() -> String
    {
        return "AppCategory"
    }
}

//MARK:- USER INTERFACE
extension CategoryDAO
{
    static func updateMultipleCategoryWith(models : [CategoryModel])
    {
        CategoryDAO.deleteCategory()
        
        for (_, category) in models.enumerate()
        {
            CategoryDAO.createCategoryWith(category)
        }
    }
    
    static func retriveAllCategories() -> [AppCategory]?
    {
        return self.retriveCategories()
    }
    
    static func clearCategory()
    {
        if let categories = self.retriveAllCategories()
        {
            for (_ , category) in categories.enumerate()
            {
                self.mainMOC.deleteObject(category)
            }
        }
        
        self.save()
    }
}
