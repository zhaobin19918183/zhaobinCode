//
//  UserSwitchView.swift
//  CN SalesPortal
//
//  Created by Kilin on 16/7/6.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class UserSwitchView: UIView
{
    @IBOutlet weak var currentUserLabel: UILabel!
    @IBOutlet weak var textField: UITextField!
    
    @IBAction func saveClicked(sender: AnyObject)
    {
        EnvironmentManager.updateLocalUser(self.textField.text!) {
            AppDAO.clearApp()
            CategoryDAO.clearCategory()
            TraningDAO.clearTranings()
            EnvironmentManager.clearFolderWith(PATH_FOLDER_APP)
            //TODO:清除新闻
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, Int64(0.5 * Double(NSEC_PER_SEC))), dispatch_get_main_queue(), {
                exit(0)
            })
        }
    }
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        
        if let currentUser = EnvironmentManager.getCurrentUser()
        {
            self.currentUserLabel.text = "当前用户 : \(currentUser)"
        }
    }
}
