//
//  DocumentCollectionViewCell.swift
//  DevelopmentTool
//
//  Created by Kilin on 16/7/4.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class DocumentCollectionViewCell: UICollectionViewCell
{
    @IBOutlet weak var categoryLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
}
