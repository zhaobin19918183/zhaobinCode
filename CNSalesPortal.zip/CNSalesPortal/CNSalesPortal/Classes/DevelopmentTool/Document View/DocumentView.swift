//
//  DocumentView.swift
//  DevelopmentTool
//
//  Created by Kilin on 16/7/4.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class DocumentView: UIView
{
    @IBOutlet weak var collectionView: UICollectionView!
    
    var rootPath : String = {
        var rootPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true).first! as String
        rootPath = rootPath.stringByReplacingOccurrencesOfString("Documents", withString: "")
        return rootPath
    }()
    
    var collectionData : [String]!
    var currentPath : String!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        
        self.loadCollectionData(atPath: self.rootPath)
        self.collectionView.registerNib(UINib(nibName: "DocumentCollectionViewCell", bundle: NSBundle.mainBundle()), forCellWithReuseIdentifier: "reusableID")
        currentPath = self.rootPath
    }
    
    private func loadCollectionData(atPath path : String)
    {
        let fileManager = NSFileManager.defaultManager()
        do {
            self.collectionData = try fileManager.contentsOfDirectoryAtPath(path)
        }catch{
            self.collectionData = [String]()
        }
    }
    
    private func checkFileOrFolder(name : String) -> (isDirectory : Bool , category : String)
    {
        let fileManager = NSFileManager.defaultManager()
        let directory = currentPath.stringByAppendingString("/\(name)")
        do {
            let subPaths = try fileManager.contentsOfDirectoryAtPath(directory)
            return subPaths.count > 0 ? (true, "FOLDER") : (false, "FILE")
        }catch{
            return (false, "FILE")
        }
    }
}

//MARK:- Button Actions
extension DocumentView
{
    @IBAction func rootClicked(sender: AnyObject)
    {
        currentPath = self.rootPath
        self.loadCollectionData(atPath: currentPath)
        self.collectionView.reloadData()
    }
}

//MARK:- UICollectionViewDelegate & UICollectionViewDataSource
extension DocumentView : UICollectionViewDelegate , UICollectionViewDataSource
{
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return self.collectionData.count
    }
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int
    {
        return 1
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell
    {
        let reusableID = "reusableID"
        let cell : DocumentCollectionViewCell!
        if let reusableCell = collectionView.dequeueReusableCellWithReuseIdentifier(reusableID, forIndexPath: indexPath) as? DocumentCollectionViewCell
        {
            cell = reusableCell
        }else
        {
            cell = DocumentCollectionViewCell()
        }
        
        cell.nameLabel.text = self.collectionData[indexPath.row]
        cell.categoryLabel.text = self.checkFileOrFolder(self.collectionData[indexPath.row]).category
        
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath)
    {
        if self.checkFileOrFolder(self.collectionData[indexPath.row]).isDirectory == true
        {
            currentPath = currentPath.stringByAppendingString("/\(self.collectionData[indexPath.row])")
            self.loadCollectionData(atPath: currentPath)
            self.collectionView.reloadData()
        }
    }
}




