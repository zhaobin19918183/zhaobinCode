//
//  DevelopmentViewController.swift
//  DevelopmentTool
//
//  Created by Kilin on 16/7/4.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class DevelopmentViewController: UIViewController
{
    @IBOutlet weak var contentLabel: UILabel!
    @IBOutlet weak var contentView: UIView!
    
    @IBOutlet weak var componentTableView: UITableView!
    
    let componentData : [String] = {
        return ["DOCUMENT" ,
                "VIEW LOG" ,
                "URL SWITCH" ,
                "USER SWITCH"]
    }()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    @IBAction func exitClicked(sender: AnyObject)
    {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
}

extension DevelopmentViewController : UITableViewDelegate , UITableViewDataSource
{
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        for (_ , view) in self.contentView.subviews.enumerate()
        {
            view.removeFromSuperview()
        }
        
        self.contentLabel.text = self.componentData[indexPath.row]
        
        let contentViewFrame = self.contentView.frame
        switch indexPath.row {
        case 0:
            let nibs = NSBundle.mainBundle().loadNibNamed("DocumentView", owner: nil, options: nil)
            let documentView = nibs.first as! DocumentView
            documentView.frame = CGRectMake(0,0,CGRectGetWidth(contentViewFrame),CGRectGetHeight(contentViewFrame))
            self.contentView.addSubview(documentView)
        case 1:
            let nibs = NSBundle.mainBundle().loadNibNamed("LoggerView", owner: nil, options: nil)
            let loggerView = nibs.first as! LoggerView
            loggerView.frame = CGRectMake(0,0,CGRectGetWidth(contentViewFrame),CGRectGetHeight(contentViewFrame))
            self.contentView.addSubview(loggerView)
        case 2:
            let nibs = NSBundle.mainBundle().loadNibNamed("URLSwitchView", owner: nil, options: nil)
            let urlSwitchView = nibs.first as! URLSwitchView
            urlSwitchView.frame = CGRectMake(0,0,CGRectGetWidth(contentViewFrame),CGRectGetHeight(contentViewFrame))
            self.contentView.addSubview(urlSwitchView)
        case 3:
            let nibs = NSBundle.mainBundle().loadNibNamed("UserSwitchView", owner: nil, options: nil)
            let userSwitchView = nibs.first as! UserSwitchView
            userSwitchView.frame = CGRectMake(0,0,CGRectGetWidth(contentViewFrame),CGRectGetHeight(contentViewFrame))
            self.contentView.addSubview(userSwitchView)
        default:
            print("The sequence is wrong.")
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let reusableID = "ReusableID"
        var cell : UITableViewCell?
        if let reusableCell = tableView.dequeueReusableCellWithIdentifier(reusableID)
        {
            cell = reusableCell
        }else
        {
            cell = UITableViewCell(style: .Default, reuseIdentifier: reusableID)
        }
        
        cell?.textLabel?.text = self.componentData[indexPath.row]
        
        return cell!
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.componentData.count
    }
}