//
//  DelelopmentToolProtocol.swift
//  DevelopmentTool
//
//  Created by Kilin on 16/7/4.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

protocol Developable
{
    var developmentViewController : DevelopmentViewController { get }
    
    func displayDevelopmentScene()
}

extension Developable where Self : UIViewController
{
    var developmentViewController : DevelopmentViewController
    {
        let nibs = NSBundle.mainBundle().loadNibNamed("DevelopmentViewController", owner: nil, options: nil)
        let developmentViewController = nibs.first as! DevelopmentViewController
        return developmentViewController
    }
    
    func displayDevelopmentScene()
    {
        self.presentViewController(self.developmentViewController, animated: true, completion: nil)
    }
}