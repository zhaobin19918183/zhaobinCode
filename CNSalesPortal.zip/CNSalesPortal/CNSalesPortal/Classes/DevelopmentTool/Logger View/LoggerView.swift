//
//  LoggerView.swift
//  DevelopmentTool
//
//  Created by Kilin on 16/7/4.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class LoggerView: UIView
{
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var textView: UITextView!
    
    var tableviewData : [String] = {
        let fileManager = NSFileManager.defaultManager()
        do{
            let data = try fileManager.contentsOfDirectoryAtPath(PATH_FOLDER_LOGGER)
            return data
        }catch
        {
            return [String]()
        }
    }()
}

extension LoggerView : UITableViewDelegate , UITableViewDataSource
{
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        let path = PATH_FOLDER_LOGGER + "/\(self.tableviewData[indexPath.row])"
        let record = try! String(contentsOfFile: path)
        self.textView.text = record
        self.textView.backgroundColor = UIColor(red: 208/255.0, green: 208/255.0, blue: 208/255.0, alpha: 1).colorWithAlphaComponent(0.9)
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let reusableID = "ReusableID"
        var cell : UITableViewCell?
        if let reusableCell = tableView.dequeueReusableCellWithIdentifier(reusableID)
        {
            cell = reusableCell
        }else
        {
            cell = UITableViewCell(style: .Default, reuseIdentifier: reusableID)
        }
        
        cell?.textLabel?.text = self.tableviewData[indexPath.row]
        cell?.textLabel?.font = UIFont.systemFontOfSize(15)
        
        return cell!
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.tableviewData.count
    }
}