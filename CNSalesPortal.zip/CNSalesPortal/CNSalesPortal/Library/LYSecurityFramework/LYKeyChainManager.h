//
//  LYKeyChainManager.h
//  LYSecurityLibrary
//
//  Created by PwC on 5/28/12.
//  Copyright (c) 2012 Eli Lilly and Company. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <Security/Security.h>
#import "LYHttpConnection.h"

typedef void (^LYKeyChainStatusBlock)(BOOL isOnline, NSError *errConnection, NSError *errInstall);

@interface LYKeyChainManager : NSObject

//
//Func:
//+ (void)checkLillyUserIdentityStatusOnline:(LYKeyChainStatusBlock)statusBlock
//                               validLinker:(NSString*)checkLinker
//                       autoInstallKeychain:(BOOL)isInstallKeychain
//
//Requests to "checkLinker" to verify username and password
//if connection is ok and user credential is valid, statusBlock would be invoked.
//Otherwise, if "autoInstall" is No then invoke "statusBlock" with optional status error info as below
// 1. kLYConnectionFailureErrorType -- Connectivity failed with no network connection
// 2. kLYConnectionTimedOutErrorType -- Connectivity with time out
// 3. kLYConnectionCredentialsAuthErrorType -- Invalid user certificate
// 4. kLYConnectionUserInfoAuthErrorType -- Invalid password
// 5. Etc.
//If "autoInstall" is YES, installs new keychain then exits caller when executing successfully or invoke "statusBlock" error info as below:
// 1. kInstallAppMissing -- Keychain Helper does not exist.
// 2. kInstallEnvInvalid -- the program which using securityLib of environment doesn't support.
// 3. kInstallGeneralException -- Failed with exception while launching the Lilly Keychain Helper.
+ (void)checkLillyUserIdentityStatusOnline:(LYKeyChainStatusBlock)statusBlock
                               validLinker:(NSString*)checkLinker
                       autoInstallKeychain:(BOOL)isInstallKeychain;

//
//Func:
//+ (BOOL)confirmUserIsMemberOfGroup
//
//
//Requests to "checkLinker" to verify whether the user is member of the given group.
//"checkLinker" for example: https://soa-d.xh1.lilly.com:8443/groupCheck?group=XXX&domain=XXX
//Returns TRUE if connection is ok and user credential is valid,
//otherwise it means you don't have access to the content.
//If "groupName" is nil, it will use the value from key "LYADGroupAuthName" in LYSecurityConfig.plist instead as default.
+ (BOOL)confirmUserIsMemberOfGroup:(NSString*)groupName
						withDomain:(NSString*)domain
                       validLinker:(NSString*)checkLinker;

//
//Func:
//+ (SecIdentityRef)getLillyUserIdentityCopyFromKeychain;
//
//Load Lilly User secIdentity from Lilly keychain.
//Return Lilly account user ID if it exists, otherwise, return NULL.
//
//Warning!!!
//You should release the return value if it isn't equal to NULL;
//else memory leak would occur.
+ (SecIdentityRef)getLillyUserIdentityCopyFromKeychain;

//
//Func:
//+ (NSString*)getLillyAccountUserIdFromKeychain;
//
//Get UserID from Keychain, if success, Lilly User existed and return AccountUserID,
//Return Lilly account UserID if it exists, otherwise, return nil.
+ (NSString*)getLillyAccountUserIdFromKeychain;

//
//Func:
//+ (NSString*)getLillyAccountPasswordFromKeychain;
//
//Get password from Keychain, if success, Lilly User existed and return Accountpassword,
//Return Lilly account password if it exists, otherwise, return nil.
+ (NSString*)getLillyAccountPasswordFromKeychain;

//
//Func:
//+ (NSString*)getLillyAccountDomainFromKeychain:
//
//Get domain information from Keychain, if success, Lilly User existed and return domain for account,
//Return Lilly account domain if it exists, otherwise, return nil.
//"userId" should be better not to equal to "nil". Otherwise the other userId's domain may be returned.
+ (NSString*)getLillyAccountDomainFromKeychain:(NSString*)userId;

//
//Func:
//+ (OSStatus)addLillyUserIdentityFileToKeychain: password
//
//Add Lilly user identity in a .p12 file to lilly Keychain, if success, return errSecSuccess
//else return the error code in keychain domain
//keychain error domain:
//errSecSuccess                 0       No error.
//errSecUnimplemented           -4      Function or operation not implemented.
//errSecParam                   -50     One or more parameters passed to the function were not valid.
//errSecAllocate                -108    Failed to allocate memory.
//errSecNotAvailable            –25291	No trust results are available.
//errSecAuthFailed              –25293	Authorization/Authentication failed.
//errSecDuplicateItem           –25299	The item already exists.
//errSecItemNotFound            –25300	The item cannot be found.
//errSecInteractionNotAllowed	–25308	Interaction with the Security Server is not allowed.
//errSecDecode                  -26275	Unable to decode the provided data.
+ (OSStatus)addLillyUserIdentityFileToKeychain:(NSString*)p12FilePath 
                                      password:(NSString *)password;

//
//Func:
//+ (OSStatus)addLillyUserIdentityToKeychain;
//
//Add Lilly user secIdentity to lilly Keychain, if success, return errSecSuccess
//else return the error code in keychain domain
//keychain error domain:
//errSecSuccess                 0       No error.
//errSecUnimplemented           -4      Function or operation not implemented.
//errSecParam                   -50     One or more parameters passed to the function were not valid.
//errSecAllocate                -108    Failed to allocate memory.
//errSecNotAvailable            –25291	No trust results are available.
//errSecAuthFailed              –25293	Authorization/Authentication failed.
//errSecDuplicateItem           –25299	The item already exists.
//errSecItemNotFound            –25300	The item cannot be found.
//errSecInteractionNotAllowed	–25308	Interaction with the Security Server is not allowed.
//errSecDecode                  -26275	Unable to decode the provided data.
+ (OSStatus)addLillyUserIdentityToKeychain:(SecIdentityRef)userIdentity;

//
//Func:
//+ (OSStatus)addLillyAccountToKeychain: password: 
//
//Add Lilly account, password to Keychain, if success, return errSecSuccess
//else return the error code in keychain domain.
//If any parameter is equal to nil, the param will be considered as @"".
//keychain error domain:
//errSecSuccess                 0       No error.
//errSecUnimplemented           -4      Function or operation not implemented.
//errSecParam                   -50     One or more parameters passed to the function were not valid.
//errSecAllocate                -108    Failed to allocate memory.
//errSecNotAvailable            –25291	No trust results are available.
//errSecAuthFailed              –25293	Authorization/Authentication failed.
//errSecDuplicateItem           –25299	The item already exists.
//errSecItemNotFound            –25300	The item cannot be found.
//errSecInteractionNotAllowed	–25308	Interaction with the Security Server is not allowed.
//errSecDecode                  -26275	Unable to decode the provided data.
+ (OSStatus)addLillyAccountToKeychain:(NSString *)userId 
                             password:(NSString *)password;

//
//Func:
//+ (OSStatus)addLillyDomainToKeychain: domain
//
//Add Lilly domain to Keychain, if success, return errSecSuccess
//else return the error code in keychain domain.
//If keychain item not existed according to "userId", "errSecItemNotFound" err code will be returned.
//If there is already a domain information in the keychain item, the newer domain string will replace the older one.
//If any parameter is equal to nil, the param will be considered as @"".
//keychain error domain:
//errSecSuccess                 0       No error.
//errSecUnimplemented           -4      Function or operation not implemented.
//errSecParam                   -50     One or more parameters passed to the function were not valid.
//errSecAllocate                -108    Failed to allocate memory.
//errSecNotAvailable            –25291	No trust results are available.
//errSecAuthFailed              –25293	Authorization/Authentication failed.
//errSecDuplicateItem           –25299	The item already exists.
//errSecItemNotFound            –25300	The item cannot be found.
//errSecInteractionNotAllowed	–25308	Interaction with the Security Server is not allowed.
//errSecDecode                  -26275	Unable to decode the provided data.
+ (OSStatus)addLillyDomainToKeychain:(NSString*)userId
                              domain:(NSString*)domain;

//
//Func:
//+ (BOOL)installNewKeychain:(NSError**)errOut;
//
//Launch Keychain helper to install a new keychain,
//if success return YES, else return No with error info as:
// 1. Keychain Helper does not exist.
// 2. the program which using securityLib of environment doesn't support.
// 3. Failed with exception while launching the Lilly Keychain Helper.
typedef enum{
	kInstallNoErr                       = 0,
    kInstallAppMissing,
	kInstallEnvInvalid,	
	kInstallGeneralException,
}LYInstallKeychainErrorEnum;

+ (BOOL)installNewKeychain:(NSError**)errOut;


@end
