//
//  LYHttpConnection.h
//  LYFramework
//
//  Created by PwC on 6/1/12.
//  Copyright (c) 2012 Eli Lilly and Company. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LYKeyChainManager.h"

typedef enum{
	kLYConnectionSuccess                           = 0,
	kLYConnectionFailureErrorType                  = 0x1,
	kLYConnectionTimedOutErrorType,
	kLYConnectionCredentialsAuthErrorType,
    kLYConnectionServerUnauthorizedErrorType,
    kLYConnectionServerDeclineErrorType,
    kLYConnectionNotFoundErrorType,
    kLYConnectionMethodNotAllowedErrorType,
    kLYConnectionRequestTimeOutErrorType,
    kLYConnectionInternalServerErrorType,
    kLYConnectionUserInfoAuthErrorType,
//
//reserved for extension
//
//	kLYConnectionCancelledErrorType,
//	kLYConnectionUnableToCreateErrorType,
//	kLYConnInternalErrorWhileBuildingRequestType,
//	kLYConnInternalErrorWhileApplyingCredentialsType,
//	kLYConnectionFileManagementError,
//	kLYConnectionTooMuchRedirectionErrorType,
//	kLYConnectionUnhandledExceptionError,
//	kLYConnectionCompressionError,
}LYKeyChainConnectionErrEnum;

typedef void (^LYHTTPCompletionBlock)(id connection);
@protocol LYHttpConnectionDelegate;
@interface LYHttpConnection : NSObject {
    LYHTTPCompletionBlock           completionBlock;
    id<LYHttpConnectionDelegate>    _delegate;

    LYKeyChainConnectionErrEnum     _errorType;
    NSString                        *_errorDescription;
    NSMutableData                   *_dataReceived;
    NSURLConnection                 *_currentConnection;
    double                          _dTimeoutInterval;
    NSTimer                         *_timerForTimeout;
    NSString                        *_strUserName;
    NSString                        *_strPassword;
    SecIdentityRef                  _externalIdentity;
}

@property (nonatomic, assign) id<LYHttpConnectionDelegate> delegate;
@property (nonatomic, assign) double                       timeoutInterval;
//[[11/30/2012 PwC
//Add enhancement to support external identity for http connection instead of default Lilly user credential in Keychain
@property (nonatomic, assign) SecIdentityRef               externalIdentity;
//11/30/2012 PwC]]

//
//Func:
//- (void)setCompletionBlock:(LYHTTPCompletionBlock)aCompletionBlock;
//
//Set the completion block, the block would be invoked when the connection ends.
- (void)setCompletionBlock:(LYHTTPCompletionBlock)aCompletionBlock;

//
//Func:
//- (void)sendSOAPRequestWithURL:(NSString*)urlString
//                   messageBody:(NSString*)message
//                        action:(NSString*)action;
//
//Generates a SOAP URL request and starts the connection by "POST" method.
- (void)sendSOAPRequestWithURL:(NSString*)urlString
                   messageBody:(NSString*)message
                        action:(NSString*)action;

//
//Func:
//- (void)sendRestfulRequestWithURL:(NSString*)urlString;
//
//Generates a RESTFUL URL request and starts the connection by "GET" method.
- (void)sendRestfulRequestWithURL:(NSString*)urlString;

//
//Func:
//- (void)sendRequest:(NSURLRequest*)aURLRequest;
//
//Starts the connection by a customize URL request.
- (void)sendRequest:(NSURLRequest*)aURLRequest;

//
//Func:
//- (void)endConnection;
//
//End the connection and call the completion block function.
- (void)endConnection;

//
//Func:
//- (NSString*)responseString;
//
//Returns the available response contents from current requesting connection.
//If there aren't any contents available, return nil;
- (NSString*)responseString;

//
//Func:
//- (NSError*)connectionError;
//
//Returns the error occurred which contains details of why the connection failed to load the request
//successfully. If the connection ends successfully with no error info, return nil;
//The error info as below:
// 1. kLYConnectionFailureErrorType -- Connectivity failed with no network connection
// 2. kLYConnectionTimedOutErrorType -- Connectivity with time out
// 3. kLYConnectionCredentialsAuthErrorType -- Invalid user certificate
// 4. kLYConnectionInternalErrorType --web service internal error
// 5. kLYConnectionUserInfoAuthErrorType -- Invalid password
// 6. Etc.
- (NSError*)connectionError;

@end


@protocol LYHttpConnectionDelegate
@optional
//- (void)LYConnectionFinished:(LYHttpConnection*)connection;
//- (void)LYConnectionFailed:(LYHttpConnection*)connection;
- (void)LYConnection:(LYHttpConnection*)connection
handleAuthenticationChanllenge:(NSURLAuthenticationChallenge*)challenge;

@end