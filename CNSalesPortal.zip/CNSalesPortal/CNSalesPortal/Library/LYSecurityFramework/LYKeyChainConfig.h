//
//  LYKeyChainConfig.h
//  LYSecurityLibrary
//
//  Created by PwC on 5/28/12.
// Copyright (c) 2012 Eli Lilly and Company. All rights reserved.
//

#ifndef LYFramework_LYKeyChainConfig_h
#define LYFramework_LYKeyChainConfig_h

#define LYKeyChainHelperApplicationScheme @"keychainhelper"

#endif