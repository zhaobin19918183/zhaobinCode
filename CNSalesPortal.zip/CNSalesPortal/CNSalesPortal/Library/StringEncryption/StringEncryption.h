//
//  StringEncryption.h
//  CN SalesPortal
//
//  Copyright ( C ) 2015 Eli Lilly and Company. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCryptor.h>


#define kChosenCipherBlockSize	kCCBlockSizeAES128
#define kChosenCipherKeySize	kCCKeySizeAES128

@interface StringEncryption : NSObject

+ (NSString *) EncryptString:(NSString *)plainSourceStringToEncrypt;
+ (NSString *) DecryptString:(NSString *) base64StringToDecrypt;
+ (NSString *)encryptUserInfor:(NSString *)username password:(NSString *)password;

- (NSData *)encrypt:(NSData *)plainText key:(NSData *)aSymmetricKey padding:(CCOptions *)pkcs7;
- (NSData *)decrypt:(NSData *)plainText key:(NSData *)aSymmetricKey padding:(CCOptions *)pkcs7;

- (NSData *)doCipher:(NSData *)plainText key:(NSData *)aSymmetricKey
			 context:(CCOperation)encryptOrDecrypt padding:(CCOptions *)pkcs7;
@end
