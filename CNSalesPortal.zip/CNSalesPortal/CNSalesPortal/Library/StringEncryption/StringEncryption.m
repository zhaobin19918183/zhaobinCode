#import "StringEncryption.h"
#import "NSData+Base64.h"

#if DEBUG
#define LOGGING_FACILITY(X, Y)	\
NSAssert(X, Y);	

#define LOGGING_FACILITY1(X, Y, Z)	\
NSAssert1(X, Y, Z);	
#else
#define LOGGING_FACILITY(X, Y)	\
if(!(X)) {			\
NSLog(Y);		\
exit(-1);		\
}					

#define LOGGING_FACILITY1(X, Y, Z)	\
if(!(X)) {				\
NSLog(Y, Z);		\
exit(-1);			\
}						
#endif

@implementation StringEncryption

NSString *_key = @"233A765B-C942-485A-824D-697FE759BAA7";

CCOptions padding = kCCOptionPKCS7Padding;

+ (NSString *)encryptUserInfor:(NSString *)username password:(NSString *)password
{
    NSMutableDictionary *loginData = [NSMutableDictionary dictionary];
    [loginData setValue:username forKey:@"username"];
    [loginData setValue:password forKey:@"password"];
    
    NSString *encryptLoginString = [self convertJsonDataToString:loginData];
    encryptLoginString = [StringEncryption EncryptString:encryptLoginString];
    encryptLoginString = [encryptLoginString stringByReplacingOccurrencesOfString:@"+" withString:@"%2B"];
    encryptLoginString = [encryptLoginString stringByReplacingOccurrencesOfString:@"/" withString:@"%2F"];
    encryptLoginString = [encryptLoginString stringByReplacingOccurrencesOfString:@"=" withString:@"%3D"];
    
    return encryptLoginString;
}

+ (NSString *)convertJsonDataToString:(id)data
{
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:data
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:nil];
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}

+ (NSString *) EncryptString:(NSString *)plainSourceStringToEncrypt
{
    StringEncryption *crypto = [[StringEncryption alloc] init];
	NSData *_secretData = [plainSourceStringToEncrypt dataUsingEncoding:NSASCIIStringEncoding];
	NSData *encryptedData = [crypto encrypt:_secretData key:[_key dataUsingEncoding:NSASCIIStringEncoding] padding:&padding];
    return [encryptedData base64EncodedStringWithSeparateLines:NO];
}

+ (NSString *)DecryptString:(NSString *)base64StringToDecrypt
{
	StringEncryption *crypto = [[StringEncryption alloc] init];
	NSData *data = [crypto decrypt:[base64StringToDecrypt dataUsingEncoding:NSASCIIStringEncoding] key:[_key dataUsingEncoding:NSASCIIStringEncoding] padding: &padding];
	
	return [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
}

- (NSData *)encrypt:(NSData *)plainText key:(NSData *)aSymmetricKey padding:(CCOptions *)pkcs7
{
    return [self doCipher:plainText key:aSymmetricKey context:kCCEncrypt padding:pkcs7];
}

- (NSData *)decrypt:(NSData *)plainText key:(NSData *)aSymmetricKey padding:(CCOptions *)pkcs7
{
    return [self doCipher:plainText key:aSymmetricKey context:kCCDecrypt padding:pkcs7];
}

- (NSData *)doCipher:(NSData *)plainText key:(NSData *)aSymmetricKey
			 context:(CCOperation)encryptOrDecrypt padding:(CCOptions *)pkcs7
{
    CCCryptorStatus ccStatus = kCCSuccess;
    // Symmetric crypto reference.
    CCCryptorRef thisEncipher = NULL;
    // Cipher Text container.
    NSData * cipherOrPlainText = nil;
    // Pointer to output buffer.
    uint8_t * bufferPtr = NULL;
    // Total size of the buffer.
    size_t bufferPtrSize = 0;
    // Remaining bytes to be performed on.
    size_t remainingBytes = 0;
    // Number of bytes moved to buffer.
    size_t movedBytes = 0;
    // Length of plainText buffer.
    size_t plainTextBufferSize = 0;
    // Placeholder for total written.
    size_t totalBytesWritten = 0;
    // A friendly helper pointer.
    uint8_t * ptr;
	
    // Initialization vector; dummy in this case 0's.
    uint8_t iv[kChosenCipherBlockSize];
    memset((void *) iv, 0x0, (size_t) sizeof(iv));
	
    plainTextBufferSize = [plainText length];
	
    // We don't want to toss padding on if we don't need to
    if(encryptOrDecrypt == kCCEncrypt) {
        if(*pkcs7 != kCCOptionECBMode) {
            if((plainTextBufferSize % kChosenCipherBlockSize) == 0) {
                *pkcs7 = kCCOptionPKCS7Padding;
            } else {
                *pkcs7 = kCCOptionPKCS7Padding;
            }
        }
    } else if(encryptOrDecrypt != kCCDecrypt) {
//        NSLog(@"Invalid CCOperation parameter [%d] for cipher context.", *pkcs7 );
    }
	
    // Create and Initialize the crypto reference.
    CCCryptorCreate(encryptOrDecrypt,
                               kCCAlgorithmAES128,
                               *pkcs7,
                               (const void *)[aSymmetricKey bytes],
                               kChosenCipherKeySize,
                               (const void *)iv,
                               &thisEncipher
                               );
	
   //LOGGING_FACILITY1( ccStatus == kCCSuccess, @"Problem creating the context, ccStatus == %d.", ccStatus );
	
    // Calculate byte block alignment for all calls through to and including final.
    bufferPtrSize = CCCryptorGetOutputLength(thisEncipher, plainTextBufferSize, true);
	
    // Allocate buffer.
    bufferPtr = malloc( bufferPtrSize * sizeof(uint8_t) );
	
    // Zero out buffer.
    memset((void *)bufferPtr, 0x0, bufferPtrSize);
	
    // Initialize some necessary book keeping.
	
    ptr = bufferPtr;
	
    // Set up initial size.
    remainingBytes = bufferPtrSize;
	
    // Actually perform the encryption or decryption.
    CCCryptorUpdate(thisEncipher,
                               (const void *) [plainText bytes],
                               plainTextBufferSize,
                               ptr,
                               remainingBytes,
                               &movedBytes
                               );
    // Handle book keeping.
    ptr += movedBytes;
    remainingBytes -= movedBytes;
    totalBytesWritten += movedBytes;
	
    // Finalize everything to the output buffer.
    ccStatus = CCCryptorFinal(thisEncipher,
                              ptr,
                              remainingBytes,
                              &movedBytes
                              );
	
    totalBytesWritten += movedBytes;
	
    if(thisEncipher) {
        (void) CCCryptorRelease(thisEncipher);
        thisEncipher = NULL;
    }

    if (ccStatus == kCCSuccess)
        cipherOrPlainText = [NSData dataWithBytes:(const void *)bufferPtr length:(NSUInteger)totalBytesWritten];
    else
        cipherOrPlainText = nil;
	
    if(bufferPtr) free(bufferPtr);
    
    return cipherOrPlainText;
}

@end