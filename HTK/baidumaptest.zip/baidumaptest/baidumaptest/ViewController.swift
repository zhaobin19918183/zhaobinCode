//
//  ViewController.swift
//  baidumaptest
//
//  Created by Kilin on 16/6/28.
//  Copyright © 2016年 Eli Lilly and Company. All rights reserved.
//

import UIKit

class ViewController: UIViewController , CLLocationManagerDelegate {

    var
    _locationManager : CLLocationManager? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
//        let clManager = CLLocationManager()
//        clManager.requestWhenInUseAuthorization()
//        
//        let locationManager = BMKLocationService()
//        locationManager.delegate = self
//        locationManager.startUserLocationService()
        
        self._locationManager = CLLocationManager()
        self._locationManager!.delegate = self
        self._locationManager!.desiredAccuracy = kCLLocationAccuracyBest
        self._locationManager!.requestWhenInUseAuthorization()
        self._locationManager!.startUpdatingLocation()
        print("123")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        print(locations)
        let location = locations.first!
        self.getAddress(location)
        
        manager.stopUpdatingLocation()
    }
    
    func getAddress(location : CLLocation)
    {
        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(location) { (placemarks, error) in
            var plackmark : CLPlacemark?
            if placemarks?.count > 0
            {
                plackmark = placemarks![0]
            }
            
            if let addresses = plackmark?.addressDictionary?["FormattedAddressLines"]
            {
                print(addresses.firstObject as! String)
            }
        }
    }
}

