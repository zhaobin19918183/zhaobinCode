//
//  CustomButton.m
//  xinle
//
//  Created by newland on 2017/4/10.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "CustomButton.h"

@implementation CustomButton

//初始化 并 赋值frame
-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self createSubviews:frame];
        
    }
    return self;
}

//设置初始样式
-(void)createSubviews:(CGRect)frame{
    self.frame = frame;
    self.backgroundColor = customGray;
    [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}

//点击方法
-(void)clickBtn:(id)target action:(SEL)action{
    [self addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
}

//设置文字
-(void)setText:(NSString *)text{
    [self setTitle:text forState:UIControlStateNormal];
}

-(void)buttonStart{
    self.backgroundColor = RGBA(198, 198, 198, 1);
    self.enabled = YES;
}

-(void)buttonEnd{
    self.backgroundColor = [UIColor darkGrayColor];
    self.enabled = NO;
}
@end
