//
//  CustomButton.h
//  xinle
//
//  Created by newland on 2017/4/10.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomButton : UIButton
/**
 初始化 并 赋值frame
 
 @param frame btn大小
 @return self
 */
-(instancetype)initWithFrame:(CGRect)frame;


/**
 点击方法
 @param target 目标
 @param action 方法选择器
 */
-(void)clickBtn:(id)target action:(SEL)action;


/**
 设置按钮文字

 @param text 字符串
 */
-(void)setText:(NSString *)text;

/**
 可以使用的状态
 */
-(void)buttonStart;

/**
 不可以使用的状态
 */
-(void)buttonEnd;
@end
