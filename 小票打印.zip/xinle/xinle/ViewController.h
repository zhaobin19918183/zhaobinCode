//
//  ViewController.h
//  xinle
//
//  Created by newland on 2017/4/10.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<WKUIDelegate,UITableViewDataSource,UITableViewDelegate,WKNavigationDelegate>


@end

