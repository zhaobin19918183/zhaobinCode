//
//  ViewController.m
//  xinle
//
//  Created by newland on 2017/4/10.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
    //ui
    WKWebView *myWebView;//网页
    WKWebView *showWebView;
    NSString *UUID;//uuid
    UITableView *list;//蓝牙选择列表
    
    //array
    NSMutableArray *allBlueToolArray;//所有的设备
    NSMutableArray *nowArray;//当前设备
    
    //判断
    BOOL isPrint;//是否打印
    BOOL isDayInState;//打印状态
    
    //btn
    CustomButton *dayinBtn;//打印结算
    CustomButton *dayinfanliBtn;//打印返利
    CustomButton *refreshBtn;//刷新
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //背景为黑色
    self.view.backgroundColor = [UIColor blackColor];
    //获取 uuid
    UUID = [self getCleanUUID:myUUID];
//    UUID = @"c96b890bea0515dad58b90ad169bdfe5260dfb67";
    //初始化蓝牙
    nowArray = [[NSMutableArray alloc]init];
    [PrinterSDK defaultPrinterSDK];
    //主页面
    [self mainView];
    isPrint = NO;
    
}

//4个btn + 一个webview
-(void)mainView{
    //连接设备
    CustomButton *loginBtn = [[CustomButton alloc]initWithFrame:
                              CGRectMake(5*customWidth,
                                         20*customHeight,
                                         88*customWidth,
                                         35*customHeight)];
    [loginBtn clickBtn:self action:@selector(selectLogInBtn:)];
    [loginBtn setText:@"连接设备"];
    loginBtn.selected = NO;
    [self.view addSubview:loginBtn];
    
    //打印结算
    dayinBtn = [[CustomButton alloc]initWithFrame:
                              CGRectMake(CGRectGetMaxX(loginBtn.frame)+5*customWidth,
                                         loginBtn.frame.origin.y,
                                         loginBtn.frame.size.width,
                                         loginBtn.frame.size.height)];
    [dayinBtn clickBtn:self action:@selector(selectDayInBtn:)];
    [dayinBtn setText:@"打印结算"];
    [self.view addSubview:dayinBtn];
    
    //打印返利
    dayinfanliBtn = [[CustomButton alloc]initWithFrame:
                                   CGRectMake(CGRectGetMaxX(dayinBtn.frame)+5*customWidth,
                                              dayinBtn.frame.origin.y,
                                              dayinBtn.frame.size.width,
                                              dayinBtn.frame.size.height)];
    [dayinfanliBtn clickBtn:self action:@selector(selectDayInFanliBtn:)];
    [dayinfanliBtn setText:@"打印返利"];
    [self.view addSubview:dayinfanliBtn];
    
    //刷新
    refreshBtn = [[CustomButton alloc]initWithFrame:
                                CGRectMake(CGRectGetMaxX(dayinfanliBtn.frame)+5*customWidth,
                                           dayinfanliBtn.frame.origin.y,
                                           dayinfanliBtn.frame.size.width,
                                           dayinfanliBtn.frame.size.height)];
    [refreshBtn clickBtn:self action:@selector(selectRefreshBtn:)];
    [refreshBtn setText:@"刷新"];
    [self.view addSubview:refreshBtn];
    
    CustomButton *uuidBtn = [[CustomButton alloc]initWithFrame:
                             CGRectMake(0,
                                        CGRectGetMaxY(refreshBtn.frame)+5*customHeight,
                                        self.view.frame.size.width,
                                        refreshBtn.frame.size.height)];
    [uuidBtn clickBtn:self action:@selector(selectuuidBtn:)];
    uuidBtn.selected = YES;
    [uuidBtn setText:@"显示UUID"];
    [self.view addSubview:uuidBtn];
    
    //webview
    WKWebViewConfiguration *config = [WKWebViewConfiguration new];
    //初始化偏好设置属性：preferences
    config.preferences = [WKPreferences new];
    //The minimum font size in points default is 0;
    config.preferences.minimumFontSize = 10;
    //是否支持JavaScript
    config.preferences.javaScriptEnabled = YES;
    //不通过用户交互，是否可以打开窗口
    config.preferences.javaScriptCanOpenWindowsAutomatically = NO;
    
    showWebView = [[WKWebView alloc]initWithFrame:
    CGRectMake(0,
               CGRectGetMaxY(uuidBtn.frame)+5*customHeight,
               [UIScreen mainScreen].bounds.size.width,
               [UIScreen mainScreen].bounds.size.height-CGRectGetMaxY(uuidBtn.frame)-5*customHeight) configuration:config];
    [showWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:apkloginURL,UUID]]]];
    [self.view addSubview:showWebView];
    
    myWebView = [[WKWebView alloc]initWithFrame:CGRectZero configuration:config];
    myWebView.UIDelegate = self;
    myWebView.navigationDelegate = self;
    myWebView.backgroundColor = [UIColor whiteColor];
    
    
    //未连接时不可点击
    [self buttonEnd];
}

//蓝牙选择列表
-(void)chooseBlueTool:(BOOL)state{
    if (state) {
        list = [[UITableView alloc]initWithFrame:myWebView.frame];
        list.dataSource = self;
        list.delegate = self;
        list.backgroundColor = [UIColor whiteColor];
        [self.view addSubview:list];
    }else{
        [list removeFromSuperview];
    }
}

#pragma mark - tableviewDelegate
//设置cell数量
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==0) {
        return allBlueToolArray.count;
    }else{
        return nowArray.count;
    }
}

//设置高度为tableview的高度/cell数量
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return tableView.frame.size.height/10;
}

//设置分组
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

//设置复用
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath{
    static NSString *identify = @"PrinterCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identify];
    if (cell==nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identify];
    }
    //蓝牙设备名
    UILabel *name = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, tableView.frame.size.width,[self tableView:tableView heightForRowAtIndexPath:indexPath]/2)];
    [cell addSubview:name];
    //蓝牙的 uuid
    UILabel *uuid = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(name.frame), name.frame.size.width,name.frame.size.height)];
    uuid.adjustsFontSizeToFitWidth = YES;
    [cell addSubview:uuid];
    
    //区分是已连接还是未连接
    if (indexPath.section==0) {
        if (allBlueToolArray.count>0) {
            Printer *printer = [allBlueToolArray objectAtIndex:indexPath.row];
            name.text = printer.name;
            uuid.text = printer.UUIDString;
        }
    }else{
        if (nowArray.count>0) {
            Printer *printer = [nowArray objectAtIndex:indexPath.row];
            name.text = printer.name;
            uuid.text = printer.UUIDString;
        }
    }

    return cell;
}

//点击 cell
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==0) {
        //选择打印机
        Printer *printer = [allBlueToolArray objectAtIndex:indexPath.row];
        //连接打印机
        [[PrinterSDK defaultPrinterSDK] connectBT:printer];
        //停止搜索
        [self stopSeachBlueTool];
        //连接后可点击
        [self buttonStart];
        //删除连接的蓝牙
        [allBlueToolArray removeObjectAtIndex:indexPath.row];
        //放到已连接的数组中
        [nowArray addObject:printer];
    }
    //删除列表
    [list removeFromSuperview];
}

//头部高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section==0) {
        if (allBlueToolArray.count==0) {
            return 0;
        }else{
            return 20*customHeight;
        }
    }else{
        if (nowArray.count==0) {
            return 0;
        }else{
            return 20*customHeight;
        }
    }
}

//头部
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    @try {
        NSString *reuse = @"reuse";
        UITableViewHeaderFooterView *headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:reuse];
        if (headerView == nil) {
            headerView = [[UITableViewHeaderFooterView alloc] initWithReuseIdentifier:reuse];
            if (section==0) {
                headerView.textLabel.text = @"未连接";
            }else{
                headerView.textLabel.text = @"已连接";
            }
            headerView.contentView.backgroundColor = customGray;
        }
        return headerView;
    }
    @catch (NSException *exception) {
        NSLog(@"==========sectionView出错:%@==========",exception);
    }
}

#pragma mark - bluetool
//开始搜索蓝牙设备
-(void)startSeachBlueTool{
    [[PrinterSDK defaultPrinterSDK] scanPrintersWithCompletion:^(Printer *printer){
        //未连接
        if (nil == allBlueToolArray){
            allBlueToolArray = [[NSMutableArray alloc] init];
            [allBlueToolArray addObject:printer];
        }
        //已连接
        for (Printer *p in allBlueToolArray) {
            if (![printer.UUIDString isEqualToString:p.UUIDString]) {
                [allBlueToolArray addObject:printer];
            }
        }
        [list reloadData];
        
    }];
}

//停止搜索蓝牙设备
-(void)stopSeachBlueTool{
    [[PrinterSDK defaultPrinterSDK] stopScanPrinters];
}

#pragma mark - webViewDelegate
//加载失败
-(void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error{
    NSLog(@"%@",error);
}

//加载完成
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    //先判断是否是打印功能
    //在判断是否是结算
    if(isPrint){
        if (isDayInState) {
            [self printDayinList];
        }else{
            [self printDayinFanliList];
        }
    }
}

#pragma mark - btn
//登陆
-(void)selectLogInBtn:(CustomButton *)btn{
    @try {
        btn.selected = !btn.selected;
        isPrint = NO;
        //列表
        [self chooseBlueTool:btn.selected];
        //开始搜索
        [self startSeachBlueTool];
        //连接时的监听
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handlePrinterConnectedNotification:) name:PrinterConnectedNotification object:nil];
        //连接断开时的监听
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handlePrinterDisconnectedNotification:) name:PrinterDisconnectedNotification object:nil];
    } @catch (NSException *exception) {
        NSLog(@"==========%s出错:%@==========",__func__,exception);
    }
    
}

//打印结算
-(void)selectDayInBtn:(CustomButton *)btn{
    @try {
        //请求
        [self setRequest:dayinURL];
        //打印模式
        isDayInState = YES;
        //打印状态
        isPrint = YES;
    } @catch (NSException *exception) {
        NSLog(@"==========%s出错:%@==========",__func__,exception);
    }
    
}

//打印返利
-(void)selectDayInFanliBtn:(CustomButton *)btn{
    @try {
        //请求
        [self setRequest:dayinfanliURL];
        //打印模式
        isDayInState = NO;
        //打印状态
        isPrint = YES;
    } @catch (NSException *exception) {
        NSLog(@"==========%s出错:%@==========",__func__,exception);
    }
}

//刷新
-(void)selectRefreshBtn:(CustomButton *)btn{
    isPrint = NO;
    [showWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:apkloginURL,UUID]]]];
}

//显示 UUID
-(void)selectuuidBtn:(CustomButton *)btn{
    @try {
        if (btn.selected) {
            [btn setText:[NSString stringWithFormat:@"UUID:%@",myUUID]];
            btn.titleLabel.adjustsFontSizeToFitWidth = YES;
        }else{
            [btn setText:@"显示UUID"];
        }
        btn.selected = !btn.selected;
    } @catch (NSException *exception) {
        NSLog(@"==========%s出错:%@==========",__func__,exception);
    }
}

//发送请求
-(void)setRequest:(NSString *)url{
    [myWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:url,UUID]]]];
}

//不带有 - 的 uuid
-(NSString *)getCleanUUID:(NSString *)uuid{
    NSString *strUrl = [uuid stringByReplacingOccurrencesOfString:@"-" withString:@""];
    return strUrl;
}

//button 可以点击
-(void)buttonStart{
    [dayinBtn buttonStart];
    [dayinfanliBtn buttonStart];
    [refreshBtn buttonStart];
}

//button 不可以点击
-(void)buttonEnd{
    [dayinBtn buttonEnd];
    [dayinfanliBtn buttonEnd];
    [refreshBtn buttonEnd];;
}

#pragma mark - 监听
//连接成功后的监听
- (void)handlePrinterConnectedNotification:(NSNotification*)notification{
    double delayInSeconds = 1.0f;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
//        [[PrinterSDK defaultPrinterSDK] printTestPaper];
    });
}
//连接断开后
-(void)handlePrinterDisconnectedNotification:(NSNotification *)notification{
    double delayInSeconds = 1.0f;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        
    });
}

#pragma mark - print
//打印结算
-(void)printDayinList{
        //网页获取的值
        [myWebView evaluateJavaScript:[NSString stringWithFormat:@"document.body.innerHTML"] completionHandler:^(id _Nullable response, NSError * _Nullable error) {
        //打印分割线的计数值
        int num = 0;
        //请求后的网页内容
        NSString *htmlStr = response;
        //已<br>分割数组
        NSMutableArray <NSString *>*array = [NSMutableArray arrayWithArray:[htmlStr componentsSeparatedByString:@"<br>"]];
        //最后的数组
        NSMutableArray <NSString *>*array1 = [[NSMutableArray alloc]init];
        [array1 addObjectsFromArray:array];
        //循环数组
        for (int i = 0; i<array.count; i++) {
            //如果有&nbsp;&nbsp;&nbsp;
            if([[array objectAtIndex:i] rangeOfString:@"&nbsp;&nbsp;&nbsp;"].location !=NSNotFound){
                //按照&nbsp;&nbsp;&nbsp;再次分割
                NSArray <NSString *>*arr = [[array objectAtIndex:i] componentsSeparatedByString:@"&nbsp;&nbsp;&nbsp;"];
                //在拼接加空格
                NSString *str = [[NSString stringWithFormat:@"%@ ",[arr objectAtIndex:0]] stringByAppendingString:[arr objectAtIndex:1]];
                [array1 removeObjectAtIndex:i];
                [array1 insertObject:str atIndex:i];
            }
        }
        /*
         这里单独写分割线和特殊字段是因为,不让这些字段参与商品的分割线,否则不好计算,insertObject会改变数组
         */
        //第一个分割线
        [array1 insertObject:@"\n\t-------------------" atIndex:3];
        //添加最后一个分割线
        [array1 insertObject:@"\t-------------------" atIndex:array1.count-5];
        [array1 addObject:@"本票据由大连心乐乳业有限公司提供\n"];
        
        //添加其他分割线
        for (int i = 0; i<array1.count; i++) {
            //每两个一分割
            if (4<=i&&i<array1.count-6) {
                num++;
                if (num==4) {
                    [array1 insertObject:@"\n\t-------------------" atIndex:i];
                    num = 0;
                }else if(num==2){
                    [array1 insertObject:@"\n" atIndex:i];
                }
            }
        }
        
        
        //打印
        for (int i = 0; i<=2; i++) {
            if (i==1) {
                //切换字体大小
                [[PrinterSDK defaultPrinterSDK]setFontSizeMultiple:1];
                [NSThread sleepForTimeInterval:0.2];
            }else if(i==2){
                //还原字体大小
                [[PrinterSDK defaultPrinterSDK]setFontSizeMultiple:0];
                [NSThread sleepForTimeInterval:0.2];
            }
            if (i<2) {
                //打印其他内容
                NSString *printStr = [[array1 objectAtIndex:i] stringByReplacingOccurrencesOfString:@"\n" withString:@""];
//                            NSLog(@"%@",printStr);
                [[PrinterSDK defaultPrinterSDK]printText:printStr];
            }
        }
            //截取需要变大字体之后的数组
            NSArray *arr = [array1 subarrayWithRange:NSMakeRange(2, array1.count-2)];
            //将数组变成字符串
            NSString *string = [arr componentsJoinedByString:@","];
            //去掉,
            string = [string stringByReplacingOccurrencesOfString:@"," withString:@""];
            //将\n\t\n\t 变成\n\t
            string = [string stringByReplacingOccurrencesOfString:@"\n\t\n\t" withString:@"\n\t"];
            //再去掉第一个\n
            string = [string substringWithRange:NSMakeRange(1, string.length-2)];
            [[PrinterSDK defaultPrinterSDK]printText:string];
//            NSLog(@"%@",string);
    }];

}

//打印返利
-(void)printDayinFanliList{
    [myWebView evaluateJavaScript:[NSString stringWithFormat:@"document.body.innerHTML"] completionHandler:^(id _Nullable response, NSError * _Nullable error) {
        //请求后的网页内容
        NSString *htmlStr = response;
        //已<br>分割数组
        NSMutableArray <NSString *>*array = [NSMutableArray arrayWithArray:[htmlStr componentsSeparatedByString:@"<br>"]];
//        [array addObject:@"本票据由大连心乐乳业有限公司提供\n"];
        
        //打印
        NSString *string = [array componentsJoinedByString:@","];
        string = [string stringByReplacingOccurrencesOfString:@"," withString:@""];
        [[PrinterSDK defaultPrinterSDK]printText:string];
    }];
}
@end
