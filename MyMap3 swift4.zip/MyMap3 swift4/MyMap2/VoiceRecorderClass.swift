//
//  VoiceRecorderClass.swift
//  My地図アプリ
//
//  Created by developer on 2017/04/07.
//  Copyright © 2017年 njk. All rights reserved.
//

import Foundation
import Speech                               // 音声認識するための機能を盛り込んだフレームワーク
import UIKit
import AudioToolbox                      // 録音、再生、およびストリーム解析、オーディオセッションの管理などのフレームワーク
import SystemConfiguration          // ネットワークにアクセス可能か
import Accelerate                          // 行列やベクトルを処理するためのライブラリ

/**
 ◆録音クラス
 Info.plistに許諾説明を追加する。
 ・Privacy - NSSpeechRecognitionUsageDescription: このアプリは音声認識機能を使用します。
 ・Privacy - Microphone Usage Description: このアプリはマイクを使用します。
 */
final class VoiceRecorderClass : NSObject, SFSpeechRecognizerDelegate, SFSpeechRecognitionTaskDelegate, AVSpeechSynthesizerDelegate {
    fileprivate var audioSession = AVAudioSession.sharedInstance()
    fileprivate let audioEngine : AVAudioEngine = AVAudioEngine()
    
    // 再生用
    fileprivate var audioPlayer: AVAudioPlayer?
    
    // 端末の地域設定（日本 : "ja-JP"）
    private var speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "ja-JP"))!
    // タスクにリクエストを登録すると、その結果に音声認識された文字列が返ってくる
    private  var recognitionTask: SFSpeechRecognitionTask?
    // 認識リクエスト
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    
    /** 録音出力先ファイルパス */
    private var recFilePath : NSURL?
    
    // ラベル
    var guideLabel : UILabel?
    /** 最大録音時間（秒）*/
    public var maxRecTimeInterval : Int = -1     // マイナス値は録音制限なし / 0は録音しない
    /** 現在の録音時間(秒) */
    public var nowRecTime : Int = 0
    
    // Delegate
    var VoiceRecorderDelegate : VoiceRecorderDelegate?
    
    /** 再生が終了したときのイベント */
    var PlayerFinishPlayingEvent : (()->())?
    var IsFinishPlayingEvent : Bool = false
    var Setting : SettingClass!
    /**
     ■録音中かどうか
     */
    public var IsRecording : Bool {
        get { return audioEngine.isRunning }
    }
    
    /** マイク使用が許可されていないかどうか */
    public var IsDenied : Bool {
        get {
            // マイクの許可確認
            let status = AVCaptureDevice.authorizationStatus(for: AVMediaType.audio)
            if status == AVAuthorizationStatus.denied {
                // アクセス許可されていない
                return true
            } else {
                return false
            }
            
//            if status == AVAuthorizationStatus.authorized {
//                // アクセス許可あり
//            } else if status == AVAuthorizationStatus.restricted {
//                // ユーザー自身にカメラへのアクセスが許可されていない
//            } else if status == AVAuthorizationStatus.notDetermined {
//                // まだアクセス許可を聞いていない
//            } else if status == AVAuthorizationStatus.denied {
//                // アクセス許可されていない
//            }
        }
    }
    
    
    /** 再生か録音 */
    enum VoiceRecordType {
        /** SoloAmbient(Default) */
        case SoloAmbient
        /** 再生 */
        case Playing
        /** 録音 */
        case Recording
    }
    
    /**
     ◆初期設定
     - Parameter recInterval : 最大録音時間（秒）
     */
     init(_ recInterval : Double = -1) {
        super.init()
        
        //●音声認識の認証処理
//        SFSpeechRecognizer.requestAuthorization { authStatus in
//            OperationQueue.main.addOperation {
//                switch authStatus {
//                case .authorized:
//                    print("音声認識へのアクセスが許可されています。")
//                    break
//                case .denied:
//                    print("音声認識へのアクセスが拒否されています。")
//                    break
//                case .restricted:
//                    print("この端末で音声認識はできません。")
//                    break
//                case .notDetermined:
//                    print("音声認識はまだ許可されていません。")
//                    break
//                }
//            }
//        }
        
        Setting = SettingClass()
        let  settingTime =  Setting.settingTime
        self.maxRecTimeInterval = settingTime
  
    }
    /**
     ◆実行中かどうか
     */
    func IsRunning() -> Bool {
        return audioEngine.isRunning
    }
    /**
     ◆録音開始
     - Parameter filePath : 保存先ファイルパス
     */
    func startRecording(_ filePath : NSURL) throws {
        
        // 最大録音時間が０以外かつ録音中でなければ開始
        if !audioEngine.isRunning && self.maxRecTimeInterval != 0 {
            // 再生停止
            self.stopPlayer()
            
            // 既存タスクがあればキャンセルしてリセット
            if let recognitionTask = self.recognitionTask {
                recognitionTask.cancel()
                self.recognitionTask = nil
            }
            
            // セッションを準備する
            // 録音時は"AVAudioSessionCategoryRecord"を設定
            try self.setSessionCategory(VoiceRecordType.Recording)
//            try audioSession.setCategory(AVAudioSessionCategoryRecord, with : .allowBluetooth)
//            try audioSession.setCategory(AVAudioSessionCategoryPlayAndRecord, with : .allowBluetooth)      // 録音して再生すると音量が小さい
//            try audioSession.setMode(AVAudioSessionModeGameChat)
            try audioSession.setActive(true, with : .notifyOthersOnDeactivation)    // 指定したオプションを使用して、オーディオセッションを有効・無効にする。
            
            // 認識リクエストの初期化（マイクを利用する場合）
            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            guard let recognitionRequest = self.recognitionRequest else { fatalError("リクエスト生成エラー") }
            // 録音完了前に途中の結果を報告する。（デフォルトはfalse） trueにすると、完了時に結果を遡って修正してくれる。
            recognitionRequest.shouldReportPartialResults = true
            
            // 保存する場所
//            let filePath = self.documentFilePath()
            self.recFilePath = filePath
            // オーディオフォーマット
            let format = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: 44100, channels: 1 , interleaved: true)
            // 出力先オーディオファイル
            let audioFile = try AVAudioFile(forWriting: self.recFilePath! as URL, settings: (format?.settings)!)
            
            // マイクからの録音
           let inputNode = audioEngine.inputNode
            inputNode.volume = 1.0
            let recordingFormat = inputNode.outputFormat(forBus: 0)
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer: AVAudioPCMBuffer, when: AVAudioTime) in
//                self.recognitionRequest?.append(buffer)
                
                // オーディオファイルにバッファを書き込む
                do {

                    try audioFile.write(from: buffer)
//                    print("書き込み... : ", audioFile.length)
//
                    self.nowRecTime = Int(Double(audioFile.length) / when.sampleRate)
                    
//                    print("時間(秒)：", self.nowRecTime)

                    self.VoiceRecorderDelegate?.voiceRecorderRecording(audioFile.url as NSURL, Double(self.nowRecTime))
                    
                    
                    // 最大録音時間が指定されている＆最大録音時間を超えたら停止する
                    if self.maxRecTimeInterval > 0 && self.nowRecTime >= self.maxRecTimeInterval {
                        try self.stopRecording()
                    }
                    
                } catch let error {
                    print("audioFile write error : ", error)
                }
            }

//            recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { (result, error) in
//                var isFinal = false
//                print("recognitionTask")
//                
//                if let result = result {
//                    // 録音内容（マイクから取得した音声）
////                    let s : String = result.bestTranscription.formattedString
//                    isFinal = result.isFinal
//                }
//                
//                if error != nil || isFinal {
//                    // 録音停止
//                    self.audioEngine.stop()
//                    inputNode.removeTap(onBus: 0)
//                    if self.recFilePath != nil {
//                        self.VoiceRecorderDelegate?.voiceRecorderStopRecording(self.recFilePath!)
//                    }
//                    print("録音停止")
//                    if self.guideLabel != nil {
//                        self.guideLabel?.text = "録音停止"
//                    }
//                    
//                    self.recognitionRequest = nil
//                    self.recognitionTask = nil
//                    self.recFilePath = nil
//                }
//            }
            
            self.nowRecTime = 0
            
            // 録音準備
            audioEngine.prepare()
            
            self.VoiceRecorderDelegate?.voiceRecorderStartRecording(self.recFilePath)
            
            // 録音開始
            try audioEngine.start()
            
            print("録音開始")
            if self.guideLabel != nil {
                self.guideLabel?.text = "録音開始"
            }
            
        }
    }
    /**
     ◆録音停止
     */
    func stopRecording() throws {
        // 実行中なら停止
        if self.audioEngine.isRunning {
            self.audioEngine.stop()
            self.audioEngine.inputNode.removeTap(onBus: 0)
            self.recognitionRequest?.endAudio()
            if recognitionTask != nil {
                recognitionTask?.finish()
            }
            if self.recFilePath != nil {
                self.VoiceRecorderDelegate?.voiceRecorderStopRecording(self.recFilePath!)
            }
            self.recFilePath = nil
            self.nowRecTime = 0
            print("録音停止")
            if self.guideLabel != nil {
                self.guideLabel?.text = "録音停止"
            }
        }
    }
    
    /**
     ◆再生
     - Parameter filePath : 再生するファイルパス
     */
    func play(_ filePath : NSURL) {
        // ファイルが存在する＆録音中でなければ再生する
        if !audioEngine.isRunning && FileManager.default.fileExists(atPath: filePath.path!) {
            self.stopPlayer()
            do {
                // 再生時は"AVAudioSessionCategoryPlayback"を設定
                try self.setSessionCategory(VoiceRecordType.Playing)
//                try audioSession.setCategory(AVAudioSessionCategoryPlayback)
                try audioPlayer = AVAudioPlayer(contentsOf: filePath as URL)
                self.audioPlayer?.delegate = self
                self.audioPlayer?.volume = 1.0
                self.audioPlayer?.numberOfLoops = 0
//                self.audioPlayer?.prepareToPlay()
                self.audioPlayer?.play()
                print("再生")
                
                if self.guideLabel != nil {
                    self.guideLabel?.text = "再生中"
                }
                
            } catch let error {
                print("再生エラー : ", error)
            }
            
        }
    }
    /**
     ◆再生停止
     */
    func stopPlayer() {
        if audioPlayer != nil && (audioPlayer?.isPlaying)! {
            // 再生中なら停止
            audioPlayer?.stop()
            print("再生停止")
            if self.guideLabel != nil {
                self.guideLabel?.text = "再生停止"
            }
        }
    }
    
    /** 
     ◆セッションカテゴリの設定
     - Parameter type : 再生か録音か
     */
    func setSessionCategory(_ type : VoiceRecordType) throws {
        do{
            // 録音中でも再生中でもない場合
            if !audioEngine.isRunning || (audioPlayer == nil || !(audioPlayer?.isPlaying)!) {
                if type == .Playing {
                    try audioSession.setCategory(AVAudioSessionCategoryPlayback)
                } else if type == .Recording {
                    try audioSession.setCategory(AVAudioSessionCategoryRecord, with : .allowBluetooth)
                } else {
                    try audioSession.setCategory(AVAudioSessionCategorySoloAmbient)
                }
                try audioSession.setActive(true)
            }
        } catch let error {
            print("エラー : ", error)
        }
    }
    
    /**
     ◆録音・再生するファイルのパスを取得する
     */
    func documentFilePath() -> NSURL {
        // 保存する場所: 今回はDocumentディレクトリにファイル名"sample.caf"で保存
        let documentDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        return NSURL(fileURLWithPath: documentDir + "/sample.caf")
    }
    /**
     ◆ファイルを削除する
     - Parameter filePath : 削除するファイルパス
     */
    func deleteDocumentFile(_ filePath : String) {
        do {
            try FileManager.default.removeItem(atPath: filePath)
        } catch let error {
            print("削除に失敗 : ", error)
        }
    }
    /**
     時間(秒)をhh:mm:ss形式にする
     - Parameter d : 時間(秒)
     */
    func formatTimeString(d: Double) -> String {
        let s: Int = Int(d.truncatingRemainder(dividingBy: 60))
        let m: Int = Int(((d - Double(s)) / 60).truncatingRemainder(dividingBy: 60))
        let h: Int = Int(((d - Double(m) - Double(s)) / 3600).truncatingRemainder(dividingBy: 3600))
        let str = String(format: "%02d:%02d:%02d", h, m, s)
        return str
    }
}

/**
 サウンド再生の完了やオーディオのデコード、オーディオの中断などに対応
 */
extension VoiceRecorderClass : AVAudioPlayerDelegate {

    /**
     ◆電話の呼び出しなどでオーディオプレイヤが中断された時に呼び出されます。
     */
//    func audioPlayerBeginInterruption(_ player: AVAudioPlayer) {
//        print("audioPlayerBeginInterruption")
//    }
    /**
     ◆ユーザが電話の呼び出しを無視するなどで、中断が終了すると呼び出されます。
     */
//    func audioPlayerEndInterruption(_ player: AVAudioPlayer, withOptions flags: Int) {
//        print("audioPlayerEndInterruption")
//    }
    /**
     ◆オーディオプレイヤの再生中にデコードエラーが発生した時に呼び出されます。
     */
    func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
        print("audioPlayerDecodeErrorDidOccur")
    }
    /**
     ◆サウンドの再生が完了した時に呼び出されます。
     */
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        print("再生終了")
        if flag {
            if self.guideLabel != nil {
                self.guideLabel?.text = "再生終了"
            }
            
            // 終了イベント
            if self.IsFinishPlayingEvent {
                self.PlayerFinishPlayingEvent?()
                self.IsFinishPlayingEvent = false
            }
        }
    }
    
}


/** VoiceRecorderClassのプロトコル */
protocol VoiceRecorderDelegate {
    /**
     録音開始前
     - Parameter filePath : 録音出力先ファイルパス
     */
    func voiceRecorderStartRecording(_ filePath : NSURL?)
    /**
     録音終了後
     - Parameter filePath : 録音出力先ファイルパス
     */
    func voiceRecorderStopRecording(_ filePath : NSURL?)
    /**
     録音中
     - Parameter filePath : 録音出力先ファイルパス
     - Parameter recTime : 録音時間（秒）
     */
    func voiceRecorderRecording(_ filePath : NSURL?, _ recTime : Double)
}
