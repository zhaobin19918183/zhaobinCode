//
//  PointAnnotationEx.swift
//  MyMap2
//
//  Created by 栄養 メイト on 2017/04/18.
//  Copyright © 2017年 njk. All rights reserved.
//

import UIKit
import MapKit

/** MKPointAnnotationの拡張クラス */
class PointAnnotationEx: MKPointAnnotation {

    /** レイヤ名・グループ名（識別用） */
    var layerName: String = "pointAnnotation"
    /** ID */
    var id: String?
    /** プロパティ */
    var properties: NSDictionary?
    
    /** ピンの色 */
    var pinColor: UIColor?
    /** ピンの色（強調） */
    var emphasisPinColor: UIColor?
    /** 強調したピンの色を使用するか */
    var isEmphasisPinColor: Bool! = false
     
    // ピンの画像
    var pinImage: UIImage?
    // ピンの画像を指定サイズに伸縮させるか
    var isStretch: Bool! = true
    // 画像の幅（伸縮後）
    var imageStretchWidth: CGFloat! = 32
    // 画像の高さ（伸縮後）
    var imageStretchHeight: CGFloat! = 32
    
}
