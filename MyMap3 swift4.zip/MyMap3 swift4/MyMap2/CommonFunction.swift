//
//  CommonFunction.swift
//  My地図アプリ
//
//  Created by developer on 2017/02/06.
//  Copyright © 2017年 njk. All rights reserved.
//

import UIKit
import AVFoundation
import Speech
import SystemConfiguration

protocol Utilities {
}

extension NSObject:Utilities{
    
    enum ReachabilityStatus {
        case notReachable
        case reachableViaWWAN
        case reachableViaWiFi
    }
    
    var currentReachabilityStatus: ReachabilityStatus {
        
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        guard let defaultRouteReachability = withUnsafePointer(to: &zeroAddress, {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                SCNetworkReachabilityCreateWithAddress(nil, $0)
            }
        }) else {
            return .notReachable
        }
        
        var flags: SCNetworkReachabilityFlags = []
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags) {
            return .notReachable
        }
        
        
        if flags.contains(.reachable) == false {
            return .notReachable
        }
        else if flags.contains(.isWWAN) == true {
            return .reachableViaWWAN
        }
        else if flags.contains(.connectionRequired) == false {
            return .reachableViaWiFi
        }
        else if (flags.contains(.connectionOnDemand) == true || flags.contains(.connectionOnTraffic) == true) && flags.contains(.interventionRequired) == false {
            return .reachableViaWiFi
        }
        else {
            return .notReachable
        }
    }
    
}



extension String  {
    
    
    func  Format(_ value: String) -> String{
        return NSString(format: self as NSString, value) as String
    }
    
    func  Format(_ value: Double) -> String{
        let val =     String( value.rounded(.up))
        return NSString(format: self as NSString, val) as String
    }
    
    func  Format(_ value: Int )-> String{
        let val =   String( value)
        return NSString(format: self as NSString, val) as String
    }
    
    func  Format(_ value: String,_ value2:String) -> String{
        return NSString(format: self as NSString, value,value2) as String
    }
    
    func  Format(_ value: Double,_ value2: Double) -> String{
        let val = String( value.rounded(.up))
        let val2 = String( value2.rounded(.up))
        return NSString(format: self as NSString, val,val2) as String
    }
    
    func  Format(_ value: Double,_ value2: String) -> String{
        let val = String( value.rounded(.up))
        return NSString(format: self as NSString, val,value2) as String
    }
    
    func  Format(_ value: String,_ value2: Double) -> String{
        let val = String( value2.rounded(.up))
        return NSString(format: self as NSString, value,val ) as String
    }
    
    func  Format(_ value: Double,_ value2: String,_ value3 : String) -> String{
        let val = String( value.rounded(.up))
        return NSString(format: self as NSString, val,value2,value3 ) as String
    }
    
    func  Format(_ value: String,_ value2: String,_ value3 : String) -> String{
        return NSString(format: self as NSString, value,value2,value3 ) as String
    }
    
    func Find(_ value : String)-> Bool {
        let arr = value.components(separatedBy: ",") as [String]
        for val in arr  {
            if( self.contains(val)) {return true}
        }
        return false
    }
    
    func CreateTextFIle( path  : URL) {
        do {
            try self.write(to: path, atomically: true, encoding: String.Encoding.utf8)
        } catch let error as NSError {
            print("failed to write: \(error)")
        }
    }
    
    func RouteNameConvert() -> String{
        let date_formatter: DateFormatter = DateFormatter()
        date_formatter.locale     = NSLocale(localeIdentifier: "ja") as Locale!
        date_formatter.dateFormat = "yyyyMMddHHmmssSS"
        
        if let theDate = date_formatter.date(from: self) {
            date_formatter.dateFormat = "yyyy年MM月dd日 HH時mm分ss秒のルート"
            return date_formatter.string(from: theDate)
        } else {
            return self
        }
    }
    
}
extension NSString {
    
    func JsonToDic() -> [[String : Any]]{
        let  jsonData = self.data(using:String.Encoding.utf8.rawValue)
        return try! JSONSerialization.jsonObject(with: jsonData!, options: []) as! [[String : Any]]
    }
}

extension Sequence where Iterator.Element == [String: Any] {
    
    var ToJson : String {
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: self, options: .prettyPrinted)
            let json = NSString(data:   jsonData, encoding: String.Encoding.utf8.rawValue)! as String
            print(json)
            return json
        } catch {
            print(error.localizedDescription)
            return "";
        }
    }
    
    
    func CreateTextFIle( path  : URL) {
        let json = self.ToJson
        do {
            try json.write(to: URL(fileURLWithPath: path.path), atomically: true, encoding: String.Encoding.utf8)
        } catch let error as NSError {
            print("failed to write: \(error)")
        }
    }
    
    func togpxData() {
      
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let formatter2 = DateFormatter()
        formatter2.dateFormat = "yyyy-MM-dd"
        let formatter3 = DateFormatter()
        formatter3.dateFormat = "HH:mm:ss"
        var date1 = formatter.date(from: "2016-05-01 00:00:05")
        
        for item in  self {
            let date = formatter2.string(from: date1!)
           let date2 = formatter3.string(from: date1!)
            
            print( " <wpt lat=\"\(item[Col.Lat.Val] as! Double)\" lon=\"\(item[Col.Lon.Val] as! Double)\"><time>\(date)T\(date2)Z</time></wpt>")
            date1 =  Date(timeInterval: 3, since: date1!)
        }
        
        
    }
    
}

extension Dictionary {
    
    var ToJson : String {
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: self, options: .prettyPrinted)
            let json = NSString(data:   jsonData, encoding: String.Encoding.utf8.rawValue)! as String
            print(json)
            return json
        } catch {
            print(error.localizedDescription)
            return "";
        }
    }
    
    func CreateTextFIle( path  : URL) {
        let json = self.ToJson
        do {
            try json.write(to: URL(fileURLWithPath: path.path), atomically: true, encoding: String.Encoding.utf8)
        } catch let error as NSError {
            print("failed to write: \(error)")
        }
    }
    
    
    
}


extension Timer {
    
    func Start(_ selector : Selector,_ timeInterval : Double)  -> Timer{
        return Timer.scheduledTimer(timeInterval: timeInterval, target: self, selector: selector, userInfo: nil, repeats: true)
    }
    
    func Stop() {
        if self.isValid == true {
            self.invalidate()
        }
    }
    
    
}

extension Data {
    func hexEncodedString() -> String {
        return map { String(format: "%02x", $0) }.joined()
    }
}

extension Date {
    func ToStr() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "ssSSS"
        
        return formatter.string(from: self)
    }
}
