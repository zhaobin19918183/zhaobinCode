//
//  BaseUITextField.swift
//  My地図アプリ
//
//  Created by developer on 2017/02/15.
//  Copyright © 2017年 njk. All rights reserved.
//

import UIKit

class BaseUITextField: UITextField , UITextFieldDelegate{

    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        self.delegate = self;
        self.returnKeyType = .done
    }
  
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
         self.resignFirstResponder()
        return true;
    }

}
