//
//  SoundVibrateClass.swift
//  MyMap
//
//  Created by developer on 2017/04/13.
//  Copyright © 2017年 njk. All rights reserved.
//
import Foundation
import AudioToolbox
import AVFoundation

/** システムサウンドID */
enum SystemSoundIDs : UInt32
{
    /** 鐘（振動1回） */
    case MailReceived = 1000
    /** スウォッシュ（振動なし） */
    case MailSent = 1001
    /** トライトーン（振動1回） */
    case Voicemail = 1002
    /** SMSメッセージ受信音（振動2回） */
    case ReceivedMessage = 1003
    /** SMSメッセージ送信音（振動なし） */
    case SentMessage = 1004
    /** 通知（振動1回） */
    case Alarm = 1005
    /** 充電残量低下音（振動なし） */
    case LowPower = 1006
    /** トライトーン（振動２回） */
    case SMSReceived = 1007
    /** チャイム（振動２回） */
    case SMSReceived2 = 1008
    /** ガラス（振動２回） */
    case SMSReceived3 = 1009
    /** ホーン（振動２回） */
    case SMSReceived4 = 1010
    /** なし（振動２回） */
    case SMSReceived_Vibrate = 1011
    /** トライトーン（振動２回） */
    case SMSReceived1 = 1012
    /** ベル（振動２回） */
    case SMSReceived5 = 1013
    /** エレクトリック（振動２回） */
    case SMSReceived6 = 1014
    /** トライトーン（振動1回） */
    case Voicemail2 = 1015
    /** ツイート（振動なし） */
    case TweetSent = 1016
    /** 通知（振動1回 長い） */
    case CalendarAlert2 = 1017
    /** 予感 */
    case Anticipate = 1020
    /** ブルーム */
    case Bloom = 1021
    /** カリプソ */
    case Calypso = 1022
    /** 機関車 */
    case Choo_Choo = 1023
    /** 降下 */
    case Descent = 1024
    /** ファンファーレ */
    case Fanfare = 1025
    /** はしご */
    case Ladder = 1026
    /** メヌエット */
    case Minuet = 1027
    /** ニュースフラッシュ */
    case NewsFlash = 1028
    /** ノアール */
    case Noir = 1029
    /** シャーウッドの森 */
    case SherwoodForest = 1030
    /** スペル */
    case Spell = 1031
    /** サスペンス */
    case Suspense = 1032
    /** 電報 */
    case Telegraph = 1033
    /** つま先 */
    case Tiptoes = 1034
    /** タイプライター */
    case Typewriters = 1035
    /** アップデート */
    case Update = 1036
    /** USSD */
    case ussd = 1050
    /** SIMToolkitCallDropped */
    case SIMToolkitCallDropped = 1051
    /** SIMToolkitGeneralBeep */
    case SIMToolkitGeneralBeep = 1052
    /** SIMToolkitNegativeACK */
    case SIMToolkitNegativeACK = 1053
    /** SIMToolkitPositiveACK */
    case SIMToolkitPositiveACK = 1054
    /** SIMToolkitSMS */
    case SIMToolkitSMS = 1055
    /** Tink */
    case Tink = 1057
    /** 着信先が通話中 */
    case AudioToneBusy = 1070
    /** ct-congestion */
    case AudioToneCongestion = 1071
    /** ct-path-ack */
    case AudioTonePathAcknowledge = 1072
    /** ct-error */
    case AudioToneError = 1073
    /** 着信開始音 */
    case AudioToneCallWaiting = 1074
    /** ct-keytone2 */
    case AudioToneKey2 = 1075
    /** スクリーンロック音 */
    case ScreenLocked = 1100
    /** スクリーンロック解除音 */
    case ScreenUnlocked = 1101
    /** FailedUnlock */
    case FailedUnlock = 1102
    /** Tink */
    case Tink2 = 1103
    /** キーボードのタップ音 */
    case Tock = 1104
    /** キーボードのタップ音 */
    case Tock2 = 1105
    /** パソコン接続音 */
    case ConnectedToPower = 1106
    /** RingerChanged */
    case RingerChanged = 1107
    /** シャッター音 */
    case CameraShutter = 1108
    /** シェイク音 */
    case ShakeToShuffle = 1109
    /** 音声認識開始音 */
    case JBL_Begin = 1110
    /** 音声認識完了音 */
    case JBL_Confirm = 1111
    /** 音声認識キャンセル音 */
    case JBL_Cancel = 1112
    /** ボイスレコーダの記録開始音 */
    case BeginRecording = 1113
    /** ボイスレコーダの記録停止音 */
    case EndRecording = 1114
    /** 音声コントロール認識音 */
    case JBL_Ambiguous = 1115
    /** 音声コントロール不認識音 */
    case JBL_NoMatch = 1116
    /** 動画の録画開始音 */
    case BeginVideoRecording = 1117
    /** 動画の録画停止音 */
    case EndVideoRecording = 1118
    /** VCInvitationAccepted */
    case VCInvitationAccepted = 1150
    /** VCRinging */
    case VCRinging = 1151
    /** 通話終了音 */
    case VCEnded = 1152
    /** VCCallWaiting */
    case VCCallWaiting = 1153
    /** VCCallUpgrade */
    case VCCallUpgrade = 1154
    /** プッシュ音(0) */
    case Push = 1200
    /** プッシュ音(1) */
    case Push1 = 1201
    /** プッシュ音(2) */
    case Push2 = 1202
    /** プッシュ音(3) */
    case Push3 = 1203
    /** プッシュ音(4) */
    case Push4 = 1204
    /** プッシュ音(5) */
    case Push5 = 1205
    /** プッシュ音(6) */
    case Push6 = 1206
    /** プッシュ音(7) */
    case Push7 = 1207
    /** プッシュ音(8) */
    case Push8 = 1208
    /** プッシュ音(9) */
    case Push9 = 1209
    /** プッシュ音(*) */
    case Push10 = 1210
    /** プッシュ音(#) */
    case Push11 = 1211
    /** Headset_StartCall */
    case Headset_StartCall = 1254
    /** Headset_Redial */
    case Headset_Redial = 1255
    /** Headset_AnswerCall */
    case Headset_AnswerCall = 1256
    /** Headset_EndCall */
    case Headset_EndCall = 1257
    /** Headset_CallWaitingActions */
    case Headset_CallWaitingActions = 1258
    /** Headset_TransitionEnd */
    case Headset_TransitionEnd = 1259
    /** トライトーン */
    case Voicemail3 = 1300
    /** ReceivedMessage */
    case ReceivedMessage2 = 1301
    /** 鐘 */
    case NewMail = 1302
    /** スウォッシュ */
    case MailSent2 = 1303
    /** 通知 */
    case Alarm2 = 1304
    /** スクリーンロック音 */
    case ScreenLocked2 = 1305
    /** Tock */
    case Tock3 = 1306
    /** トライトーン */
    case MSMReceived1 = 1307
    /** チャイム */
    case MSMReceived2 = 1308
    /** ガラス */
    case MSMReceived3 = 1309
    /** ホーン */
    case MSMReceived4 = 1310
    /**  */
    case SMSReceived_Vibrate2 = 1311
    /** トライトーン */
    case MSMReceived = 1312
    /** ベル */
    case MSMReceived5 = 1313
    /** エレクトリック */
    case MSMReceived6 = 1314
    /** トライトーン */
    case Voicemail4 = 1315
    /** 予感 */
    case Anticipate2 = 1320
    /** ブルーム */
    case Bloom2 = 1321
    /** カリプソ */
    case Calypso2 = 1322
    /** 機関車 */
    case Choo_Choo2 = 1323
    /** 降下 */
    case Descent2 = 1324
    /** ファンファーレ */
    case Fanfare2 = 1325
    /** はしご */
    case Ladder2 = 1326
    /** メヌエット */
    case Minuet2 = 1327
    /** ニュースフラッシュ */
    case News_Flash2 = 1328
    /** ノアール */
    case Noir2 = 1329
    /** シャーウッドの森 */
    case Sherwood_Forest2 = 1330
    /** スペル */
    case Spell2 = 1331
    /** サスペンス */
    case Suspense2 = 1332
    /** 電報 */
    case Telegraph2 = 1333
    /** つま先 */
    case Tiptoes2 = 1334
    /** タイプライター */
    case Typewriters2 = 1335
    /** アップデート */
    case Update2 = 1336
    /** RingerVibeChanged */
    case RingerVibeChanged = 1350
    /** SilentVibeChanged */
    case SilentVibeChanged = 1351
}


/**
 ◆振動（バイブレーション）
 */
final class SoundVibrateClass : NSObject {
    
    /** 次に振動させるまでの間隔（秒） */
    private let vibrationSleepInterval : Double = 0.5
    
    /** 初期設定 */
    override init() {
        super.init()
    }
    
    /**
     ◆振動させる
     - Parameter count : 振動させる回数
     */
    func PlayVibrate(_ count : Int = 1){
        let Setting  =  SettingClass()
      
      
        if Setting.settingPeoPleSelect == 0
        {
            PlaySystemSoundProc(kSystemSoundID_Vibrate, count)
        }
        
    }
    /**
     ◆システムサウンド（組み込みの効果音）を再生する
     - Parameter systemSoundID : システムサウンドID
     */
    func PlaySystemSoundID(_ systemSoundID : SystemSoundIDs){
//        AudioServicesPlaySystemSound(systemSoundID.rawValue)
        let Setting  =  SettingClass()
        if Setting.settingPeoPleSelect == 0
        {
           AudioServicesPlaySystemSoundWithCompletion(systemSoundID.rawValue, nil)
        }
       
    }
    /**
     ◆指定したサウンドIDを再生する
     - Parameter soundID : サウンドID
     */
    func PlaySoundID(_ soundID : UInt32)
    {
//        AudioServicesPlaySystemSound(soundID)
        let Setting  =  SettingClass()
        if Setting.settingPeoPleSelect == 0
        {
             AudioServicesPlaySystemSoundWithCompletion(soundID, nil)
        }

    }
    /**
     ◆サウンドファイルを再生する
     - Parameter soundFile : サウンドファイルパス
     */
    func PlaySoundFile(_ soundFile : String) -> SystemSoundID{
        // SystemSoundIDは0にしてURLの音源を再生する
        var soundIdRing : SystemSoundID = 0
        if let soundUrl : NSURL = URL( string : soundFile ) as NSURL? {
            
            let Setting  =  SettingClass()
            if Setting.settingPeoPleSelect == 0
            {
                AudioServicesCreateSystemSoundID(soundUrl, &soundIdRing)
                //            AudioServicesPlaySystemSound(soundIdRing)
                AudioServicesPlaySystemSoundWithCompletion(soundIdRing, nil)
            }

        }
        return soundIdRing
    }
    /**
     ◆プロジェクトファイル内のファイルを再生する
     - Parameter resourceName : ファイル名
     - Parameter resourceType : 拡張子
     */
    func PlayResourceFile(_ resourceName : String, _ resourceType : String) -> SystemSoundID{
        var soundIdRing:SystemSoundID = 0
        
        if let filePath = Bundle.main.path(forResource: resourceName, ofType: resourceType) {
            if let soundUrl : NSURL = NSURL(fileURLWithPath: filePath) as NSURL? {
                let Setting  =  SettingClass()
                if Setting.settingPeoPleSelect == 0
                {
                    AudioServicesCreateSystemSoundID(soundUrl, &soundIdRing)
                    //               AudioServicesPlaySystemSound(soundIdRing)
                    AudioServicesPlaySystemSoundWithCompletion(soundIdRing, nil)
                }

            }
        }
        return soundIdRing
    }
    
    /**
     ◆システムサウンドのファイル名一覧を取得する
     - Returns - システムサウンドファイル名
     */
    func GetSystemSoundFileName() -> [String]? {
        let path: String = "/System/Library/Audio/UISounds"
        return try? FileManager.default.contentsOfDirectory(atPath: path)
    }
    /**
     ◆システムサウンドのファイルパス一覧を取得する
     - Returns - システムサウンドファイルのパス
     */
    func GetSystemSoundFilePath() -> [String]? {
        let path: String = "/System/Library/Audio/UISounds"
        if var files = try? FileManager.default.contentsOfDirectory(atPath: path) {
            // 拡張子のないものは除外
            files = files.filter({ NSString(string: $0).pathExtension != "" })
            for i in 0..<files.count
            {
                files[i] = NSString(string: path).appendingPathComponent(files[i])
            }
            return files
        }
        return nil
    }
    
    /**
     ◆指定回数再生する
     - Parameter soundID : サウンドID
     - Parameter counter : 回数（０を指定しても最低１回は動作する）
     */
    private func PlaySystemSoundProc(_ soundID : UInt32, _ counter : Int){
        //●再生が終わった後で呼び出す処理
        AudioServicesPlaySystemSoundWithCompletion(soundID, {() -> Void in
            if counter > 1 {
                Thread.sleep(forTimeInterval: self.vibrationSleepInterval)
                self.PlaySystemSoundProc(soundID, counter - 1)
            } else {
                let Setting  =  SettingClass()
                if Setting.settingPeoPleSelect == 0
                {
                    AudioServicesRemoveSystemSoundCompletion(soundID)
                    AudioServicesDisposeSystemSoundID(soundID)
                }
                // 終了処理
               
            }
        })
    }
    
    private func StopSound(_ soundId:SystemSoundID){
        let Setting  =  SettingClass()
        if Setting.settingPeoPleSelect == 0
        {
            AudioServicesDisposeSystemSoundID(soundId)
        }
       
    }
    
    
    
}
