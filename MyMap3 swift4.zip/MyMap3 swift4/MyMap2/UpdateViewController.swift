//
//  UpdateViewController.swift
//  MyMap2
//
//  Created by newland on 2017/12/21.
//  Copyright © 2017年 njk. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation // 定位GPS相关

class UpdateViewController: BaseViewController,MKMapViewDelegate,CLLocationManagerDelegate {
    @IBOutlet weak var updatemapView: MKMapView!
    var locationlat = CLLocation()
    var locationManager = CLLocationManager()
    
    var isSelect = Bool()
    
    override func viewDidLoad() {
        super.viewDidLoad()
         clLoc?.initLocation(self.Setting,0.5)
        self.updatemapView.mapType = MKMapType.standard
        self.updatemapView.delegate = self
        self.updatemapView.isRotateEnabled = true
        self.updatemapView.showsUserLocation = true
        isSelect = true
        self.updatemapView.userTrackingMode = .none
        //マップの中心地がユーザの現在地を追従するように設定
        self.updatemapView.showsBuildings = true
        // 指南针
        if #available(iOS 9.0, *) {
            self.updatemapView.showsCompass = true
            // 比例尺
            self.updatemapView.showsScale = true
            // 交通状况
            self.updatemapView.showsTraffic = true
        }
        locationManager.delegate = self
        //每个十米获取用户位置
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        //Each ten meter takes the user's location
        locationManager.distanceFilter = 10
        //iOS8.0以上才可以使用
        if(UIDevice.current.systemVersion >= "8.0"){
            //始终允许访问位置信息
            locationManager.requestAlwaysAuthorization()
            //使用应用程序期间允许访问位置数据
            locationManager.requestWhenInUseAuthorization()
        }
        //To locate
        locationManager.startUpdatingLocation()
        let mTap:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(tapPress(_:)))
        self.updatemapView.addGestureRecognizer(mTap)
    
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        if let location = locations.last
        {
            locationlat = location
        }
    }
    
    @objc func tapPress(_ gestureRecognizer:UITapGestureRecognizer){
    
        let annotation = self.updatemapView.annotations
        let overremove = self.updatemapView.overlays
        //移除有所的大头针
        self.updatemapView.removeAnnotations(annotation)
        self.updatemapView.removeOverlays(overremove)
        let touchPoint:CGPoint = gestureRecognizer.location(in: updatemapView)
        let touchMapCoordinate:CLLocationCoordinate2D = updatemapView.convert(touchPoint, toCoordinateFrom: updatemapView)
        //创建_MKCoordinateSpan对象，设置地图的范围（越小越精确）
        let latDelta = 0.05
        let longDelta = 0.05
        let currentLocationSpan:MKCoordinateSpan = MKCoordinateSpanMake(latDelta, longDelta)
        //定义地图区域和中心坐标
        //使用当前位置
        let startlocation:CLLocation = locationManager.location!
        //使用自定义位置
        let center:CLLocation = CLLocation(latitude:touchMapCoordinate.latitude, longitude: touchMapCoordinate.longitude)
        let currentRegion:MKCoordinateRegion = MKCoordinateRegion(center: center.coordinate,
                                                                  span: currentLocationSpan)
        
        //设置显示区域
        self.updatemapView.setRegion(currentRegion, animated: true)
        
        //创建一个大头针对象
        let objectAnnotation = MKPointAnnotation()
        //设置大头针的显示位置
        objectAnnotation.coordinate = CLLocation(latitude: touchMapCoordinate.latitude,
                                                 longitude: touchMapCoordinate.longitude).coordinate
        //设置点击大头针之后显示的标题
        objectAnnotation.title = "目的地"
        self.updatemapView.addAnnotation(objectAnnotation)

        drawRedLine(startLine: startlocation, endLine: center)
    }
  
    func mapView(_ mapView: MKMapView, regionWillChangeAnimated animated: Bool) {
        
       
        print("地图缩放级别发送改变时")
//
    }
    
    
    @IBAction func search(_ sender: UIButton) {
    }
    
    @IBAction func back(_ sender: UIButton)
    {
         self.TopPage()
    }
    func  drawRedLine(startLine:CLLocation,endLine:CLLocation){
        
        // 2.苹果在中国区域默认使用高德地图
        let sourceLocation = CLLocationCoordinate2D(latitude: startLine.coordinate.latitude, longitude: startLine.coordinate.longitude)
        let destinationLocation = CLLocationCoordinate2D(latitude: endLine.coordinate.latitude, longitude: endLine.coordinate.longitude)
        
        // 3.
        let sourcePlacemark = MKPlacemark(coordinate: sourceLocation, addressDictionary: nil)
        let destinationPlacemark = MKPlacemark(coordinate: destinationLocation, addressDictionary: nil)
        
        // 4.
        let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
        let destinationMapItem = MKMapItem(placemark: destinationPlacemark)
        
        // 5.
        let sourceAnnotation = MKPointAnnotation()
        sourceAnnotation.title = "始发"
        
        if let location = sourcePlacemark.location {
            sourceAnnotation.coordinate = location.coordinate
        }
        
        
        let destinationAnnotation = MKPointAnnotation()
        destinationAnnotation.title = "终点"
        
        if let location = destinationPlacemark.location {
            destinationAnnotation.coordinate = location.coordinate
        }
        
        // 6.
    self.updatemapView.showAnnotations([sourceAnnotation,destinationAnnotation], animated: true )
        
        // 7.
        let directionRequest = MKDirectionsRequest()
        directionRequest.source = sourceMapItem
        directionRequest.destination = destinationMapItem
        directionRequest.transportType = .automobile
        
        // Calculate the direction
        let directions = MKDirections(request: directionRequest)
        
        // 8.
        directions.calculate { (response, error) in
            guard let response = response else {
                if let error = error {
                    print("Error: \(error)")
                }
                
                return
            }
            
            let route = response.routes[0]
            self.updatemapView.add(route.polyline, level: MKOverlayLevel.aboveRoads)
            
            let rect = route.polyline.boundingMapRect
            self.updatemapView.setRegion(MKCoordinateRegionForMapRect(rect), animated: true)
        }
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.red
        renderer.lineWidth = 4.0
        return renderer
    }
    
    //MARK : 自定义大头针
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
      
        if annotation is MKUserLocation {
            let userLocationView = mapView.dequeueReusableAnnotationView(withIdentifier: "userLocationIdentifier")
            let ann2 = annotation as! MKUserLocation
            ann2.title = "現在地"
            userLocationView?.annotation = ann2
            return userLocationView
        }
        
        return nil
    }
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView,
                 didChange newState: MKAnnotationViewDragState,
                 fromOldState oldState: MKAnnotationViewDragState) {
        print("移动annotation位置时调用")
    }
    // 蓝点: 大头针"视图"  大头针"数据模型"
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        // 设置地图显示区域
        if isSelect == true
        {
            isSelect = false
            let center = (userLocation.coordinate)
            let span = MKCoordinateSpanMake(0.0219952102009202, 0.0160932558432023)
            let region: MKCoordinateRegion = MKCoordinateRegionMake(center, span)
            mapView.setRegion(region, animated: true)
            
        }
        
    
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
