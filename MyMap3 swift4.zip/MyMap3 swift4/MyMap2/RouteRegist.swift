//
//  RouteRegist.swift
//  MyMap2
//
//  Created by 栄養 メイト on 2017/04/17.
//  Copyright © 2017年 njk. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import SSZipArchive
import CoreMotion


/** ルート登録ビューコントローラー */
class RouteRegist: BaseViewController ,UIAccelerometerDelegate{
    //计步器对象
    var motionManager = CMMotionManager()
    let pedometer = CMPedometer()
    var stepInt:Int = 0
     var stepStrat:Int = 0
    
    /** 録音クラス */
    fileprivate let voiceRec : VoiceRecorderClass = VoiceRecorderClass()
    /** 登録POIタイプ */
    fileprivate var registPOItype : PoiType = PoiType.None
    /** ルート名 */
    fileprivate var routeName : String = ""
    /** 音声ファイルの保存先フォルダ */
    fileprivate var soundRouteDir : URL? = nil
    /** 登録するPOI群 */
    fileprivate var registPOI : [[String:Any]] = []
    /** ルート登録処理が開始したかどうか */
    fileprivate var IsStartRegist : Bool = false
    /** POIの登録ボタンを実行したかどうか */
    fileprivate var IsRegistPoiStart : Bool = false
    /** 録音中かどうか */
    fileprivate var IsRecording : Bool = false
    /** ルート登録ボタンを押した状態かどうか */
//    fileprivate var IsRegistButtonPress : Bool = false
    /** 読み上げタイマー */
    fileprivate var speakTimer : Timer? = nil
    var t = NSInteger()
  private var movelen: Double = 0;    /** 危険 */
     private  var clCalc = Calculation()
    private var oldpt :[String:Any]? = nil;
    @IBOutlet weak var btnDanger: UIButton!
    /** 情報 */
    @IBOutlet weak var btnInfo: UIButton!
    /** お気に入り */
    @IBOutlet weak var btnFavorite: UIButton!
    /** 登録 */
    @IBOutlet weak var btnRegist: UIButton!
    /** 中止 */
    @IBOutlet weak var btnCancel: UIButton!
    /** 地図 */
    @IBOutlet weak var myMapView: MKMapView!
    /** 位置情報 */
    @IBOutlet weak var lblLocation: UILabel!
    /** メッセージ表示 */
    @IBOutlet weak var lblMessage: UILabel!
    /** 追跡モード切り替え */
    @IBOutlet weak var btnUserTracking: UIButton!
    
    /** メッセージラベルの表示・非表示 */
    var IsMessageHidden : Bool {
        get { return self.lblMessage.isHidden }
        set (val) {
            self.lblMessage.isHidden = val
            // ボタンの使用可否
            self.setButtonEnabled(self.lblMessage.isHidden)
        }
    }

    /**
     ビューにあるボタンの使用可否を設定する
     - Parameter isEnabled : 使用可否
     */
    fileprivate func setButtonEnabled(_ isEnabled : Bool) {
        for subview in self.view.subviews {
            if subview is UIButton {
                let button = subview as! UIButton
                // 中止ボタン以外
                if button != btnCancel {
                   button.isEnabled = isEnabled
                }
            }
        }
    }
        
    /** ◆コントローラーのビューがメモリにロードされた後に呼び出されるメソッド */
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       
//        btnFavorite.isHidden = true
        // 位置情報
        super.clLoc?.initLocation(self.Setting, Double(super.Setting.RegistDistanceInterval))
        if (clLoc?.IsDenied)! {
            super.Speak("位置情報の取得が許可しないに設定されています。許可に変更してから実行してください")
            super.IsSpeakEndEvent = true
            super.SpeakEndEvent = {
                super.IsSpeakEndEvent = false
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    super.TopPage()
                }
            }
            return
        }
        super.clLoc?.LocationEnd()
        super.clLoc?.LocationDelegate = self
        super.clLoc?.StartLocation()                     // 位置情報の取得開始
        
        // 録音クラス
        if self.voiceRec.IsDenied {
            super.Speak("マイクの使用が許可しないに設定されています。許可に変更してから実行してください。")
            super.IsSpeakEndEvent = true
            super.SpeakEndEvent = {
                super.IsSpeakEndEvent = false
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    super.TopPage()
                }
            }
            return
        }
        self.voiceRec.maxRecTimeInterval = super.Setting.settingTime  // 録音時間(秒)
        self.voiceRec.VoiceRecorderDelegate = self
        
        // ルート名
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyyMMddHHmmssSS"
        self.routeName = formatter.string(from: Date())
        
        // 音声ファイルの保存先フォルダ
        self.soundRouteDir = super.SoundDir.appendingPathComponent("\(super.Setting.User.description)_\(self.routeName)", isDirectory : true)
        try! FileManager.default.createDirectory(atPath: (self.soundRouteDir?.path)!, withIntermediateDirectories: true, attributes: nil)
        
        // Soundフォルダに録音ファイル（ルート名）を出力する
        do {
            let filePath = self.soundRouteDir?.appendingPathComponent("RouteName.caf", isDirectory : false)
            try self.voiceRec.startRecording(filePath! as NSURL)
        } catch {
            print("ERROR")
        }
        self.myMapView.mapType = .standard
        // 地図
        self.myMapView.delegate = self
        
        // ダブルタップで地図切り替え
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(changeMapType(sender:)))
        doubleTap.numberOfTapsRequired = 2          // 認識するのに必要なタップ数
        doubleTap.numberOfTouchesRequired = 2       // 認識するために押さなければならない指の数
        self.myMapView.addGestureRecognizer(doubleTap)
    }
    
    /**
     地図の切り替え
     */
    @objc func changeMapType(sender: UITapGestureRecognizer) {
        if self.myMapView.mapType == .standard {
            self.myMapView.mapType = .satellite
        } else {
            self.myMapView.mapType = .standard
        }
    }
    
    /** ◆警告を受け取ったときに呼ばれるメソッド */
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    /** ◆画面が表示される直前 */
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    /** ◆画面が表示された直後 */
    override func viewDidAppear(_ animated: Bool) {
 
        
    }
    func stepString()
    {
        motionManager.accelerometerUpdateInterval = 1/4
        if motionManager.isAccelerometerAvailable == true
        {
            let queue = OperationQueue.current
            
            motionManager.startAccelerometerUpdates(to: queue!, withHandler: { (accelerometerData, error) in
                
                let sqrtValue = sqrt((accelerometerData?.acceleration.x)!*(accelerometerData?.acceleration.x)! + (accelerometerData?.acceleration.y)!*(accelerometerData?.acceleration.y)! + (accelerometerData?.acceleration.z)!*(accelerometerData?.acceleration.z)! )
                if sqrtValue >  1.552188
                {
                    self.stepInt =  self.stepInt + 1
                    
                    
                }
                
                
            })
            
        }
 
    }
    
    func startPedometerUpdates()
    {
        guard CMPedometer.isStepCountingAvailable()
            else {
                //      self.textView.text =
                print("\n当前设备不支持获取步数\n")
                return
        }
        let cal = Calendar.current
        var comps = cal.dateComponents([.year, .month, .day], from: Date())
            comps.hour = 0
            comps.minute = 0
            comps.second = 0
            let midnightOfToday = cal.date(from: comps)!
             //初始化并开始实时获取数据
        
        self.pedometer.startUpdates(from: midnightOfToday) { (accelerometerData,_ ) in

            if let numberOfSteps = accelerometerData?.numberOfSteps
            {
                if self.stepStrat == 0
                {
                    self.stepStrat  =  Int(truncating: numberOfSteps)
                }
                else
                {
                 self.stepInt = Int(truncating: numberOfSteps) - self.stepStrat
                }

            }
            DispatchQueue.main.async{
                
            }
            
        }
    
        
    }

    /** ◆別の画面に遷移する前に呼ばれるメソッド（ビューが破棄されたり、覆われたり、隠されたりする前） */
    override func viewWillDisappear(_ animated: Bool) {
        super.IsSpeakEndEvent = false
        super.clLoc?.LocationDelegate = nil
        super.clLoc?.GpsStateEvent = nil
        super.clLoc?.MoveDegreeEvent = nil
        super.clLoc?.DegreeEvent = nil
        super.clLoc?.StopEvent = nil
        super.clLoc?.StartLocationEvent = nil
        super.clLoc = nil
        if super.clPHP?.task != nil {
            super.clPHP?.task?.cancel()
        }
        super.clPHP?.JsonData = nil
        super.clPHP?.ZipPath = nil
        super.clPHP?.UploadComplete = nil
        super.clPHP?.PhpComplete = nil
        super.clPHP = nil
        super.talker?.delegate = nil
        super.talker = nil
        
        self.voiceRec.VoiceRecorderDelegate = nil
        try! self.voiceRec.setSessionCategory(.SoloAmbient)
        self.myMapView.delegate = nil
        
        if self.speakTimer != nil {
            self.speakTimer?.Stop()
            self.speakTimer = nil
        }
    }
    /** ◆別の画面に遷移した後に呼ばれるメソッド（ビューが破棄されたり、覆われたり、隠されたりした後） */
    override func viewDidDisappear(_ animated: Bool) {
//        if let parentView = self.parent?.view {
//            for subview in parentView.subviews {
//                subview.removeFromSuperview()
//            }
//        }
    }
    
    /** ◆登録「危険」 */
    @IBAction func btnDangerTouchDown(_ sender: UIButton) {
        RegistPOI(.Danger)
    }
    /** ◆登録「情報」 */
    @IBAction func btnInfoTouchDown(_ sender: UIButton) {
        RegistPOI(.Location)
    }
    /** ◆登録「お気に入り」*/
    @IBAction func btnFavoriteTouchDown(_ sender: UIButton)
    {
//        RegistPOI(.Like)
        if   self.myMapView.mapType == .standard {
            self.myMapView.mapType = .satellite
        } else {
            self.myMapView.mapType = .standard
        }
        
    }
    /** ◆その他「登録」 */
    @IBAction func btnRegistTouchDown(_ sender: UIButton) {
        if (self.clLoc?.Routes.count)!  < 2 {
            super.Speak("ルートが作成されていません。", false, false)
            return
        }
        
        // 登録停止
        super.clLoc?.RecodeStop()
        
        let alert: UIAlertController = UIAlertController(title: "登録", message: "登録を行います。\nよろしいですか？", preferredStyle: .alert)
        // OKボタン
        let defaultAction: UIAlertAction = UIAlertAction(title: "OK", style: .default, handler:{
            // ボタンが押された時の処理を書く（クロージャ実装）
            (action: UIAlertAction!) -> Void in
            self.Complete()
        })
        // キャンセルボタン
        let cancelAction: UIAlertAction = UIAlertAction(title: "キャンセル", style: .cancel, handler:{
            // ボタンが押された時の処理を書く（クロージャ実装）
            (action: UIAlertAction!) -> Void in
            
            // 位置情報の取得再開
            super.clLoc?.RecodeReStart()
            
        })
        alert.addAction(cancelAction)
        alert.addAction(defaultAction)
        
        // Alertを表示
        present(alert, animated: true, completion: nil)
        
    }
    /** ◆その他「中止」 */
    @IBAction func btnCancelTouchDown(_ sender: UIButton) {
        // 登録停止
        super.clLoc?.RecodeStop()
        
        let alert: UIAlertController = UIAlertController(title: "登録中止", message: "登録中止します。\nよろしいですか？", preferredStyle: .alert)
        // OKボタン
        let defaultAction: UIAlertAction = UIAlertAction(title: "OK", style: .default, handler:{
            // ボタンが押された時の処理を書く（クロージャ実装）
            (action: UIAlertAction!) -> Void in
            
            // ディレクトリを削除
            do {
                try FileManager.default.removeItem(atPath: self.soundRouteDir!.path)
                
                let routeDir = super.RouteDir.appendingPathComponent(self.routeName, isDirectory: true)
                try FileManager.default.removeItem(atPath: routeDir.path)
            } catch {
                // エラー
            }
            
            // 位置情報の取得終了
            super.clLoc?.LocationEnd()
            
            super.TopPage()
            
        })
        // キャンセルボタン
        let cancelAction: UIAlertAction = UIAlertAction(title: "キャンセル", style: .cancel, handler:{
            // ボタンが押された時の処理を書く（クロージャ実装）
            (action: UIAlertAction!) -> Void in
            
            // 位置情報の取得再開
            super.clLoc?.RecodeReStart()
        })
        alert.addAction(cancelAction)
        alert.addAction(defaultAction)
        
        // Alertを表示
        present(alert, animated: true, completion: nil)

    }
    /** ◆追跡モード切り替え */
    @IBAction func btnUserTrackingTouchDown(_ sender: UIButton) {
        if self.myMapView.userTrackingMode == .none {
            // ユーザが向いている方向を表示
            self.myMapView.setUserTrackingMode(.followWithHeading, animated: true)
        } else {
            self.myMapView.setUserTrackingMode(.none, animated: false)
        }
    }
    
    /**
     POIの登録
     - Parameter poiType : 登録種類
     */
    private func RegistPOI(_ poiType : PoiType) {
        // (POI登録待ち状態 or 録音中 or ルート数が0)ではない場合
        if !(self.IsRegistPoiStart || self.IsRecording || self.clLoc?.Routes.count == 0) {
            self.lblMessage.text = "位置情報を取得しています\nしばらくお待ち下さい"
            self.IsMessageHidden = false
            
            if self.speakTimer != nil {
                self.speakTimer?.Stop()
                self.speakTimer = nil
            }
            self.speakTimer = Timer.scheduledTimer(withTimeInterval: 5, repeats: true, block: {_ in
                super.Speak("位置取得中", false, false)
            })
        }
        self.IsRegistPoiStart = true
        self.registPOItype = poiType
        var pt = self.clLoc?.GetPoint()
        let pos = (self.clLoc?.Routes.count)! - 1
        // 取得精度

        // 取得地点の描画
        if self.speakTimer != nil {
            self.speakTimer?.Stop()
            self.speakTimer = nil
        }
        do {
            // 登録停止
            //                        super.clLoc?.RecodeStop()
            // 追加地点にタイプとファイル名を設定
            let fileName : String = (super.clLoc?.Routes[pos][Col.No.Val] as! Int).description + ".caf"
            super.clLoc?.Routes[pos][Col.POI.Val] = self.registPOItype.No
            super.clLoc?.Routes[pos][Col.Memo.Val] = fileName
            // 取得地点の描画
            let point = PointAnnotationEx()
            point.coordinate = CLLocationCoordinate2D(latitude: pt?[Col.Lat.Val] as! CLLocationDegrees, longitude: pt?[Col.Lon.Val] as! CLLocationDegrees)
            point.imageStretchWidth = 10
            point.imageStretchHeight = 10
            if self.registPOItype == .Danger {
                point.layerName = "DangerPoint"
                point.pinImage = #imageLiteral(resourceName: "DangerPoint")
                self.myMapView.addAnnotation(point)
            } else if self.registPOItype == .Location {
                point.layerName = "InfoPoint"
                point.pinImage = #imageLiteral(resourceName: "InfoPoint")
                self.myMapView.addAnnotation(point)
            } else if self.registPOItype == .Like {
                point.layerName = "FavoritePoint"
                point.pinImage = #imageLiteral(resourceName: "FavoritePoint")
                self.myMapView.addAnnotation(point)
            }
            // 追跡モードだと以下の処理を行っても反応しないので追跡モードではないときに実行する
            if self.myMapView.userTrackingMode == .none {
                // 登録地点を画面中央に表示する
                self.showUserLocationCamera(mapView: self.myMapView, coordinate: point.coordinate, heading: nil, altitude: 10)
            }
            // Soundフォルダに録音ファイルを出力する
            let filePath = self.soundRouteDir?.appendingPathComponent(fileName, isDirectory : false)
            addline()
            // 録音開始
            if self.IsRecording {
                super.clLoc?.RecodeStop()
            }
            try self.voiceRec.startRecording(filePath! as NSURL)
            
        } catch {
            print("登録失敗")
            
            // 位置情報の取得再開
            //                        super.clLoc?.RecodeReStart()
        }
        // 録音は位置取得後（LocationUpdateのLocationUpdate内で行う）
        
        
    }
    
    /** ◆ルート登録処理 */
    private func Complete() {
        
        if self.IsRecording {
            super.clLoc?.RecodeStop()
        }
        
        
        
        var zipname = "\(super.Setting.User as String)-\(self.routeName)"
        
        let zipdir = super.RouteDir.appendingPathComponent(zipname)
        
        do {
            // フォルダが存在するか
            try FileManager.default.contentsOfDirectory(atPath: zipdir.path)
        } catch {
            // フォルダが存在しなかったら作成する
            do {
                try FileManager.default.createDirectory(atPath: zipdir.path, withIntermediateDirectories: false, attributes: nil)
            } catch {
                super.Speak("フォルダの作成失敗。", false, true)
                return
            }
        }
        let clcalc = Calculation()
        if  0 !=  clcalc.LineLengeth((clLoc?.Routes.last)!,(clLoc?.pt)!) {
            var pt = clLoc?.pt
            pt?[Col.No.Val] = (clLoc?.Routes.count)! * 10
            clLoc?.Routes.append((pt)!)
        }
        let namepath = zipdir.appendingPathComponent("name.txt")
        let routepath = zipdir.appendingPathComponent("route.txt")
        let poipath = zipdir.appendingPathComponent("poi.txt")      // route.txtと同じ"No"がpoi.txtにあると登録に失敗する(Keyの重複)
        super.clLoc?.Routes.CreateTextFIle(path: routepath)
        registPOI.CreateTextFIle(path: poipath)
        let nameDIc: [NSString: Any] = ["NAME" : self.routeName]
        nameDIc.CreateTextFIle(path: namepath)
        zipname += ".zip"
        let zippath = super.RouteDir.appendingPathComponent(zipname)
        if !SSZipArchive.createZipFile(atPath: zippath.path, withContentsOfDirectory: zipdir.path, keepParentDirectory: true) {
            return
        }
        let phpurl = "https://mymapdemo.net/nedo/upload.php"
        let p : [String: String] = ["USER": super.Setting.User]
        super.clPHP?.UpLoad(zippath, phpurl, p, zipdir.path)
        super.clPHP?.UploadComplete = { s in
            if s == "0" {
                super.Speak("ルート登録完了", false, false)
                
                // 位置情報の取得終了
                super.clLoc?.LocationEnd()
                
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + .seconds(1), execute: {
                    super.TopPage()
                })
                
            } else {
                super.Speak("ルート登録失敗", false, true)

                // 位置情報の取得再開
                super.clLoc?.RecodeReStart()
            }
        }
    }
    
    /**
     現在地を表示する
     - Parameter mapView: マップビュー
     - Parameter coordinate: 現在地の座標
     */
    func showUserLocation(mapView: MKMapView, coordinate: CLLocationCoordinate2D ) {
        let longitude = coordinate.longitude
        let latitude = coordinate.latitude
        
        var cr: MKCoordinateRegion! = mapView.region
        cr.center = CLLocationCoordinate2DMake(latitude, longitude)
        cr.span = MKCoordinateSpanMake(0.001, 0.001)      // 拡大率(小さい方が拡大)
        mapView.setRegion(cr, animated: false)
    }
    
    /**
     現在地を表示する
     - Parameter mapView: マップビュー
     - Parameter coordinate: 現在地の座標
     - Parameter heading : 方位
     - Parameter altitude : 標高（縮尺みたいなもの）
     */
    func showUserLocationCamera(mapView: MKMapView, coordinate: CLLocationCoordinate2D, heading: Double? = nil, altitude: Double? = nil){
        if mapView.userTrackingMode == .none {
            let cam = mapView.camera.copy() as! MKMapCamera
            cam.centerCoordinate = coordinate
            
            if heading != nil {
                cam.heading = heading!
            }
            
            if altitude != nil {
                cam.altitude = altitude!
            }
        
            mapView.setCamera(cam, animated: true)
        }
    }
    
    func addline() {
        var coordinates : [CLLocationCoordinate2D] = []
         var routes =  clLoc?.Routes
        if((routes?.count)!  > 1) {
            let pos = (routes?.count)! - 1
           
            let lon = routes? [pos-1][Col.Lon.Val]  as! Double
            let lat = routes? [pos-1][Col.Lat.Val]  as! Double
            let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: lon)
            coordinates.append(coordinate)
            let lon2 = routes? [pos][Col.Lon.Val]  as! Double
            let lat2 = routes? [pos][Col.Lat.Val]  as! Double
            let coordinate2 = CLLocationCoordinate2D(latitude: lat2, longitude: lon2)
            coordinates.append(coordinate2)
        }

        // mapViewにラインを追加
        if coordinates.count > 1 {
            let registRoutePolyLine = PolylineEx(coordinates: &coordinates, count: coordinates.count)
            registRoutePolyLine.id = "1"
            registRoutePolyLine.layerName = "registRouteLine"
            registRoutePolyLine.lineWidth = 2
            registRoutePolyLine.strokeColor = UIColor.red
            self.myMapView.add(registRoutePolyLine)
        }
    }
    
    
}

/** LocationManagerClassのプロトコル実装 */
extension RouteRegist : LocationDelegate {
    /**
     ◆住所取得後に実行されるメソッド
     - Parameter add :
     */
    func GetAddressEvent(_ add: String) {
        
    }
    /**
     ◆ログ更新時に実行されるメソッド
     - Parameter pt : 現在地
     */
    
    
    func GpsLoggerUpdate(_ pt: [String : Any]) {
       
        if self.IsStartRegist {
            //let pos = (self.clLoc?.Routes.count)! - 1
            // 取得精度
            if(oldpt != nil ) {
                self.movelen +=  clCalc.LineLengeth(oldpt!, pt)
            }
            /*
             [_stepCounter startStepCountingUpdatesToQueue:[NSOperationQueue mainQueue]
             updateOn:1
             withHandler:^(NSInteger numberOfSteps, NSDate *timestamp, NSError *error) {
             // 歩数が更新されるたびに呼ばれる
             }];
             */
            self.startPedometerUpdates()
            self.lblLocation.text = " 移動距離：\(round(self.movelen ))m \nGPS精度：\((pt[Col.Err.Val] as! Double))m \n間隔：\((self.Setting.RegistDistanceInterval ))m \n歩数:\(self.stepInt)"
            self.oldpt = pt;
            // 取得地点の描画

            let point = PointAnnotationEx()
            point.coordinate = CLLocationCoordinate2D(latitude: pt[Col.Lat.Val] as! CLLocationDegrees, longitude: pt[Col.Lon.Val] as! CLLocationDegrees)
            point.imageStretchWidth = 10
            point.imageStretchHeight = 10
            point.layerName = "FavoritePoint"
            point.pinImage = #imageLiteral(resourceName: "LocationPoint")
           
             t = t+1
            point.title = String(format: "%d", t)
            
            self.myMapView.addAnnotation(point)
                   addline()
            
        } else {
            // 取得精度
            self.lblLocation.text =  " GPS精度：\((pt[Col.Err.Val] as! Double))m \n"
                + " 間隔：\((self.Setting.RegistDistanceInterval ))m"
        }
    }
    

    /**
     ◆現在地取得後に実行されるメソッド
     - Parameter pt : 現在地
     - Parameter pos : ルートのインデックス
     - Parameter isRequest : リクエストして取得した現在地かどうか
     */
    func LocationUpdate(_ pt: [String : Any],_ pos:Int, _ isRequest : Bool) {
        if self.IsStartRegist {
           
            
        }
    }
}

/** VoiceRecorderClassのプロトコル実装 */
extension RouteRegist : VoiceRecorderDelegate {
    
    /**
     ◆録音開始前に実行されるメソッド
     - Parameter filePath : 出力先ファイルパス
     */
    func voiceRecorderStartRecording(_ filePath : NSURL?) {
        // 音を再生する
        self.btnCancel.isEnabled = false
        self.btnRegist.isEnabled = false
        self.voiceRec.IsFinishPlayingEvent = true
        self.voiceRec.play(NSURL(fileURLWithPath: "/System/Library/Audio/UISounds/begin_record.caf"))
        self.voiceRec.PlayerFinishPlayingEvent = {
            DispatchQueue.main.async {
                try! self.voiceRec.setSessionCategory(.Recording)
                self.voiceRec.PlayerFinishPlayingEvent = nil
                self.lblMessage.text = "録音開始"
                self.IsMessageHidden = false
                self.IsRecording = true
            }
        }
    }
    /**
     ◆録音終了後に実行されるメソッド
     - Parameter filePath : 出力先ファイルパス
     */
    func voiceRecorderStopRecording(_ filePath : NSURL?) {
        self.IsRecording = false
        // 音を再生する
        self.voiceRec.IsFinishPlayingEvent = true
        self.voiceRec.play(NSURL(fileURLWithPath: "/System/Library/Audio/UISounds/end_record.caf"))
        self.voiceRec.PlayerFinishPlayingEvent = {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.btnCancel.isEnabled = true
                self.btnRegist.isEnabled = true
                self.voiceRec.PlayerFinishPlayingEvent = nil
                if self.IsStartRegist {
                    // ルート登録の再開
//                    super.clLoc?.RecodeReStart()
                    self.IsMessageHidden = true
                } else {
                    // ルート名登録後
                    self.lblMessage.text = "位置情報を取得しています\nしばらくお待ち下さい"
                    self.IsMessageHidden = false
                    if self.speakTimer != nil {
                        self.speakTimer?.Stop()
                        self.speakTimer = nil
                    }
                    self.speakTimer = Timer.scheduledTimer(withTimeInterval: 5, repeats: true, block: {_ in
                        super.Speak("位置取得中", false, false)
                    })
                    // GPS精度
                    super.clLoc?.getGpsState = true
                    super.clLoc?.GpsStateEvent = { (state : GpsState,err : Double ) in
                        switch state {
                        case GpsState.OK, GpsState.BadStart:
                            // 位置情報を取得した後にルート登録を開始する
                            self.IsStartRegist = true
                            self.IsMessageHidden = true
                            if self.speakTimer != nil {
                                self.speakTimer?.Stop()
                                self.speakTimer = nil
                            }
                            super.Speak(state == GpsState.OK ? "ルート登録開始" : "感度が低い状態で、ルート登録", false, false)
                            super.clLoc?.RecodeStart()
                            let pt =  super.clLoc?.GetPoint()
//                            self.lblLocation.text = " 移動距離：\(round(pt![Col.Len.Val] as! Double))m \nGPS精度：\((pt![Col.Err.Val] as! Double))m \n間隔：\((self.Setting.RegistDistanceInterval ))m"
                            self.lblLocation.text = " 移動距離：\(round(self.movelen ))m \nGPS精度：\((pt![Col.Err.Val] as! Double))m \n間隔：\((self.Setting.RegistDistanceInterval ))m \n歩数:\(self.stepInt)"
                            let point = PointAnnotationEx()
                            point.coordinate = CLLocationCoordinate2D(latitude: pt?[Col.Lat.Val] as! CLLocationDegrees, longitude: pt?[Col.Lon.Val] as! CLLocationDegrees)
                            point.imageStretchWidth = 10
                            point.imageStretchHeight = 10
                            point.layerName = "FavoritePoint"
                            point.pinImage = #imageLiteral(resourceName: "LocationPoint")

                            self.myMapView.addAnnotation(point)
                            break
                        default:
                            self.Speak("感度が低い", false, false)
                            break
                        }
                    }
                }
            }
        }
    }
    /**
     ◆録音中に実行されるメソッド
     - Parameter filePath : 出力先ファイルパス
     - Parameter recTime : 録音時間（秒）
     */
    func voiceRecorderRecording(_ filePath : NSURL?, _ recTime : Double) {
        DispatchQueue.main.async {
//            self.lblMessage.text = "録音中...(" + self.voiceRec.formatTimeString(d: self.voiceRec.nowRecTime) + ")"
            self.lblMessage.text = "録音中...(" + Int(recTime).description + "秒)"
        }
    }
}

/** MapViewDelegate */
extension RouteRegist : MKMapViewDelegate {
    
    /** ◆マップデータを取得する前 */
    func mapViewWillStartLoadingMap(_ mapView: MKMapView) {
        
    }
    /** ◆マップデータが取得された後 */
    func mapViewDidFinishLoadingMap(_ mapView: MKMapView) {
        
        // 現在地の青い印を表示する
        mapView.showsUserLocation = true
        // マップの中心地がユーザの現在地を追従するように設定
        //mapView.setUserTrackingMode(.follow, animated: true)
//        mapView.setUserTrackingMode(.followWithHeading, animated: true)     // ユーザが向いている方向を表示
        let cam = mapView.camera.copy()  as! MKMapCamera
        cam.altitude = 100;
        mapView.setCamera(cam, animated: true)
    }
    /** ◆マップデータの取得ができなかったとき */
    func mapViewDidFailLoadingMap(_ mapView: MKMapView, withError error: Error) {
        
    }
    
    
    /** ◆ユーザーの位置の追跡を開始したとき */
    func mapViewWillStartLocatingUser(_ mapView: MKMapView) {
        
    }
    /** ◆ユーザーの場所が更新された */
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let cam = mapView.camera.copy() as! MKMapCamera
        cam.centerCoordinate = userLocation.coordinate;
        mapView.setCamera(cam, animated: true)         /*        if let Routes = super.clLoc?.Routes {
            DispatchQueue.main.async {
               var coordinates : [CLLocationCoordinate2D] = []
                for i in 0..<Routes.count {
                    let lon = Routes[i][Col.Lon.Val]  as! Double
                    let lat = Routes[i][Col.Lat.Val]  as! Double
                    let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: lon)
                    coordinates.append(coordinate)
                }
                
                // 既存のラインを削除する
                for overlay in mapView.overlays {
                    if let polyline = overlay as? PolylineEx {
                        if polyline.layerName == "registRouteLine" {
                            mapView.remove(overlay)
                        }
                    }
                }
                
                // mapViewにラインを追加
                if coordinates.count > 1 {
                    let registRoutePolyLine = PolylineEx(coordinates: &coordinates, count: coordinates.count)
                    registRoutePolyLine.id = "1"
                    registRoutePolyLine.layerName = "registRouteLine"
                    registRoutePolyLine.lineWidth = 2
                    registRoutePolyLine.strokeColor = UIColor.red
                    self.myMapView.add(registRoutePolyLine)
                }
 
            }
         }
 */

    }
    /** ◆ユーザーの追跡モードが変更されたとき */
    func mapView(_ mapView: MKMapView, didChange mode: MKUserTrackingMode, animated: Bool) {
//        if mapView.userTrackingMode == .none {
//            // ユーザが向いている方向を表示
//            mapView.setUserTrackingMode(.followWithHeading, animated: true)
//        }
        
        if mapView.userTrackingMode == .none {
            // ユーザが向いている方向を表示
            //self.btnUserTracking.setImage(#imageLiteral(resourceName: "UserTrackingNone"), for: .normal)
        } else {
            //self.btnUserTracking.setImage(#imageLiteral(resourceName: "UserTrackingFollowWithHeading"), for: .normal)
        }
    }
    /** ◆ユーザーの位置の追跡を停止したとき */
    func mapViewDidStopLocatingUser(_ mapView: MKMapView) {

    }
    
    
    /** ◆アノテーションビューを返すメソッド */
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        // 現在位置の点滅がピンにならないように、アノテーションがUserLocationの場合は何もしないようにする。
        if annotation is MKUserLocation {
            return nil
        }
        
        if let pointEx = annotation as? PointAnnotationEx {
            
            // ピンの画像を設定する
            if (pointEx.pinColor != nil) {
                // 色が設定されている場合
                let annView = MKPinAnnotationView()
                annView.annotation = annotation
                
                if #available(iOS 9.0, *) {
                    // iOS 9以降から「赤」「緑」「紫」以外の色が設定できる
                    
                    if pointEx.isEmphasisPinColor && pointEx.emphasisPinColor != nil {
                        annView.pinTintColor = pointEx.emphasisPinColor
                    } else {
                        annView.pinTintColor = pointEx.pinColor
                    }
                    
                } else {
                    // Fallback on earlier versions
                }
                annView.canShowCallout = false
                
                return annView
                
            } else if (pointEx.pinImage != nil) {
                
                let image = pointEx.pinImage
                if (image != nil){
                    // 取得した画像の縦・横サイズを取得する
                    let imageW = image?.size.width
                    let imageH = image?.size.height
                    
                    // 画像が設定されている場合
                    let annView = MKAnnotationView()
                    annView.canShowCallout = false
                    
                    if pointEx.isStretch == true {
                        // リサイズする倍率
                        let scale = imageW! < imageH! ? pointEx.imageStretchHeight / imageH!  : pointEx.imageStretchWidth / imageW!
                        
                        // 比率に合わせてリサイズする
                        let resizedSize = CGSize(width: imageW! * scale, height: imageH! * scale)
                        UIGraphicsBeginImageContext(resizedSize)
                        image?.draw(in: CGRect(x: 0, y: 0, width: resizedSize.width, height: resizedSize.height))
                        let resizedImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
                        UIGraphicsEndImageContext()
                        
                        annView.image = resizedImage
                    } else {
                        // そのままの画像を設定
                        annView.image = pointEx.pinImage
                    }
                    
                    return annView
                }
                
            }
        }
        
        // 色も画像も設定されていない場合
        let annView = MKPinAnnotationView()
        annView.annotation = annotation
        // 吹き出しを表示不可にする
        annView.canShowCallout = false
        return annView
    }
    /** ◆アノテーションを選択したとき */
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        
    }
    
    
    /** ◆addOverlayした際に呼ばれるデリゲートメソッド */
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        if overlay is MKPolyline {
            let lineRender = MKPolylineRenderer(overlay: overlay)
            
            // ラインの設定
            if let polyline = overlay as? PolylineEx {
                // 直線の幅を設定する。
                if polyline.lineWidth != nil {
                    lineRender.lineWidth = polyline.lineWidth!
                } else {
                    lineRender.lineWidth = 1
                }
                
                //直線の色を設定する。
                if polyline.strokeColor != nil {
                    lineRender.strokeColor = polyline.strokeColor
                } else {
                    lineRender.strokeColor = UIColor.blue
                }
            } else {
                // 線の太さを指定.
                lineRender.lineWidth = 2

                // 線の色を指定.
                lineRender.strokeColor = UIColor.red
            }
            
            return lineRender
            
        }
        return MKOverlayRenderer(overlay: overlay)
    }
    /** ◆地図にレンダラが追加された際に呼ばれるデリゲートメソッド */
    func mapView(_ mapView: MKMapView, didAdd renderers: [MKOverlayRenderer]) {
        // 再描画が必要だとシステム側に通知（再描画のタイミングはシステム側が決める）
        self.myMapView.setNeedsDisplay()
    }
    
}

