//
//  SettingClass.swift
//  MyMap
//
//  Created by developer on 2017/03/03.
//  Copyright © 2017年 njk. All rights reserved.
//

import Foundation

class SettingClass : NSObject {
    
    var User : String! = "999999"       //
    
    
//    var RouteOut : Double  = 5          //

    //◆共通設定
    var VoiceCommand :  (ind :  Int,value :  Bool) = (0, true)   // 音声コマンド
    var SpeakSpeed : (ind :  Int,value :  Float) = (1, 0.55)        //話す速さ
    
    //◆検索設定
    var SearchDistance : (ind : Int, value : Int) = (1, 200)        // 距離(m)
    var SearchOrder : (ind : Int, value : Int) = (0, 1)                // 並び
    
    //◆GPS設定
    var GpsAccuracy : (ind : Int, value : Double) = (3, 10)             //GPS精度(m)
    var GpsTimePrecision : (ind : Int, value : Double) = (1, 0.5)       // GPS時間精度(秒)
    var GpsMoveSpeed : (ind : Int, value : Double) = (1, 10)            // 移動速度(km)
    
    //◆案内設定
    var GuidePoiDistance : (ind : Int, value : Double) = (1, 10)            // POI案内距離(m)
    var GuideFavoriteDistance : (ind : Int, value : Double) = (1 , 10)   // お気に入り案内距離(m)
    var GuideDirectionNotification : (ind : Int, value : Int) = (0, 1)      // 方位通知方法
    
    var LostSearchDistance: Int = 15
    var settingStartDistance: Int = 15
    var settingEndDistance: Int = 15
    var settingMissDistance: Int = 15
    var settingTime: Int = 3
    var settingTimeLocation: Int = 0
    var settingVoiceSelect: Int = 0
    var settingPeoPleSelect: Int = 0
    var settingTenMSelect: Int = 0
    var settingVibrationSelect: Int = 0
    //◆迷子設定
    var LostSmallDistance: Int     = 5       // 小迷子判定距離(m)
    var LostMiddleDistance: Int = 8         // 中迷子判定距離(m)
    var LostFunction: Int = 10                // 大迷子機能
    var LostVoiceInterval : (ind : Int, value : Int) = (1, 60)                  // 大迷子中の音声間隔(秒)
    var IsRouteoutVoice : Int = 0
    //◆ルート登録
    var RegistDistanceInterval: Int    =  10   // 登録間隔(m)
    var RegistRecordingRestriction: (ind : Int, value : Bool) = (0, true)   // 録音制限
    var RegistRecordingTime: (ind : Int, value : Int) = (4, 8)           // 録音時間(秒)
    
    private  let userDefaults = UserDefaults.standard
    
    override init(){
        super.init()
        // 保存された設定値の読み込み
        load()
    }
    
    /**
     ◆ロード
     */
    func load() {
        // --- 共通設定 ---
        // 音声コマンド
        if let val = userDefaults.object(forKey: "VoiceCommand")   {
            VoiceCommand = ToTuple(val as! [AnyObject])!
        }
        // 音声案内の速度
        if let val = userDefaults.object(forKey: "SpeakSpeed")   {
            SpeakSpeed = ToTuple(val as! [AnyObject])!
        }
        
        // --- 検索設定 ---
        // 距離
        if let val = userDefaults.object(forKey: "SearchDistance")   {
            SearchDistance = ToTuple(val as! [AnyObject])!
        }
        // 並び
        if let val = userDefaults.object(forKey: "SearchOrder")   {
            SearchOrder = ToTuple(val as! [AnyObject])!
        }
        
        // --- GPS設定 ---
        // GPS精度
        if let val = userDefaults.object(forKey: "GpsAccuracy")   {
            GpsAccuracy = ToTuple(val as! [AnyObject])!
        }
        // GPS時間精度
        if let val = userDefaults.object(forKey: "GpsTimePrecision")   {
            GpsTimePrecision = ToTuple(val as! [AnyObject])!
        }
        // 移動速度
        if let val = userDefaults.object(forKey: "GpsMoveSpeed")   {
            GpsMoveSpeed = ToTuple(val as! [AnyObject])!
        }
        
        // --- 案内設定 ---
        // POI案内距離
        if let val = userDefaults.object(forKey: "GuidePoiDistance")   {
            GuidePoiDistance = ToTuple(val as! [AnyObject])!
        }
        // お気に入り案内距離
        if let val = userDefaults.object(forKey: "GuideFavoriteDistance")   {
            GuideFavoriteDistance = ToTuple(val as! [AnyObject])!
        }
        // 方位通知方法
        if let val = userDefaults.object(forKey: "GuideDirectionNotification")   {
            GuideDirectionNotification = ToTuple(val as! [AnyObject])!
        }
        
        // --- 迷子設定 ---
        // 小迷子判定距離
         if (userDefaults.object(forKey: "LostSmallDistance") != nil) {
            LostSmallDistance = userDefaults.integer(forKey: "LostSmallDistance")
        }
        //new
           
        if (userDefaults.object(forKey: "LostSearchDistance") != nil) {
            LostSearchDistance = userDefaults.integer(forKey: "LostSearchDistance")
        }
        if (userDefaults.object(forKey: "settingStartDistance") != nil) {
            settingStartDistance = userDefaults.integer(forKey: "settingStartDistance")
        }
        if (userDefaults.object(forKey: "settingEndDistance") != nil) {
            settingEndDistance = userDefaults.integer(forKey: "settingEndDistance")
        }
        
        if (userDefaults.object(forKey: "settingVoiceSelect") != nil) {
            settingVoiceSelect = userDefaults.integer(forKey: "settingVoiceSelect")
        }
        
        if (userDefaults.object(forKey: "settingPeoPleSelect") != nil) {
            settingPeoPleSelect = userDefaults.integer(forKey: "settingPeoPleSelect")
        }
        
        
        if (userDefaults.object(forKey: "settingMissDistance") != nil) {
            settingMissDistance = userDefaults.integer(forKey: "settingMissDistance")
        }
        if (userDefaults.object(forKey: "settingTime") != nil) {
            settingTime = userDefaults.integer(forKey: "settingTime")
        }
        
     
        if (userDefaults.object(forKey: "settingTenMSelect") != nil) {
            settingTenMSelect = userDefaults.integer(forKey: "settingTenMSelect")
        }
        if (userDefaults.object(forKey: "settingVibrationSelect") != nil) {
            settingVibrationSelect = userDefaults.integer(forKey: "settingVibrationSelect")
        }
        
        // 中迷子判定距離
        if (userDefaults.object(forKey: "LostMiddleDistance") != nil) {
            LostMiddleDistance = userDefaults.integer(forKey: "LostMiddleDistance")
        }
        if (userDefaults.object(forKey: "missTimeLocation") != nil) {
            settingTimeLocation = userDefaults.integer(forKey: "missTimeLocation")
        }
        // 大迷子機能
        if (userDefaults.object(forKey: "LostFunction") != nil) {
            LostFunction = userDefaults.integer(forKey: "LostFunction")
        }
        // 大迷子中の音声間隔
        if let val = userDefaults.object(forKey: "LostVoiceInterval")   {
            LostVoiceInterval = ToTuple(val as! [AnyObject])!
        }
        
        if (userDefaults.object(forKey: "IsRouteoutVoice") != nil) {
            IsRouteoutVoice = userDefaults.integer(forKey: "IsRouteoutVoice")
        }
        // --- ルート登録設定 --
        if (userDefaults.object(forKey: "RegistDistanceInterval") != nil) {
            RegistDistanceInterval = Int(userDefaults.double(forKey: "RegistDistanceInterval"))
        }
//        if let val = userDefaults.object(forKey: "RegistRecordingRestriction")   {
//            RegistRecordingRestriction = ToTuple(val as! [AnyObject])!
//        }
//        if let val = userDefaults.object(forKey: "RegistRecordingTime")   {
//            RegistRecordingTime = ToTuple(val as! [AnyObject])!
//        }
    }
    
    /**
     ◆保存
     - Parameter value : 値 (ind, value)
     - Parameter key : キー
     */
    func Save<T, U>(_ value : (T, U), _ key : String){
        let dic : [AnyObject ] = [value.0 as AnyObject , value.1 as AnyObject]
        userDefaults.set(dic, forKey:  key)
        userDefaults.synchronize()
    }
    func Save<T>(_ value : T, _ key : String){
      
        userDefaults.set(value, forKey:  key)
        userDefaults.synchronize()
    }    /**
     ◆タプルの型変換
     - Parameter value : 値
     - Returns : 変換後の値
     */
    func ToTuple<T>(_ value : [AnyObject]) -> (ind : Int, value : T)? {
        if value.count >= 2 {
            if (value[0] is Int && value[1] is T) {
                return (value[0] as! Int, value[1] as! T)
            }
        }
        return nil
    }
    
    /**
     ◆初期値を設定する
     */
    func InitValueSetting(){
        //◆共通設定
        VoiceCommand = (0, true)                   // 音声コマンド
        SpeakSpeed = (1, 0.55)                       //話す速さ
        
        //◆検索設定
        SearchDistance = (1, 200)                  // 距離(m)
        SearchOrder = (0, 1)                          // 並び
        
        //◆GPS設定
        GpsAccuracy = (3, 10)                       //GPS精度(m)
        GpsTimePrecision = (1, 0.5)               // GPS時間精度(秒)
        GpsMoveSpeed = (1, 10)                  // 移動速度(km)
        
        //◆案内設定
        GuidePoiDistance = (1, 10)                 // POI案内距離(m)
        GuideFavoriteDistance = (1 , 10)        // お気に入り案内距離(m)
        GuideDirectionNotification = (0, 1)     // 方位通知方法
        
        //◆迷子設定
        LostSmallDistance = 5             // 小迷子判定距離(m)
        LostMiddleDistance = 8            // 中迷子判定距離(m)
        LostFunction = 1                    // 大迷子機能
        LostVoiceInterval = (1, 60)                // 大迷子中の音声間隔(秒)
        
        //◆ルート登録設定
        RegistDistanceInterval = 10         // 登録間隔(m)
        RegistRecordingRestriction = (0, true)  // 録音制限
        RegistRecordingTime = (1, 5)            // 録音時間(秒)
    }
    
}
