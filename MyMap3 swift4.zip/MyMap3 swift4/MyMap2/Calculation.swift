//
//  Calculation.swift
//  My地図アプリ
//
//  Created by developer on 2017/02/16.
//  Copyright © 2017年 njk. All rights reserved.
//

import Foundation
import CoreLocation
class  Calculation {
    
    /**
     ◆線上に点があるか判定
     - Parameter pt : 点
     - Parameter stpt : 線の始点
     - Parameter edpt : 線の終点
     - Returns : 線上に点があれば true
     */
    func PointOnline(_ pt : [String : Any],_ stpt : [String : Any] ,_ edpt : [String : Any]) -> Bool {
        let stx = stpt[Col.Lat.Val]  as! Double
        let sty = stpt[Col.Lon.Val]   as! Double
        let edx = edpt[Col.Lat.Val]  as! Double
        let edy = edpt[Col.Lon.Val]  as! Double
        let x = pt[Col.Lat.Val]  as! Double
        let y = pt[Col.Lon.Val]  as! Double
        //線分： 始点P0(x0, y0)、終点P1(x1, y1)
        //点　 ：P(x2, y2)
        let abx = edx - stx
        let aby = edy - sty
        let apx = x - stx
        let apy = y - sty
        //線分の長さ L1 = sqrt( (x1-x0)^2 + (y1-y0)^2 )
        let a1 = sqrt((abx * abx)  + (aby * aby))
        //線分の始点から点までの長さ L2 = sqrt( (x2-x0)^2 + (y2-y0)^2 )
        let a2  = sqrt((apx * apx) + (apy  * apy))
        //(x1-x0)*(x2-x0) + (y1-y0)*(y2-y0) が L1*L2 に等しく、かつL1≧L2の時衝突している
        let a3  = abx * apx + aby * apy
        let a4 = a1 * a2
        let a5 = a3 - a4
        //print("当たり判定\(a5)")
        if  (a5 == 0  && a1 >= a2) {
             return true
        }
        return false
   
        
        //let l1 = sqrt(abx * abx + aby * aby)
      //  let l2 = sqrt(apx * apx + apy * apy)
      //  let l3 = abx * apx + aby * apy
       // if ((l3 - 0.1 < l1 * l2 && l3 + 0.1 > l1 * l2) && l1 >= l2)
       // {
          //  return true
       // }
        //return false
    }

    /**
     ◆２点線上と現在点の距離
     - Parameter : 点
     - Parameter : 線の始点
     - Parameter : 線の終点
     - Returns : (現在点の距離, 線上に点があれば true)
     */
    func GetNearPoint(_ pt : [String : Any],_ stpt : [String : Any],_ edpt : [String : Any]) -> (pt : [String : Any] , isOnLine : Bool,len : Double){
       //2点線と点の最近点を取得
        let stx = stpt[Col.Lat.Val]  as! Double
        let sty = stpt[Col.Lon.Val]   as! Double
        let edx = edpt[Col.Lat.Val]  as! Double
        let edy = edpt[Col.Lon.Val]  as! Double
        let x = pt[Col.Lat.Val]  as! Double
        let y = pt[Col.Lon.Val]  as! Double
        let abx = edx - stx
        let aby = edy - sty
        let apx = x - stx
        let apy = y - sty
        //線の長さ
        //let ablen : Double = sqrt(abx * abx + aby * aby)
        //始点から点の長さ
        //let aplen = sqrt(apx * apx + apy * apy)
        //点から終点の長さ
        //let eplen = sqrt(((x - edx) * (x - edx) + (y - edy) * (y - edy)))
        if (abx == 0 && aby == 0) {
            return (stpt,false,0 )
        }

        let r2 : Double = abx * abx + aby * aby;
        let t :  Double = (abx * apx + aby * apy ) / r2;

    //    print("t:\(t)")
        if (t < 0) {
            let stlen = LineLengeth(stpt,pt)
            return (stpt,false,stlen )
        }
        if (t > 0.99) {
            let stlen = LineLengeth(pt,edpt)
            return (edpt,false,stlen )
        }
        let cx = (1 - t) * stx + t * edx;
        let cy = (1 - t) * sty + t * edy;
        var npt : [String : Any] = [:]
        npt[Col.Lat.Val] = cx
        npt[Col.Lon.Val] = cy
        let stlen = LineLengeth(npt,pt)
        return (npt,true,stlen )
        
        
          //   let ret =  PointOnline(npt,stpt,edpt)
        
/*   if ret {
            let stlen = LineLengeth(npt,pt)
            return (npt,ret,stlen)
        } else {
            let stlen = LineLengeth(stpt,pt)
            let edlen = LineLengeth(edpt,pt)
            if stlen < edlen {
                return (stpt,false,stlen )
            } else {
                return (edpt,false,edlen )
            }
        }*/
    }
    
    func GetNearPoint2(_ pt : [String : Any],_ stpt : [String : Any],_ edpt : [String : Any]) -> (pt : [String : Any] , isOnLine : Bool,len : Double){
      
        let stx = stpt[Col.Lat.Val]  as! Double
        let sty = stpt[Col.Lon.Val]   as! Double
        let edx = edpt[Col.Lat.Val]  as! Double
        let edy = edpt[Col.Lon.Val]  as! Double
        let x = pt[Col.Lat.Val]  as! Double
        let y = pt[Col.Lon.Val]  as! Double
        let abx = edx - stx
        let aby = edy - sty
        let apx = x - stx
        let apy = y - sty
        let len = pow( ( abx * abx ) + ( aby * aby ), 0.5 )
        let nabx = abx / len;
        let naby = aby / len;
        let dist_AX = nabx * apx + naby * apy
        let retx = stx + ( nabx * dist_AX );
        let rety = sty + ( naby * dist_AX );
        var npt : [String : Any] = [:]
        npt[Col.Lat.Val] = retx
        npt[Col.Lon.Val] = rety
        let stlen = LineLengeth(npt,pt)
        
        let ret =  PointOnline(npt,stpt,edpt)
        
        if ret {
             return (npt,ret,stlen)
        } else {
            let stlen = LineLengeth(stpt,pt)
            let edlen = LineLengeth(edpt,pt)
            if stlen < edlen {
                return (stpt,false,stlen )
            } else {
                return (edpt,false,edlen )
            }
        }
    }
    
    
    
    /**
     ◆2点距離を取得する
     - Parameter stpt : 1点目
     - Parameter edpt : 2点目
     - Returns : ２点間距離
     */
    func LineLengeth(_ stpt : [String : Any],_ edpt : [String : Any]) -> Double{
        let lon = stpt[Col.Lon.Val]  as! Double
        let lat = stpt[Col.Lat.Val]  as! Double
        let stloc = CLLocation(latitude: lat, longitude: lon)
       
        let edlon = edpt[Col.Lon.Val]  as! Double
        let edlat = edpt[Col.Lat.Val]  as! Double
        let edloc  : CLLocation = CLLocation(latitude: edlat, longitude: edlon)
        return stloc.distance(from: edloc) as Double
    }
    
    /**
     ◆２点間角度を取得する
     - Parameter stpt : 1点目
     - Parameter edpt : 2点目
     - Parameter degree : 角度
     - Returns : ２点間角度
     */
    func Direction(_ stpt: [String : Any]?,_ edpt : [String : Any],_ degree : Double = 0) -> Double{
        
        if(stpt == nil) {
            return degree
        }
        
        let lat1 : Double = stpt?[Col.Lat.Val]  as! Double
        let lng1 : Double = stpt?[Col.Lon.Val]   as! Double
        let lat2 : Double = edpt[Col.Lat.Val]  as! Double
        let lng2 : Double = edpt[Col.Lon.Val]  as! Double
        
        
      
        
        let Y = cos(lng2 * Double.pi / 180) * sin(lat2 * Double.pi / 180 - lat1 * Double.pi / 180);
        let X = cos(lng1 * Double.pi / 180) * sin(lng2 * Double.pi / 180) - sin(lng1 * Double.pi / 180) * cos(lng2 * Double.pi / 180) * cos(lat2 * Double.pi / 180 - lat1 * Double.pi / 180);
        var dirE0 = 180 * atan2(Y, X) / Double.pi // 東向きが０度の方向
        if (dirE0 < 0) {
            dirE0 = dirE0 + 360; //0～360 にする。
        }
        //let dirN0 = (dirE0 + 90) % 360; //(dirE0+90)÷360の余りを出力 北向きが０度の方向
         let dirN0 =  (dirE0 + 90).truncatingRemainder(dividingBy: 360)
        return dirN0
        
//        let stx : Double = stpt?[Col.Lat.Val]  as! Double
//        let sty : Double = stpt?[Col.Lon.Val]   as! Double
//        let edx : Double = edpt[Col.Lat.Val]  as! Double
//        let edy : Double = edpt[Col.Lon.Val]  as! Double
//        let radian : Double = atan2(edy - sty,edx - stx);
//        var degree : Double = radian * 180.0 / Double.pi
//        if degree < 0 {
//            degree =  degree + 360
//        }
//        return  degree
        
    }
    /**
     ◆ルート角度
     - Parameter pt : 地点
     - Parameter stpt : ルート始点
     - Parameter edpt : ルート終点
     - Returns : (dic : 方位（時計）, rdegree : ルート角度, ndegree : 最近点角度, nlen : 最近点距離(切り上げ), elen : ルート距離(切り上げ))
     */
    func RouteDirection(_ pt: [String : Any],_ stpt: [String : Any],_ edpt: [String : Any]) ->
        (dic:String ,rdegee:Double,ndegee:Double,nlen:Double,elen:Double,online : Bool,npt: [String : Any]){
        
        let rdegree : Double = Direction(stpt,  edpt )          // ルート角度
        let npt =  GetNearPoint(pt, stpt, edpt)                    // 最近点
        let ndegree : Double = Direction(pt,  npt.pt)           // 最近点角度
  
        let nearlen : Double = LineLengeth(pt, npt.pt ).rounded(.up)
        let endlen  : Double = LineLengeth(pt,edpt).rounded(.up)
        return  (DirectionTime(Int(ndegree)),rdegree,ndegree ,nearlen,endlen,npt.isOnLine,npt.pt)
    }
    
    /**
     ◆現在点が線のどちら側にあるか
     - Parameter pt : 点
     - Parameter stpt : 線の始点
     - Parameter edpt : 線の終点
     - Returns : 左 = 1 / 右 = -1 / 線上 = 0
     */
    func Side(_ pt: [String : Any],_ stpt: [String : Any],_ edpt: [String : Any]) -> Int{
        let stx = stpt[Col.Lat.Val]  as! Double
        let sty = stpt[Col.Lon.Val]   as! Double
        let edx = edpt[Col.Lat.Val]  as! Double
        let edy = edpt[Col.Lon.Val]  as! Double
        let x = pt[Col.Lat.Val]  as! Double
        let y = pt[Col.Lon.Val]  as! Double
        
        // 有向線分 (p2,p1), (p2,p3) の外積の z 成分を求める
        let n  = x * (sty - edy) + stx * (edy - y) + edx * (y - sty);
        if  ( n >  0 ) {
            return  1 //左
        } else if ( n < 0 )  {
            return -1
        } else {
            return  0;
        }
    }
    
    /**
     ◆方位（時計）： クロックポジションは移動しないものに対しては真北が12時となるが、移動するものに対しては進行方向が12時となる。
     ここでは、視覚障害者を対象としているので12時は進行方向となる。
     - Parameter degree : 角度(0~360)
     */
    func DirectionTime(_ degree : Int) -> String {
        if(degree > 355 && degree <= 360 || degree > 0 && degree <= 15 ) {
            return "12時"
        } else if(degree > 15 && degree <= 45) {
            return "１時"
        } else if(degree > 45 && degree <= 75) {
            return "2時"
        }else if(degree > 75 && degree <= 105) {
            return "3時"
        }else if(degree > 105 && degree <= 135) {
            return "4時"
        }else if(degree > 135 && degree <= 175) {
            return "5時"
        }else if(degree > 175 && degree <= 205) {
            return "6時"
        }else if(degree > 205 && degree <= 235) {
            return "7時"
        }else if(degree > 235 && degree <= 265) {
            return "8時"
        }else if(degree > 265 && degree <= 295) {
            return "9時"
        }else if(degree > 295 && degree <= 325) {
            return "10時"
        }else if(degree > 325 && degree <= 355) {
            return "11時"
        }
        return ""
    }
    /**
     ◆方位（東西南北）
     - Parameter dic : 角度(0~360)
     - Returns : 方位（東西南北）
     */
    func dicToStr2(dic : Double) -> String {
        if(dic > 337.5 && dic <= 360 || dic > 0 && dic <= 22.5 ) {
            return "12時"
        } else if(dic > 22.5 && dic <= 47.5) {
            return "1時"
        }
        else if(dic > 42.5 && dic <= 67.5) {
            return "2時"
        }
        else if(dic > 67.5 && dic <= 112.5) {
            return "3時"
        }
        else if(dic > 112.5 && dic <= 132.5) {
            return "4時"
        }
        else if(dic > 132.5 && dic <= 157.5) {
            return "5時"
        }else if(dic > 157.5 && dic <= 202.5) {
            return "6時"
        }else if(dic > 202.5 && dic <= 227.5) {
            return "7時"
        }
        else if(dic > 227.5 && dic <= 247.5) {
            return "8時"
        }
        else if(dic > 247.5 && dic <= 292.5) {
            return "9時"
        }else if(dic > 292.5 && dic <= 317.5) {
            return "10時"
        }
        else if(dic > 317.5 && dic <= 337.5) {
            return "11時"
        }
        return ""
    }
    /**
     ◆方位（前後左右）
     - Parameter dic : 角度(0~360)
     - Returns : 方位（前後左右）
     */
    func DirectionAllSides(dic : Double) -> String {
        if(dic > 337.5 && dic <= 360 || dic > 0 && dic <= 22.5 ) {
            return "前"
        } else if(dic > 22.5 && dic <= 67.5) {
            return "斜め右"
        } else if(dic > 67.5 && dic <= 112.5) {
            return "右"
        }else if(dic > 112.5 && dic <= 157.5) {
            return "右後"
        }else if(dic > 157.5 && dic <= 202.5) {
            return "後"
        }else if(dic > 202.5 && dic <= 247.5) {
            return "左後"
        }else if(dic > 247.5 && dic <= 292.5) {
            return "左"
        }else if(dic > 292.5 && dic <= 337.5) {
            return "斜め左"
        }
        return ""
    }
}
