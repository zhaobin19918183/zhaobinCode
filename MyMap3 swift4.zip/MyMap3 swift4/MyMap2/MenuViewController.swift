//
//  ViewController.swift
//  MyMap2
//
//  Created by developer on 2017/04/14.
//  Copyright © 2017年 njk. All rights reserved.
//

import UIKit
import Photos

class MenuViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//            IwatchSessionUtil.shareManager.sendMessageToWatch(key: "MyMap2", value: "MyMap2")
        self.Setting = SettingClass()

        let docDir = URL( string: NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0])
        TempDir = docDir?.appendingPathComponent("Temp", isDirectory: true)
        SoundDir = TempDir?.appendingPathComponent("Sound", isDirectory : true)
        RouteDir = TempDir?.appendingPathComponent("Route", isDirectory : true)
        GuideDir = docDir?.appendingPathComponent("Guide", isDirectory : true)
        
        // Tempフォルダを削除(テスト用)
//        if FileManager.default.fileExists(atPath: (TempDir?.path)!) {
//            try! FileManager.default.removeItem(atPath: (TempDir?.path)!)
//        }
        
        // このアプリに必要なフォルダを作成する
        if !CreateMyMapAppDir() {
            print("フォルダの作成に失敗しました。")
        }
       
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    //MARK: go to destination
    @IBAction func GoToDestination(_ sender: UIButton)
    {
        
        
        
    }
    
    @IBAction func beforButtonAction(_ sender: UIButton) {
    }
    @IBAction func popToSelectViewAction(_ sender: UIButton)
    {

        let notificationName = Notification.Name(rawValue: "RouteSelectViewController")
        NotificationCenter.default.post(name: notificationName, object: self,
                                        userInfo: ["valueSelect":"SelectViewController"])
        
    }
    
    /**
     このアプリに必要なフォルダを作成する
     */
    private func CreateMyMapAppDir() -> Bool {
        do {
            // Tempフォルダを作成する
            try FileManager.default.createDirectory(atPath: (TempDir?.path)!, withIntermediateDirectories: true, attributes: nil)
            
            // Soundフォルダを作成する
            try FileManager.default.createDirectory(atPath: (SoundDir?.path)!, withIntermediateDirectories: true, attributes: nil)
            
            // Routeフォルダを作成する
            try FileManager.default.createDirectory(atPath: (RouteDir?.path)!, withIntermediateDirectories: true, attributes: nil)
            try FileManager.default.createDirectory(atPath: (GuideDir?.path)!, withIntermediateDirectories: true, attributes: nil)
            
        } catch {
            print("フォルダー作成失敗")
            return false
        }
        return true
    }
    
    
}

