//
//  PolylineEx.swift
//  MyMap2
//
//  Created by 栄養 メイト on 2017/04/18.
//  Copyright © 2017年 njk. All rights reserved.
//

import UIKit
import MapKit

/** MKPolylineの拡張クラス */
class PolylineEx: MKPolyline {
    
    /** レイヤ名・グループ名（識別用） */
    var layerName: String = "polyline"
    /** ID */
    var id: String?
    /** プロパティ */
    var properties: NSDictionary?
    
    /** 直線の幅を設定する。 */
    var lineWidth: CGFloat?
    /** 直線の色を設定する */
    var strokeColor: UIColor?
}
