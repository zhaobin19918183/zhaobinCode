//
//  SelectEditRouteViewController.swift
//  MyMap2
//
//  Created by developer on 2017/04/25.
//  Copyright © 2017年 njk. All rights reserved.
//

import UIKit

class EditRouteSelectViewController:  BaseViewController {
    
    @IBOutlet weak var RouteTable: UITableView!
    // private  var clLoc = LocationManagerClass()
    let clSound = SoundVibrateClass()
    private var routeJson :String!
    private var allRoutes : [[String:Any]] = []
    private var useRoutes:[[String:Any]] = []
    private var mode : SegueIds!
    @IBOutlet weak var btnStart: UIButton!
    
    
    var searchRoutes:[[String:Any]] = []
    var selectRoute : [String:Any]!
    var previewingViewController: UIViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        clLoc?.initLocation(self.Setting,0)
        if  (clLoc?.IsDenied)! {
            self.Speak("位置情報の取得が許可しないに設定されています、許可に変更してから実行してください")
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                self.TopPage()
            }
            return
        }
        
        self.clLoc?.StartLocation()
        self.clPHP?.JsonData = { (json : NSString?,err : Int) in
            if err != 0 || json == nil {
                // エラーまたはデータがない場合
                self.Speak("ルート取得失敗")
                return
            }
            
            if !self.getRoutes(json!) {
                self.Speak("ルート登録されていません")
                return
            }
        }
        self.clLoc?.getStartLocation = true
        self.clLoc?.StartLocationEvent = { pt  in
            let x = pt[Col.Lat.Val]  as! Double
            let y = pt[Col.Lon.Val]  as! Double
            let parameters: [String : Any] = ["USER":self.Setting.User,"AREA":self.Setting.SearchDistance.value,"LAT": x,"LON":y, "SORT": self.Setting.SearchOrder.ind]
            let phppath = "https://mymapdemo.net/nedo/search.php"
            self.clPHP?.GetData(phppath, parameters,.JSON)
            self.clLoc?.LocationEnd()
        }
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.doubleTapped))
        tap.numberOfTapsRequired = 2
        self.RouteTable.addGestureRecognizer(tap)
 
    }
    
    @objc func doubleTapped() {
        print(selectRoute)
        performSegue(withIdentifier: SegueIds.RouteGuide.rawValue,sender: nil);
        
    }
    
    @IBAction func btnTouchDown(_ sender: Any) {
        if  searchRoutes.count == 0 {
            Speak("ルートなし。メニュー画面へ戻ります")
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                self.TopPage()
            }
            return
        }
        self.selectRoute =  searchRoutes[0]
        routesoundplay()
        performSegue(withIdentifier: SegueIds.RouteGuide.rawValue,sender: nil);
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let  view =  segue.destination as!  RouteGuideViewController
        view.SelectRoute = self.selectRoute
        initViewController(view)
    }
    
    
    //ルート名の一覧を作成
    func getRoutes(_ json : NSString )-> Bool {
        self.allRoutes = json.JsonToDic()
        
        
        self.useRoutes = allRoutes.filter{
            $0[Col.Use.Val] as! String == "1" && String(describing: $0[Col.Name.Val]) != "NODATA"
        }
        
        if(self.useRoutes.count == 0) {
            return false
        }
        
        for i in 0..<self.useRoutes.count {
            let id  =   self.useRoutes[i][Col.ID.Val] as! String
            self.useRoutes[i]["AliasName"] = id.RouteNameConvert()
        }
        btnStart.isEnabled = true
        self.searchRoutes =   self.useRoutes
        RouteTable.dataSource = self
        RouteTable.delegate = self
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.1, execute: {self.RouteTable.reloadData()})
        return true
        
    }
    
    func routesoundplay() {
        let id = self.selectRoute[Col.ID.Val] as! String
        let name = "\(self.Setting.User as String)_\(id)"
        let routesounddir  = SoundDir?.appendingPathComponent(name, isDirectory : true)
        let routesoundfile  = routesounddir?.appendingPathComponent("RouteName.caf", isDirectory : false)
        let checkValidation = FileManager.default
        self.SpeakEnd()
        self.stopMp3()
        if (checkValidation.fileExists(atPath: (routesoundfile?.path)!)){
            playMp3(routesoundfile! as NSURL)
        } else {
            self.Speak((selectRoute["AliasName"] as? String)!, false, false)
        }
    }
    
}

extension EditRouteSelectViewController: UITableViewDelegate, UITableViewDataSource  {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // セルを作る
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        cell.textLabel?.adjustsFontSizeToFitWidth = true;
        cell.textLabel?.text = searchRoutes[indexPath.row]["AliasName"] as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchRoutes.count
    }
    
    
    // セルがタップされた時の処理
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectRoute =  searchRoutes[indexPath.row]
        routesoundplay()
    }
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        // セルの高さを設定
        return 45
    }
    
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        
    }
}

