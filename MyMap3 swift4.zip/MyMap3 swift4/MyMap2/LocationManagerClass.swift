//
//  LocationManagerClass.swift
//  My地図アプリ
//
//  Created by developer on 2017/02/13.
//  Copyright © 2017年 njk. All rights reserved.
//

import Foundation
import CoreLocation
import AudioToolbox


class LocationManagerClass: NSObject, CLLocationManagerDelegate {
    //
    private var locationManager: CLLocationManager!
    private let clCalc = Calculation()
    var pt : [String:Any]!
    private var nowpt : [String:Any]?
    private var oldpt :[String:Any]?
    private var stoppt : [String:Any]?
    private var oldtime : Date?
    private var stoptimer : Timer?
    private var gpstimer : Timer?
    private var Newtimer : Timer?
    private var isStop: Bool = false
    private var isRec: Bool = false            // ルート登録
    private var clLocation : CLLocation!
    private var gpsCount : Int = 0
    private var clSet : SettingClass!
    private var isGetPoint : Bool = false       // 現在地の取得を行ったかどうか
    //
    var Routes: [[String:Any]] = []
    var Degree :Double = -1
   
    var Speed : Double = 0.0
    var IsMove : Bool = false
    var getGpsState : Bool = false
    var getStartLocation: Bool = false
    var getDirection : Bool = false
    var getMoveDirection : Bool = false
    //Delegate
    var LocationDelegate : LocationDelegate?
    
    var MoveDegreeEvent :((_ d : Double,_ pt :[String:Any] ) -> ())?
    var DegreeEvent  :((_ d : Double,_ pt :[String:Any] ) -> ())?
    var StopEvent  :((_ d : Bool) -> ())?
    var GpsStateEvent  :((_ state : GpsState, _ err : Double) -> ())?
    var StartLocationEvent  :((_ pt : [String:Any]) -> ())?
    var IsDenied : Bool = true
    var distanceFilter : Int!
    
    func initLocation(_ clSet : SettingClass,_ distanceFilter : Double){
        locationManager = CLLocationManager()
         // 認証が得られていない場合は、認証ダイアログを表示する
        let locStatus = CLLocationManager.authorizationStatus()
        self.clSet  = clSet
        if(locStatus == CLAuthorizationStatus.notDetermined) {
            locationManager.requestAlwaysAuthorization()
        }
          IsDenied =  locStatus == .denied
        locationManager.delegate = self
        self.distanceFilter = clSet.RegistDistanceInterval
        //locationManager.distanceFilter = CLLocationDistance(distanceFilter)                                              // 取得頻度の設定（◯ｍごとに位置情報取得）
        locationManager.desiredAccuracy = kCLLocationAccuracyBest   // 取得精度（kCLLocationAccuracyBest：最高精度）
        locationManager.activityType = .fitness                                         // iOSが自動的にポーズするための判定基準（.fitness : ランニングやサイクリング、ウォーキング）
         locationManager.allowsBackgroundLocationUpdates = true
        // このフラグをtrueにするとiOSが位置情報を新たに取得する必要がない状況を自動的に判断して、位置情報取得をポーズしてくれる。
        // バッテリー消費を抑えるということでAppleはtrueが推奨されている。
        // バックグラウンドでも位置情報を取得する必要がある場合は、falseに設定する。
        locationManager.pausesLocationUpdatesAutomatically = true
        locationManager.headingFilter = 4          // 何度動いたら更新するか（デフォルトは1度）
        locationManager.headingOrientation = .portrait                          // デバイスのどの向きを北とするか（デフォルトは画面上部）
        locationManager.startUpdatingHeading()                                   // ヘッディングイベント開始

    }
    
    func StartLocation() {
        gpsCount = 0
        locationManager.startUpdatingLocation()
   
        //停止判定タイマー起動
        if stoptimer == nil  {
            stoptimer = Timer.scheduledTimer(timeInterval: 1.5, target: self, selector: #selector(self.onStopTimerUpdate(_:)), userInfo: nil, repeats: true)
        }
      
        //GPSタイマー起動
        if(gpstimer == nil ) {
            gpstimer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(self.onGpsTimerUpdate(_:)), userInfo: nil, repeats: true)
        }
    }
    
    func LocationStop() {
        isStop = false
        getDirection = false
        isRec = false
        getGpsState = false
    }
    
    func LocationEnd() {
        LocationStop()
        TimerStop(gpstimer)
        gpstimer = nil
        TimerStop(stoptimer)
        stoptimer = nil
        LocationStop()
        locationManager.stopUpdatingLocation()
        self.pt = nil
        self.nowpt = nil
        self.Degree = -1
        self.Routes = []
    }

    /** ルート登録の開始 */
    func RecodeStart() {
        self.isRec = true
        self.Routes = []
        self.locationManager.requestLocation()
        self.nowpt = self.pt

        if self.nowpt != nil {
            self.nowpt? [Col.Len.Val] = 0.0
            self.nowpt? [Col.No.Val] = 0
            self.Routes.append(nowpt!)
        }

    }
    /** ルート登録の停止 */
    func RecodeStop() {
        self.isRec = false
    }
    /** ルート登録の再開 */
    func RecodeReStart() {
        self.isRec = true
    }
    
    func MoveStopStart() {
        isStop = true
    }
    
    func MoveStopEnd() {
        isStop = false
    }
    
    @objc func onStopTimerUpdate(_ timer : Timer){
        if pt == nil  { return }
        if stoppt  == nil  {
            stoppt = pt
            return
        }
        let len : Double = clCalc.LineLengeth(stoppt!, pt)
        if(len == 0) {
            if(isStop) { StopEvent!(true)}
            Speed = 0
        } else {
            if(isStop) { StopEvent!(false) }
        }
        stoppt = pt
        IsMove = len != 0
    }
    
    func onDirectionTimerUpdate(_ timer : Timer){
        
    }
    
    @objc func onGpsTimerUpdate(_ timer : Timer){
        if(self.getGpsState ) {
            print(clLocation)
            if clLocation.horizontalAccuracy  <= clSet.GpsAccuracy.value {
                GpsStateEvent?(.OK,clLocation.horizontalAccuracy )
                self.getGpsState = false
                 gpsCount = 0
            } else if gpsCount > 1 {
                GpsStateEvent?(.BadStart,clLocation.horizontalAccuracy )
                self.getGpsState = false
                  gpsCount = 0
            } else {
                GpsStateEvent?(.NG,clLocation.horizontalAccuracy )
                gpsCount += 1
            }
        }
    }

    /** 最後に取得した位置情報を取得する */
    func GetLastLocation() -> CLLocationCoordinate2D? {
        return locationManager.location?.coordinate
    }
    /** 最後に取得した方位を取得する */
    func GetLastHeading() -> CLHeading? {
        return locationManager.heading
    }
    
    /** 現在地を取得するリクエスト */
    func GetPoint() -> [String:Any] {
        let location = locationManager.location
     
         // 121.597508,38.895986
        let lat2 : Double = location!.coordinate.latitude
        let lon2 : Double = location!.coordinate.longitude
    
        let err :Double = location!.horizontalAccuracy as Double
        let pt = [Col.Lon.Val:lon2 , Col.Lat.Val:lat2 , Col.Err.Val:err,Col.Len.Val:0.0,Col.No.Val:0,Col.POI.Val:0,Col.Memo.Val:""] as [String : Any]
        let pos = Routes.count - 1
        var len : Double = 0
        if(pos != -1)
        {
           len = clCalc.LineLengeth(Routes[pos], pt)
        }
        self.nowpt = pt
        self.nowpt?[Col.Len.Val] = len
        self.nowpt?[Col.No.Val] = Routes.count * 10
        self.Routes.append(nowpt!)
       return nowpt!
    }
    
    /** 住所取得 */
    func  GetAddress() {
            CLGeocoder().reverseGeocodeLocation(clLocation , completionHandler: {(placemarks, error)->Void in
                if error != nil {
                    return
                }
                var address: String = ""
                if (placemarks?.count)! > 0 {
                    let pm = (placemarks?[0])! as CLPlacemark
                    //address += pm.postalCode != nil ? pm.postalCode! : ""
                    address += pm.administrativeArea != nil ? pm.administrativeArea! : ""
                    address += pm.locality != nil ? pm.locality! : ""
                    address += pm.subLocality != nil ? pm.subLocality! : ""
                    address += pm.subThoroughfare != nil ? pm.subThoroughfare! : ""
                }
                self.LocationDelegate?.GetAddressEvent(address)
                print(address)
            })
        
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        IsDenied =  status == .denied
    }
  
    
    func filterAndAddLocation(_ location: CLLocation) -> Bool{
        let age = -location.timestamp.timeIntervalSinceNow
        
        if age > 1{
            return false
        }
        if location.horizontalAccuracy < 0{
            return false
        }
        if location.horizontalAccuracy > 100{
            return false
        }
        return true
        
    }
    
    // 位置情報取得成功時に呼ばれます
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        locationManager.pausesLocationUpdatesAutomatically = false
        guard let location = locations.last else {
            return
        }
        if !CLLocationCoordinate2DIsValid(location.coordinate) {
            return
        }
        self.clLocation = location
        print(location)
        let lat2 : Double = location.coordinate.latitude
        let lon2 : Double = location.coordinate.longitude
        let err :Double = location.horizontalAccuracy as Double
        if(!filterAndAddLocation(location)){
            return;
        }
        self.pt = [Col.Lon.Val:lon2 , Col.Lat.Val:lat2 , Col.Err.Val:err,Col.Len.Val:0.0,Col.No.Val:0,Col.POI.Val:0,Col.Memo.Val:""]
        if getStartLocation {
            self.StartLocationEvent?(pt)
            getStartLocation = false
        }
   
       // Speed  = location.speed == -1 ?  0 : (location.speed  * 60.0 * 60.0 ) * 1.609344
        if oldpt != nil {
            let len : Double = clCalc.LineLengeth(pt,oldpt!)
            let sec : Double =    location.timestamp.timeIntervalSince( oldtime!)
            Speed  = (len  /  sec) * 3.6
            IsMove =  Speed > 0
            
            if Speed > self.clSet.GpsMoveSpeed.value {
             
            }
            if getMoveDirection && len > 2{
               MoveDegreeEvent!(clCalc.Direction(oldpt,pt),pt)
                oldpt = pt
            }
        } else {
            oldpt = pt
        }
        oldtime = location.timestamp
        let pos = Routes.count - 1
        if(isRec ) {
            let len:Int  = Int(clCalc.LineLengeth(Routes[pos], self.pt))
            if(len >= distanceFilter ){
                self.nowpt = self.pt
                self.nowpt?[Col.Len.Val] = len
                self.nowpt?[Col.No.Val] = Routes.count * 10
                self.Routes.append(nowpt!)
                LocationDelegate?.GpsLoggerUpdate(nowpt!)
            }
        }
        LocationDelegate?.LocationUpdate(pt, Routes.count - 1, false)
        isGetPoint = false
    }
    
    
    //電子コンパス
    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        if newHeading.headingAccuracy < 0 {
            return
        }
        if(newHeading.timestamp.timeIntervalSinceNow <  clSet.GpsTimePrecision.value) {
            self.Degree  = ((newHeading.trueHeading > 0) ? newHeading.trueHeading: newHeading.magneticHeading)
            if(getDirection ) {
                self.DegreeEvent!(self.Degree,pt)
            }
        }
    }

    

    func locationManagerDidPauseLocationUpdates(_ manager: CLLocationManager) {
        
        print("位置情報取得失敗")
    }
    
    // 位置情報取得失敗時に呼ばれます
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("位置情報取得失敗")
    }
    
    
    
    //timerを破棄する.
    func TimerStop(_ timer : Timer!) {
        if(timer == nil) { return }
        timer.invalidate()
    }
}

protocol  LocationDelegate{
    func GetAddressEvent(_ add : String)
    func LocationUpdate(_ pt: [String : Any],_ pos : Int, _ isRequest : Bool)
    func GpsLoggerUpdate(_ pt: [String : Any])
//    func TimerLocationUpdate(_ pt: [String : Any])
//    func  GpsEvent(_ isgps: Bool)
}


