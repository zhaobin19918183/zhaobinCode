//
//  RouteSelectViewController.swift
//  MyMap2
//
//  Created by developer on 2017/04/17.
//  Copyright © 2017年 njk. All rights reserved.
//
import AVFoundation
import UIKit

class RouteSelectViewController: BaseViewController ,UIScrollViewDelegate{

    @IBOutlet weak var RouteTable: UITableView!
   // private  var clLoc = LocationManagerClass()
    let clSound = SoundVibrateClass()
    private var routeJson :String!
    private var allRoutes : [[String:Any]] = []
    private var useRoutes:[[String:Any]] = []
    private var mode : SegueIds!
    @IBOutlet weak var btnStart: UIButton!
    @IBOutlet weak var scroll: UIScrollView!
    @IBOutlet weak var editName: BaseUITextField!
    var  index = IndexPath()
    var valueSelect :String = ""
    var searchRoutes:[[String:Any]] = []
    var selectRoute : [String:Any]!
    var editRow : Int!
    var previewingViewController: UIViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        clLoc?.initLocation(self.Setting,0)
        if  (clLoc?.IsDenied)! {
            self.Speak("位置情報の取得が許可しないに設定されています、許可に変更してから実行してください")
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                self.TopPage()
            }
            return
        }
        let notificationName = Notification.Name(rawValue: "RouteSelectViewController")
        NotificationCenter.default.addObserver(self,
                                               selector:#selector(downloadImage(notification:)),
                                               name: notificationName, object: nil)
        
        self.clLoc?.StartLocation()
        self.clPHP?.JsonData = { (json : NSString?,err : Int) in
            if err != 0 || json == nil {
                // エラーまたはデータがない場合
                self.Speak("ルート取得失敗")
                return
            }
            
            if !self.getRoutes(json!) {
                self.Speak("ルート登録されていません")
                return
            }
            self.Speak2("\(self.useRoutes.count )個のルート。案内ルートを選択")
        }
        self.clLoc?.getStartLocation = true
        self.clLoc?.StartLocationEvent = { pt  in
            let x = pt[Col.Lat.Val]  as! Double
            let y = pt[Col.Lon.Val]  as! Double
            let parameters: [String : Any] = ["USER":self.Setting.User,"AREA":self.Setting.SearchDistance.value,"LAT": x,"LON":y, "SORT": self.Setting.SearchOrder.ind]
            let phppath = "https://mymapdemo.net/nedo/search.php"
            self.clPHP?.GetData(phppath, parameters,.JSON)
            self.clLoc?.LocationEnd()
        }
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.doubleTapped))
        tap.numberOfTapsRequired = 2
        self.RouteTable.addGestureRecognizer(tap)
        scroll.delegate = self
    
    }

    @objc func doubleTapped() {
     
        print(selectRoute)
        if selectRoute == nil { return }
        performSegue(withIdentifier: SegueIds.RouteGuide.rawValue,sender: nil)
        
    }

    @IBAction func newRouteTouchDown(_ sender: Any) {
   
        if  searchRoutes.count == 0 {
            Speak("ルートなし。メニュー画面へ戻ります")
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                self.TopPage()
            }
            return
        }
        self.selectRoute =  searchRoutes[0]
        routesoundplay()
        performSegue(withIdentifier: SegueIds.RouteGuide.rawValue,sender: nil);
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let  view =  segue.destination as!  RouteGuideViewController
        view.SelectRoute = self.selectRoute
        initViewController(view)
    }
    

    //ルート名の一覧を作成
    func getRoutes(_ json : NSString )-> Bool {
        self.allRoutes = json.JsonToDic()
        print(allRoutes)
        self.useRoutes = allRoutes.filter{
            $0[Col.Use.Val] as! String == "1" && String(describing: $0[Col.Name.Val]) != "NODATA"
        }
        //self.useRoutes = allRoutes
        if(self.useRoutes.count == 0) {
            return false
        }

        let predicate = NSPredicate(format: "SELF MATCHES '\\\\d+'")
        
        for i in 0..<self.useRoutes.count {
            let name  =   self.useRoutes[i][Col.Name.Val] as! String
          
            if(predicate.evaluate(with: name)){
                self.useRoutes[i]["AliasName"] = name.RouteNameConvert()
            } else {
                  self.useRoutes[i]["AliasName"] = name
            }
        }
        
        btnStart.isEnabled = true
        self.searchRoutes =   self.useRoutes
        RouteTable.dataSource = self
        RouteTable.delegate = self
        RouteTable.backgroundColor = UIColor.yellow
        RouteTable.register(MyCell.self, forCellReuseIdentifier: NSStringFromClass(MyCell.self))
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.1, execute: {self.RouteTable.reloadData()})
        return true
        
    }
    
    func routesoundplay() {
        let id = self.selectRoute[Col.ID.Val] as! String
        let name = "\(self.Setting.User as String)_\(id)"
        let routesounddir  = SoundDir?.appendingPathComponent(name, isDirectory : true)
        let routesoundfile  = routesounddir?.appendingPathComponent("RouteName.caf", isDirectory : false)
        let checkValidation = FileManager.default
        self.SpeakEnd()
        self.stopMp3()
        if (checkValidation.fileExists(atPath: (routesoundfile?.path)!)){
            playMp3(routesoundfile! as NSURL)
        } else {
            self.Speak((selectRoute["AliasName"] as? String)!, false, false)
        }
    }
    
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        let frame =  scroll.bounds
        if(frame.origin.x == 0)
        {
            scroll.isScrollEnabled = false
        }
       
    }
   
    @IBAction func routeNameChange(_ sender: Any) {
        
        let name = editName.text!
        
        if(name == ""){
            self.Speak("ルート名を入力")
            return
        }
        
        self.clPHP?.PhpComplete = {(ret : Bool?) in
           
            if ret! {
                self.resignFirstResponder()
                self.searchRoutes[self.editRow]["AliasName"] = name
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.1, execute: {self.RouteTable.reloadData()})
                self.Speak("ルート名を\(name)に変更")
                self.pagechange(0)
            } else {
                self.Speak("ルート名変更に失敗")
            }
        }
   
        let id = searchRoutes[editRow][Col.ID.Val] as! String
        let parameters: [String : Any] = ["USER":self.Setting.User,"ID":id ,"NAME": name]
        let phppath = "https://mymapdemo.net/nedo/renroute.php"
        self.clPHP?.Post(phppath, parameters)
    }
    
    func pagechange(_ page : CGFloat){
        
        scroll.isScrollEnabled = true
        var frame =  scroll.bounds
        
        frame.origin.x = frame.width * page
        frame.origin.y = 0
        scroll.scrollRectToVisible(frame, animated: true)
     
    }
    
    @IBAction func cancelTouchDown(_ sender: Any) {
        self.pagechange(0)
    }
    
    @IBAction func menuTouchDown(_ sender: Any) {
        self.SpeakEnd()
        self.TopPage()
    }
    @IBAction func routeDelete(_ sender: Any) {
        
        let alert = UIAlertController(title:"ルート削除", message: "ルートを削除してよろしいですか？", preferredStyle: UIAlertControllerStyle.alert)
        
        let action1 = UIAlertAction(title: "削除", style: UIAlertActionStyle.default, handler: {
            (action: UIAlertAction!) in
            let php = PHP();
            php.PhpComplete = {(ret : Bool?) in
                self.searchRoutes.remove(at: self.editRow)
                 DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.1, execute: {self.RouteTable.reloadData()})
                  self.Speak("ルートを削除")
                self.pagechange(0)
                
            }
           let id = self.searchRoutes[self.editRow][Col.ID.Val] as! String
            let parameters: [String : Any] = ["USER":self.Setting.User,"ID":id]
            let phppath = "https://mymapdemo.net/nedo/delroute.php"
            php.Post(phppath, parameters)
            
        })
        let action2 = UIAlertAction(title: "中止", style: UIAlertActionStyle.default, handler: {
            (action: UIAlertAction!) in
        })
        alert.addAction(action1)
        alert.addAction(action2)
        self.present(alert, animated: true, completion: nil)    }
    
}






extension RouteSelectViewController: UITableViewDelegate, UITableViewDataSource  {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // セルを作る
        //let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        let cell = tableView.dequeueReusableCell(withIdentifier: NSStringFromClass(MyCell.self), for: indexPath) as! MyCell
       
         //cell.addButton.setTitle("編集", for: .normal)
            //cell.addButton.tag = indexPath.row
       //cell.textLabel?.adjustsFontSizeToFitWidth = true;
       //cell.textLabel?.text = searchRoutes[indexPath.row]["AliasName"] as? String
        //cell.UIButton.text = "編集"
        //print(searchRoutes[indexPath.row]["AliasName"])
        
        cell.setCell(name: (searchRoutes[indexPath.row]["AliasName"] as? String)!,rowNo: indexPath.row)
        
        
//        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
//        cell.accessoryType = .detailButton
//        cell.textLabel?.text = "セル\(indexPath.row + 1)"
//        cell.detailTextLabel?.text = "\(indexPath.row + 1)番目のセルの説明"
        cell.edit.addTarget(self, action: #selector(self.onClick(sender:)), for: .touchUpInside)
        
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchRoutes.count
    }
    
    
    // セルがタップされた時の処理
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectRoute =  searchRoutes[indexPath.row]
        if valueSelect == ""
        {
            routesoundplay()
        }
        else
        {
            let regist = RouteRegist()
            self.present(regist, animated: true, completion: nil)
            self.remove()
        }
        
       
    }
    
    @objc func downloadImage(notification: Notification)
    {
        let userInfo = notification.userInfo as! [String: AnyObject]
         valueSelect = userInfo["valueSelect"] as! String

    }
    
    func  remove(){
        //记得移除通知监听
        NotificationCenter.default.removeObserver(self)
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        // セルの高さを設定
        return 45
    }
    
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        
    }
    
    @objc func onClick(sender: UIButton) {
        //Button Tapped
     
       pagechange(1)

        editRow = sender.tag
        
        editName.text = searchRoutes[editRow]["AliasName"] as? String
    }
 
}

class MyCell: UITableViewCell {
    var myLabel: UILabel!
    var edit : UIButton!
    var delete : UIButton!
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = UIColor.yellow
        myLabel = UILabel(frame: CGRect.zero)
        myLabel.textAlignment = .left
        contentView.addSubview(myLabel)
        
        edit = UIButton()
        edit.backgroundColor = UIColor.red // 背景色
      
        edit.layer.borderWidth = 2.0 // 枠線の幅
        edit.layer.borderColor = UIColor.red.cgColor // 枠線の色
        edit.layer.cornerRadius = 15.0 // 角丸のサイズ
        edit.setTitleColor(UIColor.white,for: UIControlState.normal)
        edit.setTitleColor(UIColor.blue, for: .highlighted)
        edit.setTitle("編集", for: .normal)
        contentView.addSubview(edit)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder: ) has not been implemented")
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        
        
        edit.frame = CGRect(x: frame.width - 50, y: 7.5, width: 50, height: 30)
        myLabel.frame = CGRect(x: 0, y: 0, width: frame.width - 50, height: frame.height)
    }
    
    func setCell(name: String,rowNo : Int) {
        myLabel.text = name
        edit.tag = rowNo
    }
    
    
}
