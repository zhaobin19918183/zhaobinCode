//
//  Enums.swift
//  My地図アプリ
//
//  Created by developer on 2017/02/15.
//  Copyright © 2017年 njk. All rights reserved.
//

import Foundation
import UIKit

enum SegueIds: String {
    case RouteName = "RouteNameSegue"
    case Route = "RouteRecSegue"
    case RouteSelect = "RouteSelectSegue"
    case RouteGuide = "RouteGuideSegue"
    case Menu = "BackMenuSegue"
    case PoiEdit = "PoiEditSegue"
    case PoiEditSelect = "PoiEditSelectSegue"
    case Setting = "SettingSegue"
       case GpsSetting = "GpsSettingSegue"
       case SearchSetting = "SearchSettingSegue"
       case GuideSetting = "GuideSettingSegue"
       case LostSetting = "LostSettingSegue"
}

enum Col : String {
    case UserId = "USERID"
    case RouteId = "ROUTEID"
    case User = "USER"
    case Name = "NAME"
    case No = "NO"
    case Lon = "LON"
    case Lat = "LAT"
    case Len = "LEN"
    case Err = "ERR"
    case POI = "TYPE"
    case Use = "USE"
    case ID = "ID"
    case Pos = "POS"
    case Memo = "MEMO"
    var Val : String {
        return self.rawValue
    }
}

enum SpeechType {
    case None
    case RouteName
    case Route
    case Menu
    case RouteSelect
    case RouteGuide
}

enum GpsState {
    case OK
    case NG
    case BadStart
    
}

enum CommandType {
    case None
    case POI
    case Rec
    case Complete
    case Cancel
    case Command
    case Location
    case Playback
    case Select
}

enum DataType {
    case None
    case JSON
    case ZIP
  
}

enum PoiType : Int{
    case None = 0
    case Danger = 1
    case Location = 2
    case Like  = 3
    var Val : String {
        if(self == .Danger) { return "危険" }
        else if(self == .Location ){ return "情報"}
        else if(self == .Like) { return "お気に入り"}
        return ""
    }
    var No : Int {
        return self.rawValue
    }
    
    func  GetType(_ val : String)-> PoiType{
        if(val.contains("危険")) { return .Danger }
        else if(val.contains("情報")) { return .Location }
        else if(val.contains("お気に入り")) { return .Like }
        return .None
    }
}

enum RouteOutType {
    case None
    case S
    case M
    case L
}

enum RouteType : Int  {
    case None = 0
    case Denger = 1
    case Info = 2
    case Like = 3
    case Start = 4
    case Goal = 5
    case Out = 6
    case Guide = 7
}


/**
 ◆検索並び順
 */
enum SearchOrderType : Int {
    case None = 0
    case Distance = 1       // 距離
    case CreateDateDesc = 2 // 作成日降順
    case CreateDateAsc = 3  // 作成日昇順
    case Frequency = 4      // 使用頻度
    
    var Val : String {
        if(self == .Distance) { return "距離" }
        else if(self == .CreateDateDesc ){ return "作成日降順"}
        else if(self == .CreateDateAsc) { return "作成日昇順"}
        else if(self == .Frequency) { return "使用頻度" }
        return ""
    }
    var No : Int {
        return self.rawValue
    }
    /**
     ◆文字列からSearchOrderTypeを取得する
     - Parameter val : 並び順の名称
     */
    func GetType(_ val : String)-> SearchOrderType{
        if(val.contains("距離")) { return .Distance }
        else if(val.contains("作成日降順")) { return .CreateDateDesc }
        else if(val.contains("作成日昇順")) { return .CreateDateAsc }
        else if(val.contains("使用頻度")) { return .Frequency }
        return .None
    }
}
/**
 ◆方位通知方法
 */
enum GuideDirectionType : Int {
    case None = 0
    case Clock = 1                          // 時計
    case Direction = 2                     // 方位
    case FrontBackLeftRight = 3     // 前後左右
    
    var Val : String {
        if(self == .Clock) { return "時計" }
        else if(self == .Direction ){ return "方位"}
        else if(self == .FrontBackLeftRight) { return "前後左右"}
        return ""
    }
    var No : Int {
        return self.rawValue
    }
    /**
     ◆文字列からGuideDirectionTypeを取得する
     - Parameter val : 方位通知方法の名称
     */
    func GetType(_ val : String)-> GuideDirectionType{
        if(val.contains("時計")) { return .Clock }
        else if(val.contains("方位")) { return .Direction }
        else if(val.contains("前後左右")) { return .FrontBackLeftRight }
        return .None
    }

}
