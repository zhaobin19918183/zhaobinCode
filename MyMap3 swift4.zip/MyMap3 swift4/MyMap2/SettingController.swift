//
//  SettingController.swift
//  MyMap2
//
//  Created by developer on 2017/10/17.
//  Copyright © 2017年 njk. All rights reserved.
//

import UIKit
import AudioToolbox
class SettingController: BaseViewController,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource {
 
    
   
    @IBOutlet weak var peopleSegmented: UISegmentedControl!
    @IBOutlet weak var sliderLabel: UILabel!
    @IBOutlet weak var lengthSlider: UISlider!
    @IBOutlet weak var stp1: UIStepper!
    @IBOutlet weak var stp2: UIStepper!
    @IBOutlet weak var len1: UITextField!
    @IBOutlet weak var len2: UITextField!
    @IBOutlet weak var sound: UISegmentedControl!
    @IBOutlet weak var missTimeTextField: UITextField!
    @IBOutlet weak var missTimeStp: UIStepper!
    @IBOutlet weak var downlaodLabel: UILabel!
    @IBOutlet weak var downloadButton: UIButton!
    @IBOutlet weak var selectLabel: UILabel!
    @IBOutlet weak var search: UITextField!
    @IBOutlet weak var voiceDegmented: UISegmentedControl!
    @IBOutlet weak var searchStp: UIStepper!
    @IBOutlet weak var startTextField: UITextField!
    @IBOutlet weak var selectButton1: UIButton!
    @IBOutlet weak var endTextField: UITextField!
    @IBOutlet weak var uploadOkButton: UIButton!
    @IBOutlet weak var selectButton2: UIButton!
    @IBOutlet weak var missTextField: UITextField!
    @IBOutlet weak var missStepper: UIStepper!
    @IBOutlet weak var endStepper: UIStepper!
    @IBOutlet weak var startStepper: UIStepper!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var timeTextField: UITextField!
    @IBOutlet weak var timeSteper: UIStepper!
    
    @IBOutlet weak var mselectSeg: UISegmentedControl!
    
    
    @IBOutlet weak var emailSelect: UIButton!
    
    @IBOutlet weak var vibrationsegment: UISegmentedControl!
    
    
    var pickerView:UIPickerView!
    let backView = UIView()
    let emaelView = UIView()
    let emailBack = UIView()
    let emailSure = UIButton()
    let emailTextView = UITextView()
    var emailTextField = UITextField()
    var emailArray = NSMutableArray()
    var selectBool = Bool()
    var titleArr = NSMutableArray()
    var detailArr = NSMutableArray()
    var selectString = String()
    var userSelect1 = String()
    var userSelect2 = String()
    var count = 0
    var countTime = 0
    var Newtimer : Timer?
    let userDefaults = UserDefaults.standard
    var tableview = UITableView()
    var keyString = "ルート上音"
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        stp1.value =      Double(self.Setting.LostSmallDistance);
        len1.text =  String( Int(stp1.value))
       
        lengthSlider.minimumValue = 1
        lengthSlider.maximumValue = 999
        self.sliderLabel.text = String(self.Setting.RegistDistanceInterval)
    lengthSlider.setValue(Float(self.Setting.RegistDistanceInterval),animated: true)
//        stp2.value =  self.Setting.RegistDistanceInterval;
//        len2.text =  String(stp2.value)
        
        searchStp.value =  Double(self.Setting.LostSearchDistance);
        search.text =  String(Int(searchStp.value))
        
        timeSteper.value =  Double(self.Setting.settingTime);
        timeTextField.text =  String(Int(timeSteper.value))
        timeSteper.maximumValue = 20
        timeSteper.minimumValue = 3
        
        
        voiceDegmented.selectedSegmentIndex = self.Setting.settingVoiceSelect
        
        mselectSeg.selectedSegmentIndex = self.Setting.settingTenMSelect
        
         vibrationsegment.selectedSegmentIndex = self.Setting.settingVibrationSelect
        peopleSegmented.selectedSegmentIndex = self.Setting.settingPeoPleSelect
        
        startStepper.value =  Double(self.Setting.settingStartDistance);
        startTextField.text =  String(Int(startStepper.value))

        missTimeStp.value =  Double(self.Setting.settingTimeLocation)
        missTimeTextField.text =  String(Int(missTimeStp.value))
        
        endStepper.value  =  Double(self.Setting.settingEndDistance);
        endTextField.text =  String(Int(endStepper.value))
        
        missStepper.value  =  Double(self.Setting.settingMissDistance);
        missTextField.text =  String(Int(missStepper.value))
        
        sound.selectedSegmentIndex = self.Setting.IsRouteoutVoice;
        
        selectButton1.tag = 1
        selectButton2.tag = 2
        selectButton1.layer.cornerRadius = 10
        selectButton2.layer.cornerRadius = 10

        selectButton1.layer.borderWidth = 2
        selectButton2.layer.borderWidth = 2
        
        selectButton1.layer.borderColor = UIColor.blue.cgColor
        selectButton2.layer.borderColor = UIColor.blue.cgColor
        
        selectButton1.backgroundColor = UIColor.white
        selectButton2.backgroundColor = UIColor.white
        
        let userid = UserDefaults.standard.string(forKey: "selectAction")
        
       
        if userid == "101"
        {
            selectButton1.backgroundColor = UIColor.red
            selectButton2.backgroundColor = UIColor.white
        }
        if userid == "102"
        {
            selectButton1.backgroundColor = UIColor.white
            selectButton2.backgroundColor = UIColor.red
            
        }

        
    }
    //MARK: Email Setting
    @IBAction func emailSelectAction(_ sender: UIButton)
    {
      
 
//        emailArray = try!self.userDefaults.mutableArrayValue(forKey: "emailText")
        do {
         emailArray = self.userDefaults.mutableArrayValue(forKey: "emailText")
        }

        emaelView.frame = CGRect(x: 0, y: self.view.bounds.size.height/3*2 - 40, width: self.view.bounds.size.width, height: self.view.bounds.size.height/3+40)
        tableview.frame = CGRect(x: 0, y: 0, width: self.view.bounds.size.width, height: self.view.bounds.size.height/3+40)
        tableview.dataSource = self
        tableview.delegate = self
        emaelView.addSubview(tableview)
        
        emaelView.backgroundColor = UIColor.white
        
        emailBack.frame = CGRect(x: 0, y:self.view.bounds.size.height/3*2-80, width: self.view.bounds.size.width, height:40)
        emailBack.backgroundColor = UIColor.orange
        self.view.addSubview(emailBack)
        
        emailTextField.frame = CGRect(x: 15, y:5, width: self.view.bounds.size.width - 120, height:30)
        emailTextField.delegate = self
        emailTextField.backgroundColor = UIColor.white
        emailBack.addSubview(emailTextField)
        
        emailSure.frame = CGRect(x: self.view.bounds.size.width - 80, y:0, width:60, height:40)
        emailSure.setTitle("閉じる", for: UIControlState.normal)
        emailSure.setTitleColor(UIColor.white, for: UIControlState.normal)
        emailSure.backgroundColor = UIColor.blue
        emailSure.addTarget(self, action: #selector(selectSureAction), for: UIControlEvents.touchUpInside)
        emailBack.addSubview(emailSure)
        
        self.view.addSubview(emaelView)
        
        emaelView.isHidden = false
        emailBack.isHidden = false
    }
    @objc func selectSureAction()
    {
        emaelView.isHidden = true
        emailBack.isHidden = true
        emailTextField.resignFirstResponder()
        
    }
    //MARK :textFieldDelegate
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        
    }
    //MARK: キーボードreturnボタンを選びましょう。
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        if validateEmail(email: textField.text!)
        {
            if emailArray.count < 5
            {
                emailArray.add(textField.text as Any)
            }
            else
            {
                self.alertAction(message: "限定数量を超える")
                
            }
            
            textField.resignFirstResponder()
            textField.text = ""
            tableview.reloadData()
            emaelView.isHidden = true
            emailBack.isHidden = true
        }
        else
        {

            self.alertAction(message: "メールアドレスの入力が間違う")
        }
        
        
        
        return true
    }
    //MARK: Alert
    func alertAction(message:String)
    {
        let alert = UIAlertController(title:"警告", message: message, preferredStyle: UIAlertControllerStyle.alert)
        let action2 = UIAlertAction(title: "閉じる", style: UIAlertActionStyle.default, handler: {
            (action: UIAlertAction!) in
            self.emailTextField.resignFirstResponder()
        })
        alert.addAction(action2)
        self.present(alert, animated: true, completion: nil)
        
    }
    
    //MARK: email 検証
    func validateEmail(email: String) -> Bool {
        
      let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        
       let emailTest:NSPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        
        return emailTest.evaluate(with: email)
        
    }
    

    //MARK: tableView delegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if emailArray.count != 0
        {
        
         return emailArray.count
        }
        
        return 0

    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
       
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:UITableViewCell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: nil)
        
        cell.selectionStyle = .none
        
        if emailArray.count != 0
        {
            emailArray = userDefaults.mutableArrayValue(forKey: "emailText")
            
            cell.textLabel?.text = (emailArray.object(at: indexPath.row) as! String)
        }
        let editButton = UIButton()
 
        editButton.tag = indexPath.row
        editButton.frame = CGRect(x: cell.bounds.size.width - 40, y: 2, width: 80, height:40)
        editButton.setTitle("修正", for: UIControlState.normal)
        editButton.setTitleColor(UIColor.white, for: UIControlState.normal)
        editButton.backgroundColor = UIColor.red
        editButton.addTarget(self, action: #selector(editAction), for: UIControlEvents.touchUpInside)
        cell.addSubview(editButton)
        return cell
    }
    //MARK:郵便ポストを修正する
    @objc func editAction(_ sender: UIButton)
    {
        let alertVC = UIAlertController(title: "メールアドレスを修正した。", message: "新しいメールアドレス", preferredStyle: UIAlertControllerStyle.alert)

        alertVC.addTextField {
            (textField: UITextField!) -> Void in
            textField.placeholder = "閉じる"
        }
        
        let alertActionOK = UIAlertAction(title: "確定", style: UIAlertActionStyle.default, handler: {
            action in
            let email = alertVC.textFields!.first! as UITextField
            
            if email.text != ""
            {
                if self.validateEmail(email: email.text!)
                {
                     self.emailArray[sender.tag] = email.text!
                }
                else
                {
                     self.alertAction(message: "メールアドレスの入力が間違う")
                }
            }
      
            self.tableview.reloadData()
        })
        
        alertVC.addAction(alertActionOK)
        self.present(alertVC, animated: true, completion: nil)
    }
    
    @IBAction func voiceOpenOrEnd(_ sender: UISegmentedControl)
    {
        // settingVoiceSelect
     self.Setting.Save(sender.selectedSegmentIndex,"settingVoiceSelect")
         self.Setting.settingVoiceSelect = sender.selectedSegmentIndex
    }
    @IBOutlet weak var menu: UIButton!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func sound(_ sender: Any) {
        let i = sound.selectedSegmentIndex;
        self.Setting.Save(i,"IsRouteoutVoice")
    }
    //TODO:終了時点の範囲設定
    @IBAction func missTimeStepAction(_ sender: UIStepper)
    
    {
        missTimeTextField.text = String( Int(missTimeStp.value))
        self.Setting.Save(missTimeStp.value,"missTimeLocation")
        self.Setting.settingTimeLocation = Int(missTimeStp.value);
        
    }
    @IBAction func len1change(_ sender: Any) {
        len1.text = String( Int(stp1.value))
        self.Setting.Save(Int(stp1.value),"LostSmallDistance")
        self.Setting.LostSmallDistance = Int(stp1.value)
        
        self.Setting.Save(stp1.value + 5,"LostMiddleDistance")
        self.Setting.LostMiddleDistance = Int(stp1.value + 5)
    }
    
    
    @IBAction func Mselect(_ sender: UISegmentedControl)
    {
        self.Setting.Save(sender.selectedSegmentIndex,"settingTenMSelect")
        self.Setting.settingTenMSelect = sender.selectedSegmentIndex
    }
    @IBAction func lengthSliderAction(_ sender: UISlider)
    {
        let str = String(Int(sender.value))
        self.sliderLabel.text = str
        self.Setting.Save(sender.value,"RegistDistanceInterval")
        self.Setting.RegistDistanceInterval = Int(sender.value)
        
    }
    //MARK:機械音選択 and  振動選択
    @IBAction func musicSelectAction(_ sender: UIButton)
    {
    
        titleArr = ["ルート上音","迷時音","ゴールオン"]
        if sender.tag == 2
        {
            detailArr = ["1","2","3"]
            count = 1
            timerPostLoaction(time: 1)
        }
        else
        {
            detailArr = ["seikai","どれみ","みれど","decision4","warning2","dog1","warning2"]
            let warning1 = NSURL(fileURLWithPath: Bundle.main.path(forResource: "seikai", ofType: "mp3")!)
            playMp3(warning1)
        }
         self.selectView()
         UserDefaults.standard.set(sender.tag, forKey: "musicSelectAction")

    }
    //MARK: pickerView
    func  selectView()
    {
        pickerView = UIPickerView()
        pickerView.delegate = self
        pickerView.dataSource = self
        pickerView.backgroundColor  = UIColor.white
        pickerView.frame = CGRect(x: 0, y: self.view.bounds.size.height/3*2, width: self.view.bounds.size.width, height: self.view.bounds.size.height/3)
        self.view.addSubview(pickerView);
        
        backView.frame = CGRect(x: 0, y:self.view.bounds.size.height/3*2-40, width: self.view.bounds.size.width, height:40)
        backView.backgroundColor = UIColor.orange
        self.view.addSubview(backView)
        
        
        let sureButton = UIButton ()
        sureButton.frame = CGRect(x: self.view.bounds.size.width - 80, y: 0, width: 80, height:40)
        sureButton.setTitle("确定", for: UIControlState.normal)
        sureButton.setTitleColor(UIColor.white, for: UIControlState.normal)
        sureButton.backgroundColor = UIColor.red
        sureButton.addTarget(self, action: #selector(selectAction), for: UIControlEvents.touchUpInside)
        backView.addSubview(sureButton)
       
        backView.isHidden = false
        pickerView.isHidden = false
    }
    
    @objc func selectAction()
    {
        backView.isHidden = true
        pickerView.isHidden = true
  
    }
    
    //MARK: pickerViewdelegate
    //------设置选择框的列数为3列,继承于UIPickerViewDataSource协议------
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    //设置选择框的行数为9行，继承于UIPickerViewDataSource协议
    func pickerView(_ pickerView: UIPickerView,numberOfRowsInComponent component: Int) -> Int{
        if component == 0
        {
            return titleArr.count
            
        }
        return detailArr.count
    }
    //设置选择框各选项的内容，继承于UIPickerViewDelegate协议
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int)
        -> String? {
            if component == 0
            {
                return titleArr[row] as? String
                
            }
            return detailArr[row] as? String
    }
    func pickerView(_ pickerView: UIPickerView,rowHeightForComponent component: Int) -> CGFloat{
        return 50
    }
    //gpstimer?.invalidate()
    //MARK: zhengdong
    @IBAction func vibrationSegmented(_ sender: UISegmentedControl)
    {
   self.Setting.Save(sender.selectedSegmentIndex,"settingVibrationSelect")
        self.Setting.settingVibrationSelect = sender.selectedSegmentIndex
    }
    //4，检测响应选项的选择状态
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        //将在滑动停止后触发，并打印出选中列和行索引
        
        count = 0
        
        let tagInt = userDefaults.integer(forKey: "musicSelectAction")
        if tagInt  == 2
        {
            
            self.pickerParam(component: component, row: row, tagInt: tagInt,userdefults:"振動選択")
            
        }
        
        else
        {
            self.pickerParam(component: component, row: row, tagInt: tagInt,userdefults:"機械音選択")
        }
        
        
    }
    
    func pickerParam(component :Int,row:Int,tagInt:Int,userdefults:String)
    {
        
        if component == 0
        {
            keyString = titleArr[row] as! String
            userSelect1 = String("\(component)" + "-" + "\(row)" )
        }

        else{
          
            if tagInt == 2
           {
            userSelect2 = String("\(component)" + "-" + "\(row)" )
            
            if userSelect1 == ""
            {
                userSelect1 = "0-0"
            }
            if userSelect2 == ""
            {
                userSelect1 = "0-1"
            }
            timerPostLoaction(time: row)
            
            UserDefaults.standard.set( userSelect2, forKey:keyString + "-" + userdefults)
            
        
        }
        else
        {
            userSelect2 = detailArr[row] as! String
            
            UserDefaults.standard.set(userSelect2, forKey:keyString + "-" + userdefults)
           
             let warning1 = NSURL(fileURLWithPath: Bundle.main.path(forResource: userSelect2, ofType: "mp3")!)
             playMp3(warning1)
        }
        
        }
        
    }
    

    func  timerPostLoaction(time:Int)
    {
      var gpstimer : Timer?
      gpstimer = Timer.scheduledTimer(timeInterval: TimeInterval(time%10), target: self, selector: #selector(self.onGpsTimerUpdate(_:)), userInfo: nil, repeats: true)
       Newtimer = gpstimer
        countTime = time

    }
    
    @objc func onGpsTimerUpdate(_ timer : Timer)
    {
        //振动
        count += 1
        if count  > countTime + 1
        {
            Newtimer?.invalidate()
        }
        else
        {
           AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
        }

        
        
    }
   
   
    @IBAction func len2chnge(_ sender: Any) {
//        len2.text = String( stp2.value);
//        self.Setting.Save(stp2.value,"RegistDistanceInterval")
//        self.Setting.RegistDistanceInterval = stp2.value;

    }
    @IBAction func menu(_ sender: Any) {
        self.TopPage()
        UserDefaults.standard.set(emailArray, forKey: "emailText")
    }
    
    @IBAction func uploadOKButton(_ sender: UIButton)
    {
    }
    
    @IBAction func searchStpAction(_ sender: UIStepper)
    {
        
        
        search.text =  String(Int(searchStp.value))
        self.Setting.Save(searchStp.value,"LostSearchDistance")
        self.Setting.LostSearchDistance = Int(searchStp.value)
        
    }
    
    @IBAction func endAction(_ sender: UIStepper) {
        
        endTextField.text =  String(Int(endStepper.value))
        self.Setting.Save(endStepper.value,"settingEndDistance")
        self.Setting.settingEndDistance = Int(endStepper.value)
    }
    
    @IBAction func missAction(_ sender: UIStepper) {
        missTextField.text =  String(Int(missStepper.value))
        self.Setting.Save(missStepper.value,"settingMissDistance")
        self.Setting.settingMissDistance = Int(endStepper.value)
    }
    
    @IBAction func startAction(_ sender: UIStepper) {
        startTextField.text =  String(Int(startStepper.value))
        self.Setting.Save(startStepper.value,"settingStartDistance")
        self.Setting.settingStartDistance = Int(startStepper.value)
    }
    
    
    @IBAction func slectAction(_ sender: UIButton)
    {
      
//        NotificationCenter.default.post(name: NSNotification.Name("settingSelect"), object: self, userInfo:nil)
        if sender.tag == 1
        {
            sender.backgroundColor = UIColor.red
            selectButton2.backgroundColor = UIColor.white
            UserDefaults.standard.set("101", forKey: "selectAction")
        }
       if sender.tag == 2
        {
            sender.backgroundColor = UIColor.red
            selectButton1.backgroundColor = UIColor.white
            UserDefaults.standard.set("102", forKey: "selectAction")
            
        }
        
    }
    
    @IBAction func peopleSoundAction(_ sender: UISegmentedControl)
    {
        self.Setting.Save(sender.selectedSegmentIndex,"settingPeoPleSelect")
           self.Setting.settingPeoPleSelect = sender.selectedSegmentIndex
        
    }
    @IBAction func timeStepperAction(_ sender: UIStepper)
    {
        timeTextField.text =  String(Int(timeSteper.value))
        self.Setting.Save(timeSteper.value,"settingTime")
        self.Setting.settingTime = Int(timeSteper.value)
        
    }
    
    @IBAction func selectMusicButtonNumber(_ sender: UIButton) {
    }
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }


}
