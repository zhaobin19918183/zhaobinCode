//
//  DangerousViewController.swift
//  MyMap2
//
//  Created by newland on 2018/1/9.
//  Copyright © 2018年 njk. All rights reserved.
//

import UIKit
import MessageUI
import MapKit
import CoreLocation // 定位GPS相关
import Photos

class DangerousViewController: BaseViewController,MFMailComposeViewControllerDelegate,UINavigationControllerDelegate,CLLocationManagerDelegate,MKMapViewDelegate {
    var locationlat = CLLocation()
    var locationManager = CLLocationManager()
    var isSelect = Bool()
    var LoactionSelect = Bool()
     var emailArray = NSMutableArray()
    var locationString = String()
     var emailString = String()
    let userDefaults = UserDefaults.standard
    
    
    @IBOutlet weak var emailS: UIButton!
    @IBOutlet weak var mapVIew: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
         isSelect = false
         LoactionSelect = true
         clLoc?.initLocation(self.Setting,0.5)
         locationAddress()
         mapViewAction()
        
        
    }
    //MARK:地图初始化
    func mapViewAction()
    {
        self.mapVIew.mapType = MKMapType.standard
        self.mapVIew.delegate = self
        self.mapVIew.isRotateEnabled = true
        self.mapVIew.showsUserLocation = true
        
        self.mapVIew.userTrackingMode = .none
        //マップの中心地がユーザの現在地を追従するように設定
        self.mapVIew.showsBuildings = true
        // 指南针
        if #available(iOS 9.0, *) {
            self.mapVIew.showsCompass = true
            // 比例尺
            self.mapVIew.showsScale = true
            // 交通状况
            self.mapVIew.showsTraffic = true
        }
        
    }
    override func viewDidAppear(_ animated: Bool) {
         self.emailS.isHidden = false
        
        if self.isSelect == false
        {
            self.isSelect = true

        }
        else
        {
            self.isSelect = false
            if emailString == "1"
            {
                self.alertAction(message: " メールをキャンセルしました")
            }
            if emailString == "2"
            {
                self.alertAction(message: "メールを保存しました。")
            }
            if emailString == "3"
            {
               self.alertAction(message: "メールの送信が失敗しました")
            }
            if emailString == "4"
            {
               self.alertAction(message: "メールを送信しました。")
            }

        }
        
    }
    
    @IBAction func sendEmail(_ sender: UIButton)
    {
        print(self.locationString)

       self.emailS.isHidden = true
       self.sentEmail(loaction: self.locationString ,image:self.screenSnapshot()! )

    }
    //MARK : MKMapViewDelegate
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if annotation is MKUserLocation {
            let userLocationView = mapView.dequeueReusableAnnotationView(withIdentifier: "userLocationIdentifier")
            let ann2 = annotation as! MKUserLocation
            ann2.title = "現在地"
            userLocationView?.annotation = ann2
            return userLocationView
        }
        
        return nil
    }
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView,
                 didChange newState: MKAnnotationViewDragState,
                 fromOldState oldState: MKAnnotationViewDragState) {
        print("移动annotation位置时调用")
    }
    // MARK:蓝点: 大头针"视图"  大头针"数据模型"
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        // 设置地图显示区域
        if LoactionSelect == true
        {
            LoactionSelect = false
            let center = (userLocation.coordinate)
            let span = MKCoordinateSpanMake(0.0219952102009202, 0.0160932558432023)
            let region: MKCoordinateRegion = MKCoordinateRegionMake(center, span)
            mapView.setRegion(region, animated: true)
            
        }
        
        
    }
    
    //获取地址
    func locationAddress()
    {
        locationManager.delegate = self
        //每个十米获取用户位置
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        //Each ten meter takes the user's location
        locationManager.distanceFilter = 10
        //iOS8.0以上才可以使用
        if(UIDevice.current.systemVersion >= "8.0"){
            //始终允许访问位置信息
            locationManager.requestAlwaysAuthorization()
            //使用应用程序期间允许访问位置数据
            locationManager.requestWhenInUseAuthorization()
        }
        //To locate
        locationManager.startUpdatingLocation()
        
        
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        if let location = locations.last
        {
            locationlat = location
            self.reverseGeocode(location: locationlat)
        }
    }
    
    //MARK:地理信息反编码
    func reverseGeocode(location:CLLocation){
        let geocoder = CLGeocoder()
        let currentLocation = location
        geocoder.reverseGeocodeLocation(currentLocation, completionHandler: {
            (placemarks:[CLPlacemark]?, error:Error?) -> Void in

            //显示所有信息
            if error != nil {
                print("错误：\(String(describing: error?.localizedDescription)))")
               
                return
            }
            
            if let p = placemarks?[0]{
                print(p ) //输出反编码信息
                do {

          self.locationString = p.country! + p.administrativeArea! + p.locality! +  p.subLocality! + p.name!
                    
                }
                
            } else {
                print("No placemarks!")
            }
        })
    }

 
    //MARK:sent email
    func  sentEmail(loaction:String,image:UIImage)
    {
        
        //首先要判断设备具不具备发送邮件功能
        if MFMailComposeViewController.canSendMail(){
            let controller = MFMailComposeViewController()
            //设置代理
            controller.mailComposeDelegate = self
            //设置主题
            emailArray = NSMutableArray()
            
            controller.setSubject("Dangerous")
            
            emailArray = userDefaults.mutableArrayValue(forKey: "emailText")
            for index in 0...emailArray.count-1
            {
                controller.setToRecipients([emailArray.object(at: index) as! String])
            }
            //添加图片附件
    
            let myData = UIImagePNGRepresentation(image )
            controller.addAttachmentData(myData!, mimeType: "image/png", fileName: "email.png")
            
            //设置邮件正文内容（支持html）
            controller.setMessageBody(loaction + "latitude = \(locationlat.coordinate.latitude)" + "longitude = \(locationlat.coordinate.longitude)" , isHTML: false)
            
            //打开界面
            self.present(controller, animated: true, completion: nil)

        }else
        {
            print("本设备不能发送邮件")
            self.alertAction(message: "メールの配置がありませんので、メールアドレスを作ってください。")
        }
        
    }
    func alertAction(message:String)
    {
        let alert = UIAlertController(title:"警告", message: message, preferredStyle: UIAlertControllerStyle.alert)
        let action2 = UIAlertAction(title: "閉じる", style: UIAlertActionStyle.default, handler: {
            (action: UIAlertAction!) in
             self.TopPage()
        })
        alert.addAction(action2)
        self.present(alert, animated: true, completion: nil)
        
    }
    
    //发送邮件代理方法
    func mailComposeController(_ controller: MFMailComposeViewController,
                               didFinishWith result: MFMailComposeResult, error: Error?) {
    
        controller.dismiss(animated: true, completion: {
            
        })
        switch result{
        case .sent:
            print("邮件已发送")
            emailString = "1"
        case .cancelled:
            print("邮件已取消")
           emailString = "2"

            
//            let nextView = self.storyboard?.instantiateViewController(withIdentifier: "MenuView")
//
//            if self.clPHP?.task != nil {
//                self.clPHP?.task?.cancel()
//            }
//            present(nextView!, animated: true, completion: nil)
//
        case .saved:
            emailString = "3"
            print("邮件已保存")
            
        case .failed:
            emailString = "4"
            print("邮件发送失败")
        }
        
    
    }
    func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
//        var image  = UIImage()
        do
        {
            emailArray = userDefaults.mutableArrayValue(forKey: "emailText")
        }
      
        if emailArray.count != 0
        {

//            image = self.screenSnapshot(save: true)!
           

        }
        else
        {
           self.TopPage()
        }
        
        
        print("地图缩放完毕触法")
    }
    
    //屏幕截图
    func screenSnapshot() -> UIImage? {
        
        guard let window = UIApplication.shared.keyWindow else { return nil }
        
        // 用下面这行而不是UIGraphicsBeginImageContext()，因为前者支持Retina
        UIGraphicsBeginImageContextWithOptions(window.bounds.size, false, 0.0)
        
        window.layer.render(in: UIGraphicsGetCurrentContext()!)
        
        let image = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
//        if save { UIImageWriteToSavedPhotosAlbum(image!, self, nil, nil) }
        
        return image
    }
    

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
