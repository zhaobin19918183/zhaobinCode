//
//  RouteGuide.swift
//  MyMap2
//
//  Created by developer on 2017/04/17.
//  Copyright © 2017年 njk. All rights reserved.
//

import UIKit
import MapKit
import SSZipArchive
import Speech
import CoreMotion
import CoreLocation

class RouteGuideViewController: BaseViewController ,LocationDelegate,CLLocationManagerDelegate  {
    let userDefaults = UserDefaults.standard
     var gpstimer : Timer?
    private let mWarning = NSURL(fileURLWithPath: Bundle.main.path(forResource: "Warning", ofType: "mp3")!)
    private let mLike = NSURL(fileURLWithPath: Bundle.main.path(forResource: "Like", ofType: "mp3")!)
    private let mInfo = NSURL(fileURLWithPath: Bundle.main.path(forResource: "Info", ofType: "mp3")!)
    private let mStart = NSURL(fileURLWithPath: Bundle.main.path(forResource: "みれど", ofType: "mp3")!)
    private let mGoal = NSURL(fileURLWithPath: Bundle.main.path(forResource: "どれみ", ofType: "mp3")!)
    private let warning1 = NSURL(fileURLWithPath: Bundle.main.path(forResource: "seikai", ofType: "mp3")!)
    private let locationMP3 = NSURL(fileURLWithPath: Bundle.main.path(forResource: "warning1", ofType: "mp3")!)
    
    private  var clCalc = Calculation()
    private var routeOut : RouteOutType = .None
    private var sound = SoundVibrateClass()
    private var guideStart : Bool = false
    private  var isClose = false
    private var outpos :Int!
    private var id :String!
    //  private var degree : Double = 0
    var alllen :  Double = 0
    var SoundEnd :((_ d : Bool) -> ())?
    private var outmappt : MyPointAnnotation?    //プロパティ
    var mapCircle : MyPointAnnotation?
    var myPolyLine : MKPolyline?
    var SelectRoute : [String:Any]!
    var pos : Int = 0
    var routes : [[String:Any]] = []                        // ルートの各頂点情報の配列
    var routesAll : [[String:Any]] = []
    var poi : [[String:Any]] = []                           // 地点情報の配列
    var like : [[String:Any]] = []
    var dic : [[String:Any]] = []
    var isImage : Bool = true
    var oldpt : [String : Any]? = nil
    var gpsBad : Bool = false
    var routeOutPoint : [[String : Any]] = []
    var isReverse : Bool = false
    var isMoveReverse : Bool = false
    let  inlen : Double = 4
    var pedometer: CMPedometer!
    var isGoalMove : Bool = false                       //ゴール方向へ戻る機能ON　OFF
    let activityManager = CMMotionActivityManager()
    var pointArrar = NSMutableArray()
    var pointNumber = NSInteger()
    @IBOutlet weak var locationButtonz: UIButton!
    @IBOutlet weak var lblRouteName: UILabel!
    @IBOutlet weak var map: MKMapView!
    @IBOutlet weak var aroow: UIImageView!
    @IBOutlet weak var lblGuideLen: UILabel!
    @IBOutlet weak var lblWait: UILabel!
    @IBOutlet weak var lblGps: UILabel!
    @IBOutlet weak var lblSpeed: UILabel!
    @IBOutlet weak var btnClose: UIButton!
    @IBOutlet weak var lblRouteOut: UILabel!
    @IBOutlet weak var lblIsMove: UILabel!
    let numberLabel  = UILabel()
    @IBOutlet weak var arrowgoal: UIImageView!
    @IBOutlet weak var goFirstLoactionButton: UIButton!
    var locationManager = CLLocationManager()
    var distanceArr:NSMutableArray = []
    var locationlat = CLLocation()
    var mindistance = Int()
    var minPoint = Int()
    var  userid = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userid = UserDefaults.standard.string(forKey: "selectAction")!
        locationButtonz.isHidden = true
        self.numberAction()
        locationButtonz.layer.masksToBounds = true
        locationButtonz.layer.cornerRadius = 35
        locationButtonz.layer.borderWidth = 1
        locationButtonz.layer.borderColor = UIColor.red.cgColor
        //        let mTap:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(tapPress(_:)))
        //
        //        pointArrar = NSMutableArray()
        //        map.addGestureRecognizer(mTap)
        //        aroow.isHidden = true
        locationManager.delegate = self
        //每个十米获取用户位置
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        //Each ten meter takes the user's location
        locationManager.distanceFilter = 10
        //iOS8.0以上才可以使用
        if(UIDevice.current.systemVersion >= "8.0"){
            //始终允许访问位置信息
            locationManager.requestAlwaysAuthorization()
            //使用应用程序期间允许访问位置数据
            locationManager.requestWhenInUseAuthorization()
        }
        //To locate
        locationManager.startUpdatingLocation()
        clPHP?.GuideDir = self.GuideDir
        clLoc?.LocationDelegate = self
        clLoc?.initLocation(self.Setting,0.5)
        clLoc?.StartLocation()
        getZipData()
        map.delegate = self
        lblRouteName.text = SelectRoute["AliasName"] as? String
        lblWait.text = "ﾙｰﾄ情報を取得しています\nしばらくお待ちください"
        Speak2(lblWait.text!)
        let longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(longPressView2))
        longPressGesture.numberOfTapsRequired = 0          // 認識するのに必要なタップ数
        longPressGesture.numberOfTouchesRequired = 1    // 認識するために押さなければならない指の数
        longPressGesture.minimumPressDuration = 1         // ◯秒以上押された時に長押しと判断
        longPressGesture.allowableMovement = 30              // 長押し判定する指が動いていい範囲, 単位px
        map.addGestureRecognizer(longPressGesture)
        let swipeRecognizer = UISwipeGestureRecognizer(target:self, action: #selector(mapSwipe));
        swipeRecognizer.direction = .left
        self.view.addGestureRecognizer(swipeRecognizer)
        let swipeRightRecognizer = UISwipeGestureRecognizer(target:self, action: #selector(mapSwipe));
        swipeRightRecognizer.direction = .right
        map.addGestureRecognizer(swipeRightRecognizer)
        let swipeUpRecognizer = UISwipeGestureRecognizer(target:self, action: #selector(mapSwipe));
        swipeUpRecognizer.direction = .up
        map.addGestureRecognizer(swipeUpRecognizer)
        let swipeDouwRecognizer = UISwipeGestureRecognizer(target:self, action: #selector(mapSwipe));
        swipeDouwRecognizer.direction = .down
        map.addGestureRecognizer(swipeDouwRecognizer)
        self.FileDelete(dir: self.GuideDir)
        id = String("\(self.Setting.User as String)_\(self.SelectRoute[Col.ID.Val] as! String)")
        pedometer = CMPedometer()
        if(CMPedometer.isStepCountingAvailable()){
            self.pedometer.startUpdates(from: NSDate() as Date) {
                (data: CMPedometerData?, error) -> Void in
                DispatchQueue.main.async(execute: { () -> Void in
                    if(error == nil){
                        // 歩数
                        let steps = data!.numberOfSteps
                        self.lblIsMove.text  = "\(steps)歩"
                    }
                })
            }
        }
        self.activityManager.startActivityUpdates(to: OperationQueue.main, withHandler: { (data: CMMotionActivity?) -> Void in
            if (data?.automotive)! {
                //   self.lblIsMove .text = "停止"
            } else {
                // self.lblIsMove .text = "移動中"
            }
            //     print(data)
        })
//
//        NotificationCenter.default.addObserver(self, selector: #selector(settingSelect), name: NSNotification.Name(rawValue: "settingSelect"), object: nil)

        
    }
    //MARK:go first location
    @IBAction func goFirstLocationAction(_ sender: UIButton)
    {
        map.isRotateEnabled = true
        map.centerCoordinate = locationlat.coordinate
    }
    //MARK:番号
    func numberAction()
    {
        numberLabel.frame = CGRect(x: aroow.frame.origin.x, y: aroow.frame.origin.y - 30 , width: aroow.bounds.size.width, height:aroow.bounds.size.height)
        numberLabel.backgroundColor = UIColor.clear
        numberLabel.layer.masksToBounds = true
        numberLabel.layer.cornerRadius = 40
        numberLabel.layer.borderWidth = 1
        numberLabel.layer.borderColor = UIColor.black.cgColor
        numberLabel.textColor = UIColor.black
        numberLabel.font = UIFont.systemFont(ofSize: 50)
        numberLabel.textAlignment = .center
        numberLabel.text =  "\(mindistance)"
        map.addSubview(numberLabel)
    }
    //MARK:Automatic planning path
    @objc func tapPress(_ gestureRecognizer:UITapGestureRecognizer){
        let touchPoint:CGPoint = gestureRecognizer.location(in: map)
        let touchMapCoordinate:CLLocationCoordinate2D = map.convert(touchPoint, toCoordinateFrom: map)
        pointArrar.add(touchMapCoordinate)
        
    }
    //MARK:next  point
    @IBAction func locationButtonzAction(_ sender: UIButton)
    {
        distanceArr.removeAllObjects()
        for index in 0...routesAll.count-1
        {
            let lat = routesAll[index][Col.Lat.Val]
            let lon = routesAll[index][Col.Lon.Val]
            //Col.Lat.Val
            let targetLocation = CLLocation(latitude:lat as! CLLocationDegrees, longitude: lon as! CLLocationDegrees)
            let currentLocation = CLLocation(latitude: locationlat.coordinate.latitude, longitude: locationlat.coordinate.longitude)
            let distance:CLLocationDistance = currentLocation.distance(from: targetLocation)
            distanceArr.add(distance);
        }
        var min = Int(truncating: distanceArr[0] as! NSNumber)
        for i in 0..<distanceArr.count - 1 {
            
            let mindis = Int(truncating: distanceArr[i] as! NSNumber)
            if  mindis < min  {
                min = mindis
                minPoint = mindis
                mindistance = i
            }
        }
        mindistance =   mindistance + 1
        numberAction()
        self.toNextPointDirection()
    }
//    @objc func settingSelect()
//    {
//        userid = UserDefaults.standard.string(forKey: "selectAction")!
//
//    }
    //MARK: Begin to move to the next point, within five meters to reach the destination, go to the next coordinate point, play the voice, the continuous vibration and the prompt sound in the process
    func toNextPoint()
    {
        
       
        self.searchPoint()
        let lat = routesAll[mindistance][Col.Lat.Val]
        let lon = routesAll[mindistance][Col.Lon.Val]
        //Col.Lat.Val
        let targetLocation = CLLocation(latitude:lat as! CLLocationDegrees, longitude: lon as! CLLocationDegrees)
        let currentLocation = CLLocation(latitude: locationlat.coordinate.latitude, longitude: locationlat.coordinate.longitude)
        let distance:CLLocationDistance = currentLocation.distance(from: targetLocation)
        if distance < 5
        {
            if Setting.settingTenMSelect == 0
            {
                playMp3(warning1)
            }
            mindistance = mindistance + 1
            if mindistance == routesAll.count
            {
                super.Speak("番号は \(mindistance)番です", false, false)
                super.Speak("ゴールしました ", false, false)
                super.Speak("ゴールしました ", false, false)
                let keyString2 =  userDefaults.string(forKey: "ゴールオン-振動選択")
                if keyString2 != nil
                {
                    self.vibrationSelect(keyString2: keyString2!)
                }else
                {
                    self.vibrationSelect(keyString2: "0")
                }
               
            }
            else
            {
               toNextPointDirection()
            }
        }
        numberAction()
    }
    
    //MARK:The direction of the next point
    func toNextPointDirection()
    {
        let  degree =  self.clCalc.DirectionTime(Int(self.nextPointAngles()))
        super.Speak("\(degree)の方向,\(mindistance)番に移動", false, false)
       
      
    }
    //MARK:The Angle of the next coordinate point
    func nextPointAngles()->Double
    {

        let latstart : Double = routesAll[mindistance][Col.Lat.Val]  as! Double
        let lngstart : Double = routesAll[mindistance][Col.Lon.Val]   as! Double
        let latend : Double = locationlat.coordinate.latitude
        let lngend : Double = locationlat.coordinate.longitude
        let Y = cos(lngend * Double.pi / 180) * sin(latend * Double.pi / 180 - latstart * Double.pi / 180)
        let X = cos(lngstart * Double.pi / 180) * sin(lngend * Double.pi / 180) - sin(lngstart * Double.pi / 180) * cos(lngend * Double.pi / 180) * cos(latend * Double.pi / 180 - latstart * Double.pi / 180);
        var dirE0 = 180 * atan2(Y, X) / Double.pi // 東向きが０度の方向
        if (dirE0 < 0) {
            dirE0 = dirE0 + 360; //0～360 にする。
        }
        //let dirN0 = (dirE0 + 90) % 360; //(dirE0+90)÷360の余りを出力 北向きが０度の方向
        let dirN0 =  (dirE0 + 90).truncatingRemainder(dividingBy: 360)
        if dirN0 > Double(self.Setting.RegistDistanceInterval)
        {
            let mis = mindistance
            if userid == "101"
            {
                mindistance =  mis - 1
                numberAction()
            }

        }
        
        return dirN0
    }
    //    MARK:Draw the current position to the nearest point
    func  pointDistance() {
        self.searchPointMin()
        let req = MKDirectionsRequest()
        req.transportType =  MKDirectionsTransportType.walking
        let placest = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude:locationlat.coordinate.latitude , longitude:  locationlat.coordinate.longitude), addressDictionary:nil))
        req.source = placest
        let lat = Double(routesAll[mindistance][Col.Lat.Val] as! String)!
        let lon =  Double(routesAll[mindistance][Col.Lon.Val] as! String)!
        let placeed = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: lat, longitude:  lon), addressDictionary: nil))
        req.destination = placeed
        //发送导航请求
        let direction = MKDirections(request: req)
 map.setRegion(MKCoordinateRegionMakeWithDistance(CLLocationCoordinate2D(latitude: lat, longitude: lon), 2000, 2000), animated: false);
        
        direction.calculate { (res:MKDirectionsResponse?, error:Error?) -> Void in
            if let polyline=res?.routes.last?.polyline {
                self.map.add(polyline, level: MKOverlayLevel.aboveLabels)
            }
        }
    }
    //MARK: Find the nearest point
    func searchPoint()
    {
        distanceArr.removeAllObjects()
        for index in 0...routesAll.count-1
        {
            let lat =  routesAll[index][Col.Lat.Val]
            let lon =  routesAll[index][Col.Lon.Val]
            //Col.Lat.Val
            let targetLocation = CLLocation(latitude:lat as! CLLocationDegrees, longitude: lon as! CLLocationDegrees)
            let currentLocation = CLLocation(latitude: locationlat.coordinate.latitude, longitude: locationlat.coordinate.longitude)
            let distance:CLLocationDistance = currentLocation.distance(from: targetLocation)
            distanceArr.add(distance);
        }
        var min = Int(truncating: distanceArr[0] as! NSNumber)
        for i in 0..<distanceArr.count - 1 {
            
            let mindis = Int(truncating: distanceArr[i] as! NSNumber)
            
            if  mindis < min  {
                min = mindis
                minPoint = mindis
                mindistance = i
            }
        }
    }
    //MARK: Find the nearest point
    func searchPointMin()
    {
        for index in 0...routesAll.count-1
        {
            let lat = Double(routesAll[index][Col.Lat.Val] as! String)!
            let lon =  Double(routesAll[index][Col.Lon.Val] as! String)!
            //Col.Lat.Val
            let targetLocation = CLLocation(latitude:lat, longitude: lon)
            let currentLocation = CLLocation(latitude: locationlat.coordinate.latitude, longitude: locationlat.coordinate.longitude)
            let distance:CLLocationDistance = currentLocation.distance(from: targetLocation)
            print("两点间距离是：\(distance)")
            distanceArr.add(distance);
        }
        var min = Int(truncating: distanceArr[0] as! NSNumber)
        for i in 0..<distanceArr.count - 1 {
            
            let mindis = Int(truncating: distanceArr[i] as! NSNumber)
            if  mindis < min  {
                min = mindis
                minPoint = mindis
                mindistance = i
            }
        }
        mindistance =   mindistance + 1
        numberAction()
 
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            locationlat = location
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //Satellite
    @objc func mapSwipe (_ sender : UISwipeGestureRecognizer)
    {
        
        switch(sender.direction){
            
        case UISwipeGestureRecognizerDirection.left:
            if   map.mapType == .standard {
                map.mapType = .satellite
            } else {
                map.mapType = .standard
            }
            break
        case UISwipeGestureRecognizerDirection.down:
            if !(talker?.isSpeaking)! {
                clLoc?.GetAddress()
            }
            break
        case UISwipeGestureRecognizerDirection.right:
            if isClose {
                Speak2("案内中止をキャンセル")
                isClose = false
            }
            break
        default:
            if isClose {
                isClose = false
                Speak2("案内を終了")
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    self.Close()
                }
            }
            break
        }
    }
    
    @objc func longPressView2 (_ sender : UILongPressGestureRecognizer){
        switch sender.state {
        case .began:
            // 長押し開始
            Close()
            break
        default:
            break;
        }
    }
    
    private func Close() {
        stopMp3()
        SpeakEnd()
        pedometer.stopUpdates()
        activityManager.stopActivityUpdates()
        clLoc?.LocationEnd()
        clLoc?.LocationDelegate = nil

        TopPage()
    }
    
    /**
     ◆ルートデータを取得（ZIP）
     */
    private func getZipData () {
        self.clPHP?.ZipPath = {(path : String?,err : Int) in
            if err != 0 {
                self.FileDelete(dir: self.GuideDir)
                return
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                let ret = SSZipArchive.unzipFile(atPath: path!, toDestination: self.GuideDir.path)
                if !ret { return print("1")}
                do {
                    try FileManager.default.removeItem(atPath: path! as String)
                } catch  {
                    
                }
                let files =  try! FileManager.default.contentsOfDirectory(atPath: self.GuideDir.path )
                let zipdir = self.GuideDir.appendingPathComponent(files[0])
                let routepath = zipdir.appendingPathComponent("route.txt")
                var text = try! NSString( contentsOfFile: routepath.path, encoding: String.Encoding.utf8.rawValue)
                text =  text.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines) as NSString
                let msg = text.replacingOccurrences(of: "\n", with: "")
                print(msg)
                self.routesAll  = msg.JsonToDic()
                self.pointDistance()
                let poipath = zipdir.appendingPathComponent("poi.txt")
                text = try! NSString( contentsOfFile: poipath.path, encoding: String.Encoding.utf8.rawValue)
                self.poi  = text == "" ?  "[]".JsonToDic() : text.JsonToDic()
                let likepath = zipdir.appendingPathComponent("like.txt")
                text = try! NSString( contentsOfFile: likepath.path, encoding: String.Encoding.utf8.rawValue)
                self.like = text == "" ?  "[]".JsonToDic() : text.JsonToDic()
                self.FileDelete(dir: self.GuideDir)
                self.clLoc?.getGpsState = true
                //GPS精度
                self.clLoc?.GpsStateEvent = { (state : GpsState,  err : Double) in
                    self.lblGps.text = "\(Int(err))m "
                    if( state == GpsState.OK ) {
                        //self.Speak("ルート案内を開始します")
                        self.startlocation()
                    }  else if( state == GpsState.BadStart ) {
                        self.Speak("感度低いルート案内開始",false,false)
                        self.startlocation()
                    } else if( state == GpsState.NG ) {
                        self.lblWait.text = "感度低い"
                        self.Speak("感度低い", false, false)
                    }
                }
            }
        }
        let parameters: [String : Any] = ["USER": self.Setting.User,"ID":self.SelectRoute[Col.ID.Val] as! String  ]
        let phppath = "https://mymapdemo.net/nedo/route.php"
        clPHP?.GetData(phppath, parameters,.ZIP)
    }
    
    /**
     ◆ルート情報の初期化
     */
    func initRoute(_ pt: [String : Any]) {
        var min :Double = 0
        self.pos  = 0
        
        for i in 0..<self.routesAll.count {
            routesAll[i][Col.Lon.Val]  = ( routesAll[i] [Col.Lon.Val]  as! NSString).doubleValue
            routesAll[i][Col.Lat.Val]  = ( routesAll[i] [Col.Lat.Val]  as! NSString).doubleValue
            routesAll[i][Col.Len.Val]  = ( routesAll[i] [Col.Len.Val]  as! NSString).doubleValue
            routesAll[i][Col.No.Val]  = ( routesAll[i] [Col.No.Val]  as! NSString).integerValue
            routesAll[i][Col.Memo.Val]  = (routesAll[i] [Col.Memo.Val]  as! String).trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            routesAll[i][Col.POI.Val]  = ( routesAll[i] [Col.POI.Val]  as! NSString).integerValue
            var rpt = self.routesAll[i]
            if i != 0  {
                let poi =   rpt[Col.POI.Val] as! Int
                if i == self.routesAll.count - 1 {
                    addPoint(rpt,   .Goal)
                    rpt[Col.POI.Val]  = RouteType.Goal.rawValue
                    routes.append(rpt)
                } else  {
                    let len2 = clCalc.LineLengeth(self.routesAll[i], self.routesAll[ i - 1])
                    if len2 != 0  {
                        routes.append(rpt)
                        addPoint(rpt, RouteType(rawValue: poi)!)
                    } else {
                        let poi2 = self.routesAll[ i - 1][Col.POI.Val] as! Int
                        if   poi2 == 0   && (poi == 1 || poi == 2 || poi == 3) {
                            routes.remove(at: routes.count - 1 )
                            routes.append(rpt)
                        }
                    }
                    if  (poi == 1 || poi == 2 || poi == 3) {
                        self.poi.append(rpt)
                    }
                }
                //一番近いポイント
                let len = clCalc.LineLengeth(pt, rpt)
                if  min  > len  {
                    min = len
                    self.pos  = routes.count  - 1
                }
                
            } else {
                min = clCalc.LineLengeth(pt,   rpt)
                rpt[Col.POI.Val]  =  RouteType.Start.rawValue
                addPoint( rpt,.Start)
                routes.append(rpt)
            }
        }
        
        isMoveReverse = pos == routes.count - 1
        
        if pos == routes.count - 1 {
            
            //    let edlen = clCalc.LineLengeth(pt, routes[pos])
            //   let stlen = clCalc.LineLengeth(pt, routes[0])
            // let  ret = stlen - edlen
            //  if ret < 9 {
            //    pos = 0
            // }
        }
        //  routes = routesAll
        //var guideroute = routesAll
        // guideroute.removeSubrange(0..<pos)
        alllen = 0
        // GetAllLength(pt)
        //self.routesAll .togpxData()
    }
    
    //ルート長さ
    func GetAllLength(_ pt: [String : Any]) {
        for i in pos..<self.routes.count {
            alllen += routes[i][Col.Len.Val] as! Double
        }
        //let len =    alllen + clCalc.LineLengeth(pt ,routes[pos]).rounded()
        //lblSpeed .text = String("\(len.rounded())m")
    }
    
    //ファイル削除
    func FileDelete(dir : URL) {
        let  files =  try! FileManager.default.contentsOfDirectory(atPath: dir.path )
        for file in files{
            do {
                let filepath = dir.appendingPathComponent(file)
                try FileManager.default.removeItem(atPath: (filepath.path))
            } catch {
                
            }
        }
    }
    //位置情報の取得開始
    private func startlocation(){
        mapstart()
        locationEvent()
        self.initRoute((self.clLoc?.pt)!)
        self.routeLine()
        self.clLoc?.RecodeStart()
        self.clLoc?.getDirection = true
        let len : Double = clCalc.LineLengeth((self.clLoc?.pt)! ,routes[pos])
        if self.pos >= routes.count - 1 && len < 3 {
            // Speak2("目的地周辺です。案内を終了します")
            //guideStart = false
            //DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
            //     self.Close()
            //}
            //return
        }
        guideStart = true
        self.clLoc?.getMoveDirection = true;
        lblWait.isHidden = true
        //        addPoint2(pt: routes[self.pos])
    }
    var  angle:CGFloat = 0
    
    //位置情報イベント
    private  func  locationEvent() {
        
        //移動停止イベント
        self.clLoc?.StopEvent = { stop in
        }
        //方位イベント
        self.clLoc?.DegreeEvent = { (d,pt) in
            //if   self.clLoc?.Speed == 0 {
            self.setDirection(d,pt)
            // }
        }
        
        //移動方向
        self.clLoc?.MoveDegreeEvent = { (d,pt) in
            if self.pos == 0{
                self.isMoveReverse = false
                return
            }
            let  stpt = self.routes[self.pos - 1]
            let  edpt = self.routes[self.pos  ]
            let  degree =  self.clCalc.Direction(stpt,edpt)
            var go =    (d - degree).truncatingRemainder(dividingBy: 360)
            go = go >= 0 ? go : 360 + go
            //移動方向判定
            if self.isGoalMove {
                self.isMoveReverse = abs(go) > 90 && abs(go) < 270
            }
        }
    }
    
    //方位の設定
    func setDirection(_ d : Double,_ nowpt: [String : Any]) {
        if self.routeOut == .None {
            var stpt = routes[pos]
            var edpt : [String : Any]? = nil
            if pos == 0 {
                let len = self.clCalc.LineLengeth(nowpt, stpt)
                if len < inlen  && pos + 1 < routes.count {
                    stpt = routes[pos]
                    edpt = routes[pos + 1]
                }
                DirectionVibrate(nowpt,stpt,d,"スタート")
            } else if  pos  == routes.count  {
                let len = self.clCalc.LineLengeth(nowpt, stpt)
                if len < inlen  && pos - 1 <= 0{
                    stpt = routes[pos]
                    edpt = routes[pos - 1]
                }
                DirectionVibrate(nowpt,stpt,d,"ゴール")
            } else {
                stpt = routes[pos - 1]
                edpt =  routes[pos]
                var degree2  = self.clCalc.Direction(nowpt, edpt!)
                var retg =   (d - degree2).truncatingRemainder(dividingBy: 360)
                retg = retg >= 0 ? retg : 360 + retg
                var len = self.clCalc.LineLengeth(nowpt, edpt!)
                if len < inlen  && pos + 1 < routes.count  {
                    degree2 =  self.clCalc.Direction(nowpt,  routes[pos + 1])
                    retg =  (d - degree2).truncatingRemainder(dividingBy: 360)
                    retg = retg >= 0 ? retg : 360 + retg
                }
                self.angle = CGFloat(( retg * Double.pi) / 180.0)
                //終了時
                let  distance =  self.Setting.settingEndDistance
                self.arrowgoal.transform = CGAffineTransform(rotationAngle: self.angle)
                if  360 - distance   < Int(retg) ||  distance > Int(retg)
                {
                
                    if Setting.settingVoiceSelect == 0
                    {
                        
                        let keyString1 =  userDefaults.string(forKey: "ゴールオン-機械音選択")
                        
                        if keyString1 != nil
                        {
                            self.musicSelect(name: keyString1!)
                            
                        }
                        else
                        {
                            self.musicSelect(name: "seikai")
                        }

//
//                         playMp3(mGoal)
                    }
                    // self.Speak3("ゴール方向")
                }
                var  degree =  self.clCalc.Direction(nowpt, stpt)
                var ret = (d - degree).truncatingRemainder(dividingBy: 360)
                ret = ret >= 0 ? ret : 360 +  ret
                len = self.clCalc.LineLengeth(nowpt, stpt)
                if len < inlen  && pos - 2 >= 0 {
                    degree =  self.clCalc.Direction(nowpt, routes[pos - 2])
                    ret =  (d - degree).truncatingRemainder(dividingBy: 360)
                    ret = ret >= 0 ? ret : 360 + ret
                }
                let angleg = CGFloat((ret * Double.pi) / 180.0)
                self.aroow.transform = CGAffineTransform(rotationAngle: angleg)
                //スタート時
                let  distance1 =  self.Setting.settingStartDistance
                if(self.isGoalMove) {
                    if  360 - distance1  < Int(ret) ||  distance1 > Int(ret) {
                        self.sound.PlayVibrate()
                        playMp3(mStart)
                        //self.Speak3("スタート方向")
                    }
                }
            }
        } else {
            let  apt =  routes[self.outpos]
            let  degree =  self.clCalc.Direction(nowpt, apt)
            let  len =   clCalc.LineLengeth(apt, nowpt)
            var ret = (d - degree).truncatingRemainder(dividingBy: 360)
            ret = ret >= 0 ? ret : 360 + ret
            self.angle = CGFloat((ret * Double.pi) / 180.0)
            self.aroow.transform = CGAffineTransform(rotationAngle: self.angle)
            self.arrowgoal.transform = CGAffineTransform(rotationAngle: self.angle)
            //迷い子時
            let  distance2 =  self.Setting.settingMissDistance
            if  360 - distance2 < Int(ret)  || distance2 >  Int(ret) {
                //   self.sound.PlayVibrate()
               
                IwatchSessionUtil.shareManager.sendMessageToWatch(key: "MyMap2", value: "true")
               
                if(self.Setting.IsRouteoutVoice == 0) {
                    self.Speak2("ルートまで\(Int(len.rounded()))メートル")
                    //                lblRouteOut.text = String("\(len.rounded())m")
                }

                let keyString1 =  userDefaults.string(forKey: "ルート上音-機械音選択")
                let keyString2 =  userDefaults.string(forKey: "ルート上音-振動選択")
                if keyString2 != nil
                {
                     self.vibrationSelect(keyString2: keyString2!)
                    
                }
                else
                {
                    self.vibrationSelect(keyString2:"1-0")
                }
               
                if Setting.settingPeoPleSelect == 0
                {
                    if keyString1 != nil
                    {
                        self.musicSelect(name: keyString1!)
                    }
                    else
                    {
                        self.musicSelect(name: "seikai")
                    }
                }
               
                
            }
            else
            {
               
                
                let keyString1 =  userDefaults.string(forKey: "迷時音-機械音選択")
                let keyString2 =  userDefaults.string(forKey: "迷時音-振動選択")
                if keyString2 != nil
                {
                    self.vibrationSelect(keyString2: keyString2!)
                    
                }
                else
                {
                    self.vibrationSelect(keyString2: "no")
                }
                
                if Setting.settingPeoPleSelect == 0
                {
                    if keyString1 != nil
                    {
                        self.musicSelect(name: keyString1!)
                    }
                    else
                    {
                        self.musicSelect(name: "seikai")
                    }
                }
             IwatchSessionUtil.shareManager.sendMessageToWatch(key: "MyMap2", value: "false")

            }
            
        }
    }
    func musicSelect(name:String)
    {
     
//        let keyString2 =  userDefaults.string(forKey: "迷時音-振動選択")
//        if keyString2 != nil
//        {
//            self.vibrationSelect(keyString2: keyString2!)
//            
//        }
//        else
//        {
//            self.vibrationSelect(keyString2: "no")
//        }
//         self.sound.PlayVibrate(
        
        let location = NSURL(fileURLWithPath: Bundle.main.path(forResource: name, ofType: "mp3")!)
        playMp3(location)
        
    }
    
    func vibrationSelect(keyString2:String)
    {
        
        if keyString2 == "1-0"
        {
        
            timerPostLoaction(time: 1)
            
        }
        if keyString2 == "1-1"
        {
            //
            
            timerPostLoaction(time: 2)
        }
        if keyString2 == "1-2"
        {
         
            timerPostLoaction(time: 3)
            
        }
        else
        {
           
        
        }
        
    }
    
    func  timerPostLoaction(time:Int)
    {
        gpstimer = Timer.scheduledTimer(timeInterval: TimeInterval(time%10), target: self, selector: #selector(self.onGpsTimerUpdate(_:)), userInfo: nil, repeats: false)
        
    }
    
    @objc func onGpsTimerUpdate(_ timer : Timer)
    {
       self.sound.PlayVibrate()
        
    }
    func DirectionVibrate(_ nowpt: [String : Any] , _ stpt: [String : Any] ,_ d : Double,_ mes : String ){
        let  degree =  self.clCalc.Direction(nowpt, stpt)
        //degree =  self.clCalc.Direction(nowpt, routes[pos - 2])
        var ret = (d - degree).truncatingRemainder(dividingBy: 360)
        ret = ret >= 0 ? ret : 360 + ret
        self.angle = CGFloat((ret * Double.pi) / 180.0)
        self.aroow.transform = CGAffineTransform(rotationAngle: self.angle)
        self.arrowgoal.transform = CGAffineTransform(rotationAngle: self.angle)
        let  distance =  self.Setting.LostSearchDistance
        let  len =   clCalc.LineLengeth(nowpt, stpt)
        if  360 - distance < Int(ret) ||  distance > Int(ret)
        {
            
            self.sound.PlayVibrate()

            self.Speak2("\(mes)まで\(Int(len.rounded()))メートル")
        }
    }
    //MARK:Get the user's location
    func  LocationUpdate(_ pt: [String : Any],_ no : Int, _ isRequest : Bool) {
       
        if(!guideStart  ) {return; }
        if isImage {
            isImage = false
        }
        // let sp : Double = (self.clLoc?.Speed.rounded())!
        // self.lblSpeed.text = "\(NSString(format: "%.2f", sp))km"
        if oldpt  == nil  {
            self.lblSpeed.text  = "0m"
        } else {
            alllen += clCalc.LineLengeth(oldpt!, pt)

            self.lblSpeed.text  = "\(Int(alllen.rounded()) )m"
            let keyString2 =  userDefaults.string(forKey: "ルート上音-振動選択")
            if keyString2 != nil
            {
                self.vibrationSelect(keyString2: keyString2!)
            }else
            {
                self.vibrationSelect(keyString2: "0")
            }
           
            if self.routesAll.count != 0
            {
                self.toNextPoint()
                self.locationButtonz.isHidden = false
            }
            if Setting.settingVoiceSelect == 0
            {
                let keyString1 =  userDefaults.string(forKey: "ルート上音-機械音選択")
                if keyString1 != nil{
                
                    self.musicSelect(name: keyString1!)
                }
                else
                {
                    self.musicSelect(name: "seikai")
                }
            }

        }
        
        let err = pt[Col.Err.Val] as! Double
        if err > 10 {
            if !gpsBad     {
                self.Speak2("感度低下")
                gpsBad = true
            }
        } else {
            if gpsBad     {
                gpsBad = false
                self.Speak("感度良好")
            }
        }
        //mapScale(pt,0,self.map.camera.altitude)
        lblGps.text = String("\(Int(err.rounded()))m")
        //案内ポイントの更新　迷子中は更新しない
        var len : Double = 0
        if  isGoalMove {
            if isMoveReverse {
                if routeOut == .None {
                    routePosUpdateStart(pt)
                }
                setRouteOut(pt)
                if pos  !=  0 {
                    len = clCalc.LineLengeth(pt,self.routes[self.pos - 1])
                }
            }
        }
        if  !isGoalMove || !isMoveReverse {
            setRouteOut(pt)
            if routeOut == .None {
                routePosUpdateGole(pt)
            }
            len = clCalc.LineLengeth(pt,self.routes[self.pos])
        }
        oldpt  = pt
        lblGuideLen.text = String("\(Int(len.rounded()))m")
    }
    
    func  RoutePointSeach(_ pt: [String : Any] ) {
        var min :Double = 999999
        for i in 0..<self.routesAll.count {
            if i > 0  {
                let stpt = self.routesAll[i - 1]
                let edpt = self.routesAll[i]
                let ret = clCalc.GetNearPoint(pt,stpt,edpt)
                if( ret.isOnLine ){
                    let len = clCalc.LineLengeth(ret.pt, pt)
                    if  min  > len  {
                        min = len
                        self.pos  = i
                    }
                }
            }
        }
    }
    
    //迷子判定
    func setRouteOut (_ pt: [String : Any]) {
        if !(self.pos == 0 || self.pos  >=  routes.count ) {
            var stpt = self.routes[self.pos - 1]
            var edpt = self.routes[self.pos ]
            if isMoveReverse {
                stpt = self.routes[self.pos ]
                edpt = self.routes[self.pos - 1 ]
            }
            let  ret = clCalc.GetNearPoint(pt,stpt,edpt)
            var len = ret.len
            if routeOut != .None {
                len = clCalc.LineLengeth(pt, self.routes[outpos])
            }
            //    print(ret)
            if Int(len) > self.Setting.LostSmallDistance  {
                if routeOut == .None {
                    outpos = self.pos
                    let gllen = clCalc.LineLengeth(pt, self.routes[self.pos ])
                    let stlen = clCalc.LineLengeth(pt, self.routes[self.pos - 1 ])
                    outpos = self.pos
                    if  stlen < gllen{
                        if (self.pos != 0 ) {
                            outpos = self.pos - 1
                        }
                    }
                    self.Speak2("ルートから\(Int(len.rounded()))メートル小迷子")
                    routeOut = .S
                    //                    addOutPoint(self.routes[self.outpos], RouteType.Out)
                    //addPoint2(pt: self.routes[self.outpos])
                    routeOutPoint.append(pt)
                } else if (Int(ret.len)  > self.Setting.LostMiddleDistance){
                    if routeOut == .S || routeOut == .L {
                        // for outpt in routeOutPoint {
                        // addPoint(outpt, .Out)
                        //}
                        self.Speak2("ルートから\(Int(len.rounded()))メートル中迷子")
                        routeOut = .M
                    }
                } else {
                    if routeOut == .S || routeOut == .M {
                        routeOut = .L
                    }
                }
                if(self.Setting.IsRouteoutVoice == 0) {
                    let len = clCalc.LineLengeth(pt, self.routes[self.outpos])
                    lblRouteOut.text = String("\(Int(len.rounded()))m")
                }
            } else {
                //迷子ではなくなった時
                if(routeOut != .None) {
                    self.routeOutPoint = []
                    self.Speak2("ルート復帰")
                    self.deleteOutPoint();
                }
                lblRouteOut.text = "0m"
                //POI
                let poi =  routes[self.pos][Col.POI.Val] as? Int
                let len = clCalc.LineLengeth(pt ,routes[self.pos])
                if  poi  != 0 &&  len < inlen {
                    let val = routes[self.pos]["play"] as! Bool?
                    if val == nil  || val! != isMoveReverse {
                        let name = routes[self.pos][Col.Memo.Val] as! String
                        let routesounddir  = SoundDir?.appendingPathComponent(id, isDirectory : true)
                        let routesoundfile  = routesounddir?.appendingPathComponent(name, isDirectory : false)
                        let checkValidation = FileManager.default
                        var url = mWarning
                        if poi == 2 {
                            url = mInfo
                        } else if poi == 3 {
                            url = mLike
                        }
                        self.SpeakEnd()
                    SoundVibrateClass().PlaySystemSoundID(SystemSoundIDs.Alarm)
                        playMp3(url)
                        if (checkValidation.fileExists(atPath: (routesoundfile?.path)!)) {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                self.playMp3_2(routesoundfile! as NSURL)
                            }
                            routes[self.pos]["play"] = isMoveReverse
                        }
                    }
                }
                routeOut = .None
            }
        }
    }
    
    //ゴール方向
    func routePosUpdateGole(_ pt: [String : Any]) {
        let edpt = self.routes[pos]
        var isNext  = false
        var len : Double = clCalc.LineLengeth(pt, edpt)
        
        if  pos == 0 {
            routes[self.pos]["start"] = false
            if (!(talker?.isSpeaking)!) {
                self.Speak("スタートまで\(Int(len.rounded())))メートル",false,false)
            }
            let stpt = self.routes[pos]
            let edpt = self.routes[pos + 1]
            let  ret = clCalc.GetNearPoint(pt,stpt,edpt)
            if ret.isOnLine  || ret.len < inlen{
                Speak2("スタート付近")
                isNext = true
            }
        } else if pos  == routes.count - 1 {
            let val = routes[self.pos]["goal"] as! String?
            if val == nil || val == "0" {
                if Int(len) < self.Setting.LostSmallDistance {
                    Speak2("ゴール付近")
                    routes[self.pos]["goal"] = "1"
                }
            }
        } else {
            isNext =  len  < inlen
            if pos + 1 <  self.routes.count && !isNext {
                let stpt = self.routes[pos - 1]
                let edpt = self.routes[pos]
                let npt = self.routes[pos + 1]
                let  ret = clCalc.GetNearPoint(pt,stpt,edpt)
                let  ret2 = clCalc.GetNearPoint(pt,edpt,npt)
                if !ret.isOnLine  && ret2.isOnLine{
                    isNext  = ret2.len < ret.len
                }
            }
        }
        if isNext {
            self.pos += 1
            len = clCalc.LineLengeth(pt,self.routes[pos ])
        }
        //         addPoint2(pt: routes[self.pos])
    }
    
    //スタート方向
    func routePosUpdateStart(_ pt: [String : Any] ) {
        var isNext = false
        if  pos == 0 {
            let len : Double = clCalc.LineLengeth(pt, self.routes[0])
            if  Int(len) < self.Setting.LostSmallDistance  {
                let val = routes[self.pos]["start"] as! Bool?
                if val == nil  || !val! {
                    Speak2("スタート付近")
                    routes[self.pos]["start"] = true
                }
            }
        } else if pos  == routes.count - 1 {
            routes[self.pos]["goal"] = "0"
            isNext = true
        } else  {
            let stpt = self.routes[pos]
            let edpt = self.routes[pos - 1]
            var len : Double = clCalc.LineLengeth(pt, edpt)
            let  ret = clCalc.GetNearPoint2(pt,stpt,edpt)
            isNext  = len < inlen
            if pos - 2 >= 0  && !isNext   {
                let npt = self.routes[pos - 2]
                let  ret2 = clCalc.GetNearPoint2(pt,edpt,npt)
                len = clCalc.LineLengeth(pt, npt)
                if ret2.isOnLine && !ret.isOnLine {
                    isNext  = ret2.len < ret.len
                } else if !ret2.isOnLine && !ret.isOnLine  && len < 4{
                    isNext = true
                }
            }
        }
        if isNext {
            self.pos -= 1
        }
        if pos - 1 >= 0 {
            //            addPoint2(pt: routes[self.pos - 1 ])
        }
    }
    
    //住所
    func  GetAddressEvent(_ add: String) {
        Speak(add, false, false)
    }
    
    //
    func GpsLoggerUpdate(_ pt: [String : Any]) {
        mapMove(pt);
    }
    
    @IBAction func tap(_ sender: Any) {
        //if !(talker?.isSpeaking)! {
        // clLoc?.GetAddress()
        //}
    }
    
    @IBAction func btnCancel(_ sender: Any) {
        isClose = true
        SpeakEnd()
        Speak2("案内を終了します")
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.Close()
        }
        //Speak("ルート案内を終了してよろしいですか？画面を左スワイプで終了。右スワイプで中止できます")
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    }
}

extension RouteGuideViewController :  AVAudioPlayerDelegate{
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        SoundEnd!(true)
    }
}

extension RouteGuideViewController : MKMapViewDelegate   {
    
    func mapScale(_ pt : [String : Any],_ angle : Double,_ altitude : Double) {
        let lon = pt[Col.Lon.Val]  as! Double
        let lat = pt[Col.Lat.Val]  as! Double
        
        let coordinate = CLLocationCoordinate2DMake(lat, lon)
        // 縮尺
        let latDist : CLLocationDistance = 5
        let lonDist : CLLocationDistance = 5
        //表示領域を作成
        let region: MKCoordinateRegion = MKCoordinateRegionMakeWithDistance(coordinate , latDist, lonDist);
        //MapViewに反映
        map.setRegion(region, animated: true)
        
        //        let cam = map.camera.copy() as! MKMapCamera
        //        //cam.heading = angle
        //        cam.centerCoordinate = coordinate
        //        cam.altitude = altitude;
        //        map.setCamera(cam, animated: true)
        
    }
    
    func mapMove(_ pt : [String : Any]) {
        let lon = pt[Col.Lon.Val]  as! Double
        let lat = pt[Col.Lat.Val]  as! Double
        let coordinate = CLLocationCoordinate2DMake(lat, lon)
        map.setCenter(coordinate, animated: true)
    }
    func mapstart() {
        map.mapType = MKMapType.standard
        // 現在地の青い印を表示する
        map.showsUserLocation = true
        map.isRotateEnabled = false
        
        //マップの中心地がユーザの現在地を追従するように設定
        map.setUserTrackingMode(.follow, animated: true)
        map.setUserTrackingMode(.followWithHeading, animated: true)     // ユーザが向いている方向を表示
        
        if clLoc?.pt != nil
        {
           mapScale((clLoc?.pt)!,(clLoc?.Degree)!,5)
        }
        
        if( mindistance == 0)
        {
            mindistance = mindistance + 1
        }
        super.Speak("もうすぐ第\(mindistance)点に近づいて", false, false)
    }
    
    /**
     ◆地図上にルートを作成する
     */
    func routeLine() {
        if routes.count  == 0 { return }
        if(myPolyLine != nil) {
            map.remove(myPolyLine!)
            myPolyLine = nil
        }
        
        var coordinates : [CLLocationCoordinate2D] = []
        for i in 0..<routes.count {
            let lon = routes[i][Col.Lon.Val]  as! Double
            let lat = routes[i][Col.Lat.Val]  as! Double
            let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: lon)
            coordinates.append(coordinate)
        }
        // polyline作成.
        let line = MKPolyline(coordinates: &coordinates, count: coordinates.count)
        // mapViewにcircleを追加.
        map.add(line)
        myPolyLine = line
    }
    
    /**
     ◆地図上にアノテーションポイント（ピン）を追加する
     - Parameter pt : アノテーションポイントを作成する位置
     */
    func addPoint(_ pt : [String : Any],_ routetype  : RouteType) {
        self.pointNumber = self.pointNumber + 1
        let lon = pt[Col.Lon.Val]  as! Double
        let lat = pt[Col.Lat.Val]  as! Double
        let coordinate = CLLocationCoordinate2DMake(lat, lon)
        let  mapCircle = MyPointAnnotation()
        mapCircle.RouteType = routetype
        mapCircle.coordinate = coordinate
        mapCircle.number =  self.pointNumber
        map.addAnnotation(mapCircle)
    }
    
    func addPoint2(pt : [String : Any] ){
        if(mapCircle != nil) {
            map.removeAnnotation(mapCircle! )
            mapCircle = nil
        }
        if(routeOut == .None)  {
            let poi =   pt[Col.POI.Val] as! Int
            let  routetype = RouteType(rawValue: poi)!
            let lon = pt[Col.Lon.Val]  as! Double
            let lat = pt[Col.Lat.Val]  as! Double
            let coordinate = CLLocationCoordinate2DMake(lat, lon)
            mapCircle = MyPointAnnotation()
            mapCircle?.coordinate = coordinate
            mapCircle?.RouteType = routetype
            mapCircle?.height = 30
            mapCircle?.width = 30
            map.addAnnotation(mapCircle!)
        }
    }
    
    func addOutPoint(_ pt : [String : Any],_ routetype  : RouteType) {
        if(outmappt != nil) {
            map.removeAnnotation(outmappt! )
            outmappt = nil
        }
        if(mapCircle != nil) {
            map.removeAnnotation(mapCircle! )
            mapCircle = nil
        }
        let lon = pt[Col.Lon.Val]  as! Double
        let lat = pt[Col.Lat.Val]  as! Double
        let coordinate = CLLocationCoordinate2DMake(lat, lon)
        self.outmappt = MyPointAnnotation()
        outmappt?.RouteType = routetype
        outmappt?.height = 30
        outmappt?.width = 30
        outmappt?.coordinate = coordinate
        
        map.addAnnotation(outmappt!)
    }
    
    func deleteOutPoint() {
        if(outmappt != nil) {
            map.removeAnnotation(outmappt! )
            outmappt = nil
        }
    }
    
    //●指定されたオーバーレイを描画するときに使用するレンダラーオブジェクトのデリゲートを要求します。
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        mapView.setUserTrackingMode(.followWithHeading, animated: true)
        let myPolyLineRendere: MKPolylineRenderer = MKPolylineRenderer(overlay: overlay)
        // 線の太さを指定.
        myPolyLineRendere.lineWidth = 2
        // 線の色を指定.
        myPolyLineRendere.strokeColor = UIColor.red
        return myPolyLineRendere
    }
    //viewForAnnotation
    func mapViewWillStartLocatingUser(_ mapView: MKMapView)
    {
        //        mapView.setUserTrackingMode(.followWithHeading, animated: true)
    }
    
    //●ユーザー追跡モードが変更されたとき
    func mapView(_ mapView: MKMapView, didChange mode: MKUserTrackingMode, animated: Bool) {
        //     mapView.setUserTrackingMode(.followWithHeading, animated: false)
    }
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        //        mapView.centerCoordinate = (userLocation.location?.coordinate)!
    }
    
    //MARK : 自定义大头针
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        var image =  #imageLiteral(resourceName: "LocationPoint")
        if annotation is MKUserLocation {
            let userLocationView = mapView.dequeueReusableAnnotationView(withIdentifier: "userLocationIdentifier")
            let ann2 = annotation as! MKUserLocation
            ann2.title = "現在地"
            userLocationView?.annotation = ann2
            return userLocationView
        }
        
        let ann : MyPointAnnotation = annotation as! MyPointAnnotation
        var name = "def"
        
        if ann.RouteType == .Start {
            image =  #imageLiteral(resourceName: "StartPoint")
            name = "start"
        } else if ann.RouteType == .Goal {
            image =  #imageLiteral(resourceName: "GoalPoint")
            name = "goal"
        } else if ann.RouteType == .Denger {
            image =  #imageLiteral(resourceName: "DangerPoint")
            name = "danger"
        } else if ann.RouteType == .Info {
            image =  #imageLiteral(resourceName: "InfoPoint")
            name = "info"
        } else if ann.RouteType == .Like {
            image =  #imageLiteral(resourceName: "FavoritePoint")
            name = "like"
        }
        //       else if ann.RouteType == .Out {
        //            image = #imageLiteral(resourceName: "RouteOut")
        //            name = "Out"
        //        }
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: name)
        if annotationView == nil
        {
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: name)
            
            
            
        }else {
            annotationView?.annotation = annotation
            
        }
        
        //        if ann.RouteType == .Out {
        //            annotationView?.layer.zPosition = 99;
        //        }
        
        
        // 比率に合わせてリサイズする
        let resizedSize = CGSize(width: ann.width*1.5 , height:ann.height*1.5 )
        UIGraphicsBeginImageContext(resizedSize)
        image.draw(in: CGRect(x: 0, y: 0, width: resizedSize.width, height: resizedSize.height))
        let resizedImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        annotationView?.image =    resizedImage
        let  titleLabel = UILabel(frame:CGRect(x:0, y:0, width:ann.width*1.5, height:ann.height*1.5))
        titleLabel.font = UIFont.systemFont(ofSize: 10)
        titleLabel.textColor = UIColor.white
        titleLabel.textAlignment = NSTextAlignment.center
        titleLabel.text = String(format: "%d",ann.number)
        if ann.RouteType == .Start {
            //            image = #imageLiteral(resourceName: "StartPoint")
            titleLabel.backgroundColor = UIColor.black
            name = "start"
        } else if ann.RouteType == .Goal {
            //            image = #imageLiteral(resourceName: "GoalPoint")
            titleLabel.backgroundColor = UIColor.black
            name = "goal"
        } else if ann.RouteType == .Denger {
            //            image = #imageLiteral(resourceName: "DangerPoint")
            titleLabel.backgroundColor = UIColor.red
            name = "danger"
        } else if ann.RouteType == .Info {
            //            image = #imageLiteral(resourceName: "InfoPoint")
            titleLabel.backgroundColor = UIColor.black
            name = "info"
        } else if ann.RouteType == .Like {
            //            image = #imageLiteral(resourceName: "FavoritePoint")
            titleLabel.backgroundColor = UIColor.blue
            name = "like"
        }
        else if ann.RouteType == .Out {
            //            image = #imageLiteral(resourceName: "RouteOut")
            //            titleLabel.backgroundColor = UIColor.clear
            //            titleLabel.textColor = UIColor.clear
            //            name = "Out"
            
        }
        else if ann.RouteType == .None {
            titleLabel.backgroundColor = UIColor.init(red: 16.0/255.0, green: 135/255.0, blue: 49.0/255.0, alpha: 1)
            name = "def"
        }
        annotationView?.addSubview(titleLabel)
        return annotationView
    }
    
    //TODO: 这里是针对大头针的属性,以后修改
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView,
                 calloutAccessoryControlTapped control: UIControl) {
        print("点击注释视图按钮")
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        print("点击大头针注释视图")
    }
    
    func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView) {
        print("取消点击大头针注释视图")
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView,
                 didChange newState: MKAnnotationViewDragState,
                 fromOldState oldState: MKAnnotationViewDragState) {
        print("移动annotation位置时调用")
    }
    //当大头针被添加到地图上时调用
    func mapView(_ mapView:MKMapView, didAdd views: [MKAnnotationView]){
        print("添加大头针！")
    }
    
    //    MARK: routeSearch
    func routeSearch(_ stpt : [String : Any] ,_ edpt : [String : Any]) {
        let myLatitude = Double(stpt[Col.Lat.Val] as! String)!
        let myLongitude = Double(stpt[Col.Lon.Val]  as! String)!
        // 目的地の緯度、経度を設定.
        let requestLatitude = Double(edpt[Col.Lat.Val]  as! String)!
        let requestLongitude = Double(edpt[Col.Lon.Val]  as! String)
        // 目的地の座標を指定.
        let requestCoordinate: CLLocationCoordinate2D = CLLocationCoordinate2DMake(requestLatitude, requestLongitude!)
        let fromCoordinate: CLLocationCoordinate2D = CLLocationCoordinate2DMake(myLatitude, myLongitude)
        // PlaceMarkを生成して出発点、目的地の座標をセット.
        let fromPlace: MKPlacemark = MKPlacemark(coordinate: fromCoordinate, addressDictionary: nil)
        let toPlace: MKPlacemark = MKPlacemark(coordinate: requestCoordinate, addressDictionary: nil)
        // Itemを生成してPlaceMarkをセット.
        let fromItem: MKMapItem = MKMapItem(placemark: fromPlace)
        let toItem: MKMapItem = MKMapItem(placemark: toPlace)
        // MKDirectionsRequestを生成.
        let myRequest: MKDirectionsRequest = MKDirectionsRequest()
        // 出発地のItemをセット.
        myRequest.source = fromItem
        // 目的地のItemをセット.
        myRequest.destination = toItem
        
        // 複数経路の検索を有効.
        myRequest.requestsAlternateRoutes = true
        
        // 移動手段を車に設定.
        myRequest.transportType = MKDirectionsTransportType.automobile
        
        // MKDirectionsを生成してRequestをセット.
        let myDirections: MKDirections = MKDirections(request: myRequest)
        // 経路探索.
        myDirections.calculate { (response, error) in
            
            // NSErrorを受け取ったか、ルートがない場合.
            if error != nil || response!.routes.isEmpty {
                return
            }
            
            let route: MKRoute = response!.routes[0] as MKRoute
            print("目的地まで \(route.distance)km")
            print("所要時間 \(Int(route.expectedTravelTime/60))分")
            
            for  i in 0..<route.polyline.pointCount {
                _ =  route.polyline.points()[i]
            }
            
            // mapViewにルートを描画.
            self.map.add(route.polyline)
        }
    }
}

class MyPointAnnotation : MKPointAnnotation {
    var width : CGFloat = 10
    var height : CGFloat = 10
    var RouteType : RouteType = .None
    var number = 0
    
    
}


