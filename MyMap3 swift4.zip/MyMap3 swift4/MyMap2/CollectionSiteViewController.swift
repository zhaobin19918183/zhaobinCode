//
//  CollectionSiteViewController.swift
//  MyMap2
//
//  Created by newland on 2018/1/9.
//  Copyright © 2018年 njk. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation // 定位GPS相关
class CollectionSiteViewController: BaseViewController,CLLocationManagerDelegate,MKMapViewDelegate {
    
    @IBOutlet weak var backButton: UIButton!
    var isSelect = Bool()
    var gpstimer : Timer?
    @IBOutlet weak var mapView: MKMapView!
    var locationlat = CLLocation()
    var locationManager = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        clLoc?.initLocation(self.Setting,0.5)
        isSelect = true
        mapViewAction()
        locationAddress()
    }
    //MARK: 定时器每隔五秒与目标点进行距离计算
    func  timerPostLoaction()
    {
      gpstimer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(self.onGpsTimerUpdate(_:)), userInfo: nil, repeats: true)
        
    }
    
    @objc func onGpsTimerUpdate(_ timer : Timer)
    {
//        self.lengthStartToEnd(location: )
        
    }
    
    @IBAction func back(_ sender: UIButton)
    {
        self.TopPage()
    }
    //MARK:服务器交互
    func postLoaction()
    {
        //TODO:等待接口
        
    }
    //MARK:地图初始化
    func mapViewAction()
    {
        self.mapView.mapType = MKMapType.standard
        self.mapView.delegate = self
        self.mapView.isRotateEnabled = true
        self.mapView.showsUserLocation = true
        
        self.mapView.userTrackingMode = .none
        //マップの中心地がユーザの現在地を追従するように設定
        self.mapView.showsBuildings = true
        // 指南针
        if #available(iOS 9.0, *) {
            self.mapView.showsCompass = true
            // 比例尺
            self.mapView.showsScale = true
            // 交通状况
            self.mapView.showsTraffic = true
        }
        
    }
    //MARK: 计算当前位置和目标位置的距离符合要求后接受发送数据
    func  lengthStartToEnd(location:CLLocation)
    {
        
        let targetLocation = CLLocation(latitude:location.coordinate.latitude, longitude: location.coordinate.longitude)
        let currentLocation = CLLocation(latitude: locationlat.coordinate.latitude, longitude: locationlat.coordinate.longitude)
        let distance:CLLocationDistance = currentLocation.distance(from: targetLocation)
        if distance > 100 && distance < 1000
        {
            print("接近目的地")
            
        }

    }
    
    //MARK:接收服务器数据,画出集合点的位置
    func destinationPoint(location:CLLocation)
    {
        //创建一个MKCoordinateSpan对象，设置地图的范围（越小越精确）
        let latDelta = 0.05
        let longDelta = 0.05
        let currentLocationSpan:MKCoordinateSpan = MKCoordinateSpanMake(latDelta, longDelta)
        //定义地图区域和中心坐标（
        //使用自定义位置
        let center:CLLocation = CLLocation(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let currentRegion:MKCoordinateRegion = MKCoordinateRegion(center: center.coordinate,
                                                                  span: currentLocationSpan)
        
        //设置显示区域
        self.mapView.setRegion(currentRegion, animated: true)
        //创建一个大头针对象
        let objectAnnotation = MKPointAnnotation()
        //设置大头针的显示位置
        objectAnnotation.coordinate = CLLocation(latitude: location.coordinate.latitude,
                                                 longitude: location.coordinate.longitude).coordinate
        //设置点击大头针之后显示的标题
        objectAnnotation.title = "集合地点"
        //设置点击大头针之后显示的描述
//        objectAnnotation.subtitle = "南京市秦淮区秦淮河北岸中华路"
        //添加大头针
        self.mapView.addAnnotation(objectAnnotation)
        
    }
    
    //MARK : MKMapViewDelegate
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if annotation is MKUserLocation {
            let userLocationView = mapView.dequeueReusableAnnotationView(withIdentifier: "userLocationIdentifier")
            let ann2 = annotation as! MKUserLocation
            ann2.title = "現在地"
            userLocationView?.annotation = ann2
            return userLocationView
        }
        
        return nil
    }
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView,
                 didChange newState: MKAnnotationViewDragState,
                 fromOldState oldState: MKAnnotationViewDragState) {
        print("移动annotation位置时调用")
    }
    // MARK:蓝点: 大头针"视图"  大头针"数据模型"
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        // 设置地图显示区域
        if isSelect == true
        {
            isSelect = false
            let center = (userLocation.coordinate)
            let span = MKCoordinateSpanMake(0.0219952102009202, 0.0160932558432023)
            let region: MKCoordinateRegion = MKCoordinateRegionMake(center, span)
            mapView.setRegion(region, animated: true)
            
        }
        
        
    }
    
    
    //获取地址
    func locationAddress()
    {
        locationManager.delegate = self
        //每个十米获取用户位置
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        //Each ten meter takes the user's location
        locationManager.distanceFilter = 10
        //iOS8.0以上才可以使用
        if(UIDevice.current.systemVersion >= "8.0"){
            //始终允许访问位置信息
            locationManager.requestAlwaysAuthorization()
            //使用应用程序期间允许访问位置数据
            locationManager.requestWhenInUseAuthorization()
        }
        //To locate
        locationManager.startUpdatingLocation()
        
        
    }
    
    //MARK:CLLocationManagerDelegate
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        if let location = locations.last
        {
            locationlat = location
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
