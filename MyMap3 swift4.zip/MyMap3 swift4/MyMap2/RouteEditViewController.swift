//
//  RouteEditViewController.swift
//  MyMap2
//
//  Created by developer on 2017/04/25.
//  Copyright © 2017年 njk. All rights reserved.
//

import UIKit
import MapKit
import SSZipArchive
import Speech


class RouteEditViewController :    BaseViewController  {

    private let mWarning = NSURL(fileURLWithPath: Bundle.main.path(forResource: "Warning", ofType: "mp3")!)
    private let mLike = NSURL(fileURLWithPath: Bundle.main.path(forResource: "Like", ofType: "mp3")!)
    private let mInfo = NSURL(fileURLWithPath: Bundle.main.path(forResource: "Info", ofType: "mp3")!)
    private  var clCalc = Calculation()

    private var sound = SoundVibrateClass()
    private var id :String!

    var SoundEnd :((_ d : Bool) -> ())?
    
    //プロパティ
    var mapCircle : MyPointAnnotation?
    var myPolyLine : MKPolyline?
    var SelectRoute : [String:Any]!
    var pos : Int = 0
    var routes : [[String:Any]] = []                        // ルートの各頂点情報の配列
    var routesAll : [[String:Any]] = []
    var poi : [[String:Any]] = []                           // 地点情報の配列
    var like : [[String:Any]] = []
    var isImage : Bool = true
    
    @IBOutlet weak var lblRouteName: UILabel!
    
    @IBOutlet weak var map: MKMapView!
    @IBOutlet weak var aroow: UIImageView!
    @IBOutlet weak var lblGuideLen: UILabel!
    @IBOutlet weak var lblWait: UILabel!
    @IBOutlet weak var lblGps: UILabel!
    @IBOutlet weak var lblSpeed: UILabel!
    @IBOutlet weak var btnClose: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        clPHP?.GuideDir = self.GuideDir
        getZipData()
        map.delegate = self
        lblRouteName.text = SelectRoute["AliasName"] as? String
        let longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(longPressView2))
        longPressGesture.numberOfTapsRequired = 0          // 認識するのに必要なタップ数
        longPressGesture.numberOfTouchesRequired = 1    // 認識するために押さなければならない指の数
        longPressGesture.minimumPressDuration = 3         // ◯秒以上押された時に長押しと判断
        longPressGesture.allowableMovement = 30              // 長押し判定する指が動いていい範囲, 単位px
        map.addGestureRecognizer(longPressGesture)
        
        let swipeRecognizer = UISwipeGestureRecognizer(target:self, action: #selector(mapSwipe));
        swipeRecognizer.direction = .left
        map.addGestureRecognizer(swipeRecognizer)
        
        let swipeRightRecognizer = UISwipeGestureRecognizer(target:self, action: #selector(mapSwipe));
        swipeRightRecognizer.direction = .right
        map.addGestureRecognizer(swipeRightRecognizer)
        
        let swipeUpRecognizer = UISwipeGestureRecognizer(target:self, action: #selector(mapSwipe));
        swipeUpRecognizer.direction = .up
        map.addGestureRecognizer(swipeUpRecognizer)
        
        let swipeDouwRecognizer = UISwipeGestureRecognizer(target:self, action: #selector(mapSwipe));
        swipeDouwRecognizer.direction = .down
        map.addGestureRecognizer(swipeDouwRecognizer)
        
  
        id = String("\(self.Setting.User as String)_\(self.SelectRoute[Col.ID.Val] as! String)")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func mapSwipe (_ sender : UISwipeGestureRecognizer){
        switch(sender.direction){
        case UISwipeGestureRecognizerDirection.up:
            if   map.mapType == .standard {
                map.mapType = .hybrid
            } else {
                map.mapType = .standard
            }
            break
        case UISwipeGestureRecognizerDirection.down:
            if !(talker?.isSpeaking)! {
                clLoc?.GetAddress()
            }
            break
        case UISwipeGestureRecognizerDirection.right:
            break
        default:
            break
        }
    }
    
    @objc func longPressView2 (_ sender : UILongPressGestureRecognizer){
        switch sender.state {
        case .began:
            // 長押し開始
            Close()
            break
        default:
            break;
        }
    }
    
    private func Close() {
        SpeakEnd()
        clLoc?.LocationEnd()
        clLoc?.LocationDelegate = nil
        TopPage()
    }
    
    /**
     ◆ルートデータを取得（ZIP）
     */
    private func getZipData () {
        self.clPHP?.ZipPath = {(path : String?,err : Int) in
            if err != 0 {
                self.FileDelete(dir: self.GuideDir)
                return
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                let ret = SSZipArchive.unzipFile(atPath: path!, toDestination: self.GuideDir.path)
                if !ret { return print("1")}
                do {
                    try FileManager.default.removeItem(atPath: path! as String)
                } catch  {
                    
                }
                let files =  try! FileManager.default.contentsOfDirectory(atPath: self.GuideDir.path )
                let zipdir = self.GuideDir.appendingPathComponent(files[0])
                let routepath = zipdir.appendingPathComponent("route.txt")
                var text = try! NSString( contentsOfFile: routepath.path, encoding: String.Encoding.utf8.rawValue)
                text =  text.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines) as NSString
                let msg = text.replacingOccurrences(of: "\n", with: "")
                print(msg)
                self.routesAll  = msg.JsonToDic()
                let poipath = zipdir.appendingPathComponent("poi.txt")
                text = try! NSString( contentsOfFile: poipath.path, encoding: String.Encoding.utf8.rawValue)
                self.poi  = text == "" ?  "[]".JsonToDic() : text.JsonToDic()
                let likepath = zipdir.appendingPathComponent("like.txt")
                text = try! NSString( contentsOfFile: likepath.path, encoding: String.Encoding.utf8.rawValue)
                self.like = text == "" ?  "[]".JsonToDic() : text.JsonToDic()
                self.FileDelete(dir: self.GuideDir)
                self.initRoute()
            }
        }
        let parameters: [String : Any] = ["USER": self.Setting.User,"ID":self.SelectRoute[Col.ID.Val] as! String  ]
        let phppath = "https://mymapdemo.net/nedo/route.php"
        clPHP?.GetData(phppath, parameters,.ZIP)
    }
    
    /**
     ◆ルート情報の初期化
     */
    func initRoute() {
        for i in 0..<self.routesAll.count {
            routesAll[i][Col.Lon.Val]  = ( routesAll[i] [Col.Lon.Val]  as! NSString).doubleValue
            routesAll[i][Col.Lat.Val]  = ( routesAll[i] [Col.Lat.Val]  as! NSString).doubleValue
            routesAll[i][Col.Len.Val]  = ( routesAll[i] [Col.Len.Val]  as! NSString).doubleValue
            routesAll[i][Col.No.Val]  = ( routesAll[i] [Col.No.Val]  as! NSString).integerValue
            routesAll[i][Col.Memo.Val]  = (routesAll[i] [Col.Memo.Val]  as! String).trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            routesAll[i][Col.POI.Val]  = ( routesAll[i] [Col.POI.Val]  as! NSString).integerValue
            var rpt = self.routesAll[i]
            if i != 0  {
                if i == self.routesAll.count - 1 {
                    addPoint(rpt,   .Goal)
                } else {
                    let poi =   rpt[Col.POI.Val] as! Int
                    addPoint(rpt, RouteType(rawValue: poi)!)
                }
            } else {
                addPoint( rpt,.Start)
            }
        }
        routes = routesAll
        routeLine()
        
    }
    
    var alllen :  Double = 0
    func GetAllLength(_ pt: [String : Any]) {
        
        for i in pos..<self.routes.count {
            alllen += routes[i][Col.Len.Val] as! Double
        }
        let len =    alllen + clCalc.LineLengeth(pt ,routes[pos]).rounded()
        lblSpeed .text = String("\(len.rounded())m")
    }
    
    
    func FileDelete(dir : URL) {
        let  files =  try! FileManager.default.contentsOfDirectory(atPath: dir.path )
        for file in files{
            do {
                let filepath = dir.appendingPathComponent(file)
                try FileManager.default.removeItem(atPath: (filepath.path))
            } catch {
                
            }
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    
}

extension RouteEditViewController :  AVAudioPlayerDelegate{
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        SoundEnd!(true)
    }
}

extension RouteEditViewController : MKMapViewDelegate   {

    /**
     ◆地図上にルートを作成する
     */
    func routeLine() {
        if routes.count  == 0 { return }
        if(myPolyLine != nil) {
            map.remove(myPolyLine!)
            myPolyLine = nil
        }
        
        var coordinates : [CLLocationCoordinate2D] = []
        for i in 0..<routes.count {
            let lon = routes[i][Col.Lon.Val]  as! Double
            let lat = routes[i][Col.Lat.Val]  as! Double
            let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: lon)
            coordinates.append(coordinate)
        }
        
        // polyline作成.
        let line = MKPolyline(coordinates: &coordinates, count: coordinates.count)
        // mapViewにcircleを追加.
        map.add(line)
        myPolyLine = line
    }
    
    /**
     ◆地図上にアノテーションポイント（ピン）を追加する
     - Parameter pt : アノテーションポイントを作成する位置
     */
    func addPoint(_ pt : [String : Any],_ routetype  : RouteType) {
        
        let lon = pt[Col.Lon.Val]  as! Double
        let lat = pt[Col.Lat.Val]  as! Double
        let coordinate = CLLocationCoordinate2DMake(lat, lon)
        let  mapCircle = MyPointAnnotation()
        mapCircle.RouteType = routetype
        mapCircle.coordinate = coordinate
        map.addAnnotation(mapCircle)
    }
    
    func addPoint2(pt : [String : Any] ){
        if(mapCircle != nil) {
            map.removeAnnotation(mapCircle! )
            mapCircle = nil
        }
        var routetype  : RouteType = .None
        if pos == self.routesAll.count - 1 {
            routetype = .Goal
        } else if pos  == 0  {
            routetype = .Start
        } else {
            let poi =   pt[Col.POI.Val] as! Int
            routetype = RouteType(rawValue: poi)!
        }
        let lon = pt[Col.Lon.Val]  as! Double
        let lat = pt[Col.Lat.Val]  as! Double
        let coordinate = CLLocationCoordinate2DMake(lat, lon)
        mapCircle = MyPointAnnotation()
        mapCircle?.coordinate = coordinate
        mapCircle?.RouteType = routetype
        mapCircle?.height = 20
        mapCircle?.width = 20
        map.addAnnotation(mapCircle!)
    }
    
    
    //●指定されたオーバーレイを描画するときに使用するレンダラーオブジェクトのデリゲートを要求します。
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let myPolyLineRendere: MKPolylineRenderer = MKPolylineRenderer(overlay: overlay)
        // 線の太さを指定.
        myPolyLineRendere.lineWidth = 2
        // 線の色を指定.
        myPolyLineRendere.strokeColor = UIColor.red
        return myPolyLineRendere
    }
    
    //●ユーザー追跡モードが変更されたとき
    func mapView(_ mapView: MKMapView, didChange mode: MKUserTrackingMode, animated: Bool) {
        map.setUserTrackingMode(.follow, animated: true)
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation {
            return nil
        }
        let ann : MyPointAnnotation = annotation as! MyPointAnnotation
        var image = #imageLiteral(resourceName: "LocationPoint")
        var name = "def"
        if ann.RouteType == .Start {
            image = #imageLiteral(resourceName: "StartPoint")
            name = "start"
        } else if ann.RouteType == .Goal {
            image = #imageLiteral(resourceName: "GoalPoint")
            name = "goal"
        } else if ann.RouteType == .Denger {
            image = #imageLiteral(resourceName: "DangerPoint")
            name = "danger"
        } else if ann.RouteType == .Info {
            image = #imageLiteral(resourceName: "InfoPoint")
            name = "info"
        } else if ann.RouteType == .Like {
            image = #imageLiteral(resourceName: "FavoritePoint")
            name = "like"
        }
        
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: name)
        if annotationView == nil {
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: name)
        }else {
            annotationView?.annotation = annotation
        }
        // 比率に合わせてリサイズする
        let resizedSize = CGSize(width: ann.width , height:ann.height )
        UIGraphicsBeginImageContext(resizedSize)
        image.draw(in: CGRect(x: 0, y: 0, width: resizedSize.width, height: resizedSize.height))
        let resizedImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        annotationView?.image =    resizedImage
        return annotationView
    }
    
    
    
}
