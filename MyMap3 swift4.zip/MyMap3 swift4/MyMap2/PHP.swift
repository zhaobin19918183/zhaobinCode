//
//  PHP.swift
//  MyMap
//
//  Created by developer on 2017/02/17.
//  Copyright © 2017年 njk. All rights reserved.
//

import Foundation


class PHP {
    
    private  var files :[String]!
     var  GuideDir:URL!
    private var routeDir :URL!
    var JsonData  :((_ json : NSString?,_ err : Int) ->  ())?
    var ZipPath  :((_ path : String?,_ err : Int) ->  ())?
    var UploadComplete  :((_ path : String?) ->  ())?
    var PhpComplete  :((_ ret : Bool?) ->  ())?
    
    
    init() {
        // Document - Route の構成から以下の構成に変更
        // Document - Temp - Route
        let docDir = URL( string: NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0])
//        routeDir = docDir?.appendingPathComponent("Route", isDirectory: true)
        
        let tempDir = docDir?.appendingPathComponent("Temp", isDirectory: true)
        self.routeDir = tempDir?.appendingPathComponent("Route", isDirectory : true)
        
    }
    
    // POST送信
    func UpLoad(_ zip : URL,_ phpurl : String,_ parameters: [String: String] ,_ delPath : String) {
        let zipData = try! Data(contentsOf: URL(fileURLWithPath: zip.path))
        let request = NSMutableURLRequest(url:URL(string: phpurl)!)
        let fileName =  (zip.path as NSString).lastPathComponent
        request.httpMethod = "POST"
        let boundary = "----------SwIfTeRhTtPrEqUeStBoUnDaRy"
        let contentType = "multipart/form-data; boundary=\(boundary)"
        request.setValue(contentType, forHTTPHeaderField:"Content-Type")
        var  body = Data()
        let parameterName = "USERFILE"
        let mimeType = "application/zip"
        for (key, value) in parameters {
            body .append("--\(boundary)\r\n".data(using: .utf8)!)
            body .append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: .utf8)!)
            body .append("\(value)\r\n".data(using: .utf8)!)
        }
        body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
        let contentDisposition = "Content-Disposition: form-data; name=\"\(parameterName)\"; filename=\"\(fileName)\"\r\n"
        body.append(contentDisposition.data(using: String.Encoding.utf8)!)
        body.append("Content-Type: \(mimeType)\r\n\r\n".data(using: String.Encoding.utf8)!)
        body.append(zipData )
        body.append("\r\n".data(using: String.Encoding.utf8)!)
        body.append("\r\n--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
        request.setValue("\(body.count)", forHTTPHeaderField: "Content-Length")
        request.httpBody = body as Data
        files =  try! FileManager.default.contentsOfDirectory(atPath: (self.routeDir?.path)! )
        let name = fileName.replacingOccurrences(of: ".zip", with: "")
        files  = files.filter{
            $0.contains(name)
        }
        let session = URLSession.shared
        let task = session.dataTask(with: request as URLRequest)  { (data, response, err) in
            if (err != nil) {
                print(err!)
                return
            }
          
            if let data = data {
                let s = NSString(data: data, encoding: String.Encoding.utf8.rawValue)
                if s == "0" {
                      self.FIleDelete()
                }
               self.UploadComplete!(s as String?)
            }
       
        }
        task.resume()
    }
    
    func FIleDelete() {
        for file in self.files{
            do {
                let filepath = self.routeDir?.appendingPathComponent(file)
                try FileManager.default.removeItem(atPath: (filepath?.path)!)
            } catch {
                
            }
        }
    }
    

    var task : URLSessionDataTask?
    
    func GetData(_ phpurl : String,_ parameters: [String: Any],_ mode : DataType ) {
        var request = URLRequest(url:URL(string: phpurl)!)
        request.httpMethod = "POST"
        var body : String = ""
        for (key, value) in parameters {
            if(body != ""){
                      body += "&"
            }
            body += "\(key)=\(value)"
        }
        request.httpBody = body.data(using: .utf8)
        let session = URLSession.shared
        if task != nil {
            task?.cancel()
        }
        
        task = session.dataTask(with: request as URLRequest)  { (data, response, err) in
            guard err == nil else {
                if( mode == .JSON) {
                    self.JsonData!(nil,1)
                }else if mode == .ZIP{
                    self.ZipPath!(nil,1)
                }
                return
            }
            guard let data = data else {
                if(mode == .JSON) {
                    self.JsonData!(nil,2)
                } else if mode == .ZIP{
                    self.ZipPath!(nil,2)
                }
                return
            }
            if( mode == .JSON ) {
                let s = NSString(data: data, encoding: String.Encoding.utf8.rawValue)
                if(s != nil) {
                    self.JsonData!(s,0)
                    return
                }
                
            } else if mode == .ZIP {
                let n =  data as NSData
                 let temp : URL  = self.GuideDir!.appendingPathComponent("temp.zip")
                n.write(toFile: temp.path , atomically: true)
                self.ZipPath!(temp.path,0)
            }
            self.task = nil
        }
        task?.resume()
  
    }

    func Post(_ phpurl : String,_ parameters: [String: Any]) {
        var request = URLRequest(url:URL(string: phpurl)!)
        request.httpMethod = "POST"
        var body : String = ""
        for (key, value) in parameters {
            if(body != ""){
                body += "&"
            }
            body += "\(key)=\(value)"
        }
        request.httpBody = body.data(using: .utf8)
        let session = URLSession.shared
        let task = session.dataTask(with: request as URLRequest)  { (data, response, err) in
            guard err == nil else {
                return self.PhpComplete!(  false)
            }
            guard let data = data else {
                return self.PhpComplete!(  false)
            }
            let s = NSString(data: data, encoding: String.Encoding.utf8.rawValue)
            if(s == nil) {
                return self.PhpComplete!(  false)
            } else if s ==  "0" {
                return self.PhpComplete!(  true)
            }
            return self.PhpComplete!(  false)
        }
        task.resume()
    }
    
}
