//
//  BaseViewController.swift
//  MyMap2
//
//  Created by 栄養 メイト on 2017/04/17.
//  Copyright © 2017年 njk. All rights reserved.
//

import UIKit
import Speech
class BaseViewController: UIViewController {

    var Setting : SettingClass!
    var TempDir : URL!
    var SoundDir : URL!
    var RouteDir  : URL!
    var GuideDir : URL!
    var UpdateDir : URL!
    var talker : AVSpeechSynthesizer?
    var clLoc : LocationManagerClass?
    var clPHP : PHP?
    var musicPlayer:AVAudioPlayer!
    var oldmusicPlayer:AVAudioPlayer!
    /** 読み上げ終了イベント */
    var SpeakEndEvent : (()->())?
    var IsSpeakEndEvent : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if(!(self is MenuViewController || self is RouteRegist) ){
            let longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(longPressView(_:)))
            longPressGesture.numberOfTapsRequired = 0          // 認識するのに必要なタップ数
            longPressGesture.numberOfTouchesRequired = 1    // 認識するために押さなければならない指の数
            longPressGesture.minimumPressDuration = 3         // ◯秒以上押された時に長押しと判断
            longPressGesture.allowableMovement = 30              // 長押し判定する指が動いていい範囲, 単位px
            self.view.addGestureRecognizer(longPressGesture)
        }
        
        if(talker == nil){
            talker = AVSpeechSynthesizer()
            talker?.delegate = self
        }
        
        if(clLoc == nil){
            clLoc = LocationManagerClass()
            clPHP = PHP()
        }
        
        let userid = UserDefaults.standard.string(forKey: "selectAction")
        
        //判断UserDefaults中是否已经存在
        if(userid != nil){
            
            
        }else{
           UserDefaults.standard.set("101", forKey: "selectAction")
        }
        
     
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        let view = segue.destination as! BaseViewController
        initViewController( view)
    }
    
    func initViewController (_ view  : BaseViewController ) {
        view.Setting = self.Setting
        view.TempDir = self.TempDir
        view.SoundDir = self.SoundDir
        view.RouteDir = self.RouteDir
        view.GuideDir = self.GuideDir
        view.UpdateDir = self.UpdateDir
        view.clLoc = self.clLoc
        view.clPHP = self.clPHP
        
        //self.clLoc?.LocationEnd()
        self.clLoc?.LocationDelegate = nil
        self.clLoc = nil
        self.clPHP = nil
    }
    
    
    
    func TopPage() {
        let nextView = self.storyboard?.instantiateViewController(withIdentifier: "MenuView")
        
        if self.clPHP?.task != nil {
            self.clPHP?.task?.cancel()
        }
        present(nextView!, animated: true, completion: nil)
    }
    
    
    /**
     ◆長押し時の処理
     */
    @objc func longPressView (_ sender : UILongPressGestureRecognizer){
        
        switch sender.state {
        case .began:
            // 長押し開始
            TopPage()
            break
            
        case .changed:
            // 長押し状態で指を移動した
            print("long press changed")
            break
            
        case .ended:
            // 長押し終了(指を離した)
       
        
            break
            
        default:
            break;
        }
        
    }
    
    /**
     ◆音声読み上げ
     - Parameter value : 読み上げる内容
     - Parameter isPB : 再生用に読み上げ内容を保持するかどうか
     - Parameter isMan : 男性のような音声で読み上げるかどうか
     */
    //self.Setting.settingVoiceSelect
    func Speak(_ value : String,_ isPB  : Bool = false ,_ isMan: Bool = false) {
        if(value == "") {return}
   
        let utterance = AVSpeechUtterance(string: value)
        utterance.voice = AVSpeechSynthesisVoice(language: "ja-JP")
        if isMan {
            utterance.pitchMultiplier = 0.4
        } else {
            utterance.pitchMultiplier = 1.1
        }
        utterance.volume = 0.5
        utterance.rate = Setting.SpeakSpeed.value
        if Setting.settingVoiceSelect == 0 {
            self.talker?.speak(utterance)
        }
        
    }
    
    func Speak2(_ value : String,_ isPB  : Bool = false ,_ isMan: Bool = false) {
        if(value == "") {return}
        
        let utterance = AVSpeechUtterance(string: value)
        utterance.voice = AVSpeechSynthesisVoice(language: "ja-JP")
        SpeakEnd()
        if isMan {
            utterance.pitchMultiplier = 0.4
        } else {
            utterance.pitchMultiplier = 1.1
        }
        utterance.volume = 0.5
        utterance.rate = Setting.SpeakSpeed.value
        if Setting.settingVoiceSelect == 0 {
            self.talker?.speak(utterance)
        }
//        self.talker?.speak(utterance)
    }
    
    func Speak3(_ value : String,_ isPB  : Bool = false ,_ isMan: Bool = false) {
        if(value == "") {return}
        
        let utterance = AVSpeechUtterance(string: value)
        utterance.voice = AVSpeechSynthesisVoice(language: "ja-JP")
        if(!(talker?.isSpeaking)!) {
            if isMan {
                utterance.pitchMultiplier = 0.4
            } else {
                utterance.pitchMultiplier = 1.1
            }
            utterance.rate = Setting.SpeakSpeed.value
            self.talker?.speak(utterance)
        }
    }
    
    func SpeakEnd() {
        if(talker?.isSpeaking)! {
            talker?.stopSpeaking(at: AVSpeechBoundary.immediate)
        }
    }
    
    func playMp3(_ url  : NSURL ) {
        do {
            //musicPlayer.volume = 0.5
            if  (musicPlayer == nil || musicPlayer.isPlaying == false) && talker?.isSpeaking == false {
                musicPlayer = try AVAudioPlayer(contentsOf: url as URL)
                musicPlayer.play()
            }
        } catch {}
    }
    
    func playMp3_2(_ url  : NSURL ) {
        do {
            //musicPlayer.volume = 0.5
            if  (musicPlayer != nil && musicPlayer.isPlaying == true) {
                musicPlayer.stop();
            }
            SpeakEnd();
            musicPlayer = try AVAudioPlayer(contentsOf: url as URL)
            musicPlayer.play()
        } catch {}
    }
    
    func stopMp3() {
     
        if(musicPlayer == nil) {return }
            if  musicPlayer.isPlaying {
                musicPlayer.stop()
            }
       
    }
    
}


extension BaseViewController : AVSpeechSynthesizerDelegate {
    
    /** 音声読み上げ終了 */
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        if IsSpeakEndEvent {
            self.SpeakEndEvent?()
        }
    }
    
}
