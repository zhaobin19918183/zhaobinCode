//
//  InterfaceController.swift
//  MyMapWatch Extension
//
//  Created by newland on 2018/1/17.
//  Copyright © 2018年 njk. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet var titleLabel: WKInterfaceLabel!
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        NotificationCenter.default.addObserver(
            self, selector: #selector(onDeactivate), name:NSNotification.Name(rawValue: "MyMap2"), object: nil)
        // Configure interface objects here.
    }
    
    @objc func onDeactivate(notification:NSNotification)
    {
        let valueObject = notification.object as! [String: AnyObject]
        print(valueObject["key"]! as! String)
        let vaule = valueObject["key"]! as! String
        if vaule == "true"
        {
             WKInterfaceDevice.current().play(.click)
             titleLabel.setText("ルートにのっています")
        }
        else
        {
         titleLabel.setTextColor(UIColor.white)
         titleLabel.setText("ルート上以外は  ルート OFF")
        }
        
       
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    

    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
     
        NotificationCenter.default.addObserver(
            self, selector: #selector(onDeactivate), name:NSNotification.Name(rawValue: "NSExtensionHostDidEnterBackgroundNotification"), object: nil)
        super.didDeactivate()
    }

}
